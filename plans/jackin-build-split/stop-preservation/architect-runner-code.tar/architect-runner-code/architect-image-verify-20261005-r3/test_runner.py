from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
import shlex

import runner


class RunnerFixtures(unittest.TestCase):
    def test_docker_vectors_keep_space_paths_as_single_arguments(self) -> None:
        docker = Path("/tmp/private bin/docker cli")
        context = Path("/tmp/private build contexts/Architect source")
        cidfile = Path("/tmp/private logs/runtime container.cid")
        tag = "architect-image-verify:fixture-amd64"

        build = runner.make_build_argv(docker, tag, context)
        self.assertEqual(build[0], str(docker))
        self.assertEqual(build[build.index("--file") + 1], str(context / "Dockerfile"))
        self.assertEqual(build[-1], str(context))
        self.assertIn("CARGO_BUILD_JOBS=4", build)
        self.assertIn("MISE_JOBS=1", build)
        self.assertEqual(build[1:3], ["buildx", "build"])
        self.assertIn("--load", build)
        self.assertIn("memory=32g", build)
        self.assertIn("cpu-quota=400000", build)
        self.assertIn("cpu-period=100000", build)

        probe = runner.make_probe_argv(docker, tag, cidfile)
        self.assertEqual(probe[0], str(docker))
        self.assertEqual(probe[probe.index("--cidfile") + 1], str(cidfile))
        self.assertIn("--entrypoint=/bin/bash", probe)
        self.assertEqual(probe[-2:], [tag, "-s"])
        self.assertIn("--network=none", probe)
        self.assertIn("--cpus=4", probe)
        self.assertIn("--memory=4g", probe)
        self.assertNotIn("--mount", probe)
        self.assertNotIn("--privileged", probe)
        self.assertFalse(any("secret" in arg.lower() for arg in probe))

    def test_execution_refuses_nonisolated_python_environment(self) -> None:
        self.assertFalse(runner.execution_environment_is_isolated())

    def test_buildx_plugin_metadata_and_resource_help_are_required(self) -> None:
        output = "warning\n[{\"Name\":\"compose\"},{\"Name\":\"buildx\",\"Path\":\"/usr/libexec/docker/cli-plugins/docker-buildx\",\"Version\":\"v0.37.1\"}]\n"
        self.assertEqual(
            runner.parse_buildx_plugin_info(output),
            {"path": "/usr/libexec/docker/cli-plugins/docker-buildx", "version": "v0.37.1"},
        )
        runner.require_buildx_resource_flag("Options:\n      --resource stringArray  Resource limits for build\n")
        with self.assertRaisesRegex(runner.RunnerError, "one Docker Buildx"):
            runner.parse_buildx_plugin_info("[]\n")
        with self.assertRaisesRegex(runner.RunnerError, "--resource"):
            runner.require_buildx_resource_flag("Options:\n      --memory string\n")

    def test_fake_executable_receives_exact_argv_stdin_and_clean_environment(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner argv fixture with spaces ") as raw:
            root = Path(raw)
            executable = root / "fake docker command"
            record = root / "argv record.json"
            source = """#!/usr/bin/python3
import json, os, sys
payload = sys.stdin.buffer.read()
with open(RECORD_PATH, 'w', encoding='utf-8') as f:
    json.dump({'argv': sys.argv[1:], 'stdin': payload.decode(), 'home': os.environ.get('HOME'), 'keys': sorted(os.environ)}, f)
""".replace("RECORD_PATH", json.dumps(str(record)))
            executable.write_text(source)
            executable.chmod(0o700)
            log = root / "fake log.txt"
            home = root / "clean home"
            home.mkdir()
            environment = {"HOME": str(home), "PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
            expected_argv = ["run", "one value with spaces", "--label", "a=b c"]
            script = "printf '%s\\n' 'fixture only'\n"

            self.assertEqual(
                runner.run_bounded("fake-docker-fixture", [str(executable), *expected_argv], environment, log, 5, script.encode()),
                0,
            )
            captured = json.loads(record.read_text())
            self.assertEqual(captured["argv"], expected_argv)
            self.assertEqual(captured["stdin"], script)
            self.assertEqual(captured["home"], str(home))
            self.assertNotIn("GITHUB_TOKEN", captured["keys"])
            self.assertNotIn("OPENAI_API_KEY", captured["keys"])

    def test_fake_child_is_reaped_after_timeout(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner timeout fixture ") as raw:
            root = Path(raw)
            executable = root / "sleeping fake docker"
            child_pid_file = root / "child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                f"sleep 60 & child=$!; printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}; wait\n"
            )
            executable.chmod(0o700)
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded("fake-timeout-fixture", [str(executable)], {"PATH": "/usr/bin:/bin"}, root / "timeout.log", 1)
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.05)
            else:
                self.fail(f"timed-out child process still exists: {child_pid}")

    def test_timeout_covers_blocked_stdin_delivery(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner blocked stdin fixture ") as raw:
            root = Path(raw)
            executable = root / "nonreading fake docker"
            child_pid_file = root / "child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                f"sleep 60 & child=$!; printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}; wait\n"
            )
            executable.chmod(0o700)
            started = time.monotonic()
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded(
                    "fake-blocked-stdin-fixture",
                    [str(executable)],
                    {"PATH": "/usr/bin:/bin"},
                    root / "blocked-stdin.log",
                    1,
                    b"x" * (2 * 1024 * 1024),
                )
            self.assertLess(time.monotonic() - started, 4)
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.05)
            else:
                self.fail(f"blocked-input child process still exists: {child_pid}")

    def test_timeout_kills_ignoring_grandchild_after_leader_exits(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner grandchild fixture ") as raw:
            root = Path(raw)
            executable = root / "ignoring fake docker"
            child_pid_file = root / "ignoring-child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                "python3 -c 'import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(60)' & child=$!\n"
                f"printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}\n"
                "trap 'exit 0' TERM\n"
                "wait \"$child\"\n"
            )
            executable.chmod(0o700)
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded(
                    "fake-grandchild-fixture",
                    [str(executable)],
                    {"PATH": "/usr/bin:/bin"},
                    root / "grandchild.log",
                    0.2,
                )
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                stat_path = Path(f"/proc/{child_pid}/stat")
                if stat_path.exists() and stat_path.read_text().split(") ", 1)[1].split()[0] == "Z":
                    break
                time.sleep(0.05)
            else:
                self.fail(f"SIGTERM-ignoring process survived group cleanup: {child_pid}")

    def test_raw_tree_context_ignores_replace_refs_attributes_and_worktree_files(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner raw tree fixture with spaces ") as raw:
            root = Path(raw)
            repo = root / "repo with spaces"
            repo.mkdir()
            git_home = root / "isolated git home"
            git_home.mkdir()
            env = runner.clean_git_env(git_home)
            subprocess.run(["/usr/bin/git", "init", "--quiet", str(repo)], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.name", "Fixture"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.email", "fixture@example.invalid"], check=True, env=env)
            fixture_files = {
                ".dockerignore": ".git\n",
                "Dockerfile": "FROM scratch\n# $Format:%H$\n",
                ".gitattributes": "Dockerfile export-ignore export-subst\n",
                "caveman-config.json": '{"defaultMode":"ultra"}\n',
                "AGENTS.md.d/caveman.md": "Fixture instructions\n",
                "AGENTS.md.d/token-tools.md": "Fixture tool rules\n",
                "jackin-toolchain/mise.toml": "[tools]\n",
                "jackin-toolchain/rust-toolchain.toml": "[toolchain]\nchannel = \"1.98.1\"\n",
                "maintained-image-build/skills-cli/package.json": '{"name":"fixture"}\n',
                "maintained-image-build/skills-cli/package-lock.json": '{"lockfileVersion":3}\n',
                "README.md": "Tracked but not part of the build context\n",
            }
            for name, contents in fixture_files.items():
                path = repo / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(contents)
            (repo / "untracked-secret.txt").write_text("must not enter the context\n")
            subprocess.run(["/usr/bin/git", "-C", str(repo), "add", "--all"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "commit", "--quiet", "-m", "fixture"], check=True, env=env)
            commit = subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
                env=env,
            ).stdout.strip()
            original_tree = runner.verify_source(repo, commit, git_home)[1]

            attributes = repo / ".git" / "info" / "attributes"
            attributes.write_text("Dockerfile export-ignore export-subst\n")
            dockerfile = repo / "Dockerfile"
            dockerfile.write_text("FROM replaced-object\n")
            subprocess.run(["/usr/bin/git", "-C", str(repo), "add", "Dockerfile"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "commit", "--quiet", "-m", "replacement"], check=True, env=env)
            replacement = subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
                env=env,
            ).stdout.strip()
            replacement_env = dict(env)
            replacement_env.pop("GIT_NO_REPLACE_OBJECTS")
            subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "replace", commit, replacement],
                check=True,
                env=replacement_env,
            )

            pinned_commit, pinned_tree = runner.verify_source(repo, commit, git_home)
            self.assertEqual(pinned_commit, commit)
            self.assertEqual(pinned_tree, original_tree)
            context = root / "context with spaces"
            manifest = runner.materialize_tree_context(repo, original_tree, context, git_home)
            files = {entry["path"] for entry in manifest["files"]}
            self.assertEqual(files, runner.REQUIRED_FILES)
            self.assertEqual((context / "Dockerfile").read_text(), fixture_files["Dockerfile"])
            self.assertFalse((context / ".gitattributes").exists())
            self.assertFalse((context / "README.md").exists())
            self.assertFalse((context / "untracked-secret.txt").exists())

    def test_reviewed_source_tree_passes_dockerfile_contract(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner reviewed source ") as raw:
            root = Path(raw)
            git_home = root / "git home"
            git_home.mkdir(mode=0o700)
            commit, tree = runner.verify_source(
                runner.REPO, runner.REVIEWED_SOURCE_COMMIT, git_home
            )
            self.assertEqual(commit, runner.REVIEWED_SOURCE_COMMIT)
            self.assertEqual(tree, runner.REVIEWED_SOURCE_TREE)
            context = root / "context"
            runner.materialize_tree_context(runner.REPO, tree, context, git_home)
            runner.validate_dockerfile_contract(context / "Dockerfile")

    def test_probe_script_is_bash_syntax_valid_and_never_invokes_context7_or_skills(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory())
        checked = subprocess.run(["/bin/bash", "-n"], input=script, capture_output=True)
        self.assertEqual(checked.returncode, 0, checked.stderr.decode())
        source = script.decode()
        self.assertIn("mise exec --deny-net -- mbx build", source)
        self.assertIn("mise exec --deny-net -- cargo build", source)
        self.assertIn("ctx7 CLI not invoked", source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/ctx7" --', source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/skills" add', source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
