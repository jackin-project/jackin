from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
import shlex

import runner


class RunnerFixtures(unittest.TestCase):
    def test_docker_vectors_keep_space_paths_as_single_arguments(self) -> None:
        docker = Path("/tmp/private bin/docker cli")
        context = Path("/tmp/private build contexts/Architect source")
        cidfile = Path("/tmp/private logs/runtime container.cid")
        tag = "architect-image-verify:fixture-amd64"

        build = runner.make_build_argv(docker, tag, context)
        self.assertEqual(build[0], str(docker))
        self.assertEqual(build[build.index("--file") + 1], str(context / "Dockerfile"))
        self.assertEqual(build[-1], str(context))
        self.assertIn("CARGO_BUILD_JOBS=4", build)
        self.assertIn("MISE_JOBS=1", build)
        self.assertEqual(build[1:3], ["buildx", "build"])
        self.assertIn("--load", build)
        self.assertIn("memory=32g", build)
        self.assertIn("cpu-quota=400000", build)
        self.assertIn("cpu-period=100000", build)

        probe = runner.make_probe_argv(docker, tag, cidfile)
        self.assertEqual(probe[0], str(docker))
        self.assertEqual(probe[probe.index("--cidfile") + 1], str(cidfile))
        self.assertEqual(probe[-3:], [tag, "/bin/bash", "-s"])
        self.assertIn("--network=none", probe)
        self.assertIn("--cpus=4", probe)
        self.assertIn("--memory=4g", probe)
        self.assertNotIn("--mount", probe)
        self.assertNotIn("--privileged", probe)
        self.assertFalse(any("secret" in arg.lower() for arg in probe))

    def test_fake_executable_receives_exact_argv_stdin_and_clean_environment(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner argv fixture with spaces ") as raw:
            root = Path(raw)
            executable = root / "fake docker command"
            record = root / "argv record.json"
            source = """#!/usr/bin/python3
import json, os, sys
payload = sys.stdin.buffer.read()
with open(RECORD_PATH, 'w', encoding='utf-8') as f:
    json.dump({'argv': sys.argv[1:], 'stdin': payload.decode(), 'home': os.environ.get('HOME'), 'keys': sorted(os.environ)}, f)
""".replace("RECORD_PATH", json.dumps(str(record)))
            executable.write_text(source)
            executable.chmod(0o700)
            log = root / "fake log.txt"
            home = root / "clean home"
            home.mkdir()
            environment = {"HOME": str(home), "PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
            expected_argv = ["run", "one value with spaces", "--label", "a=b c"]
            script = "printf '%s\\n' 'fixture only'\n"

            self.assertEqual(
                runner.run_bounded("fake-docker-fixture", [str(executable), *expected_argv], environment, log, 5, script.encode()),
                0,
            )
            captured = json.loads(record.read_text())
            self.assertEqual(captured["argv"], expected_argv)
            self.assertEqual(captured["stdin"], script)
            self.assertEqual(captured["home"], str(home))
            self.assertNotIn("GITHUB_TOKEN", captured["keys"])
            self.assertNotIn("OPENAI_API_KEY", captured["keys"])

    def test_fake_child_is_reaped_after_timeout(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner timeout fixture ") as raw:
            root = Path(raw)
            executable = root / "sleeping fake docker"
            child_pid_file = root / "child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                f"sleep 60 & child=$!; printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}; wait\n"
            )
            executable.chmod(0o700)
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded("fake-timeout-fixture", [str(executable)], {"PATH": "/usr/bin:/bin"}, root / "timeout.log", 1)
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.05)
            else:
                self.fail(f"timed-out child process still exists: {child_pid}")

    def test_git_archive_uses_allowlist_and_excludes_worktree_extras(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner archive fixture with spaces ") as raw:
            root = Path(raw)
            repo = root / "repo with spaces"
            repo.mkdir()
            git_home = root / "isolated git home"
            git_home.mkdir()
            env = runner.clean_git_env(git_home)
            subprocess.run(["/usr/bin/git", "init", "--quiet", str(repo)], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.name", "Fixture"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.email", "fixture@example.invalid"], check=True, env=env)
            fixture_files = {
                ".dockerignore": ".git\n",
                "Dockerfile": "FROM scratch\n",
                "caveman-config.json": '{"defaultMode":"ultra"}\n',
                "AGENTS.md.d/caveman.md": "Fixture instructions\n",
                "AGENTS.md.d/token-tools.md": "Fixture tool rules\n",
                "jackin-toolchain/mise.toml": "[tools]\n",
                "jackin-toolchain/rust-toolchain.toml": "[toolchain]\nchannel = \"1.98.1\"\n",
                "maintained-image-build/skills-cli/package.json": '{"name":"fixture"}\n',
                "maintained-image-build/skills-cli/package-lock.json": '{"lockfileVersion":3}\n',
                "README.md": "Tracked but not part of the build context\n",
            }
            for name, contents in fixture_files.items():
                path = repo / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(contents)
            (repo / "untracked-secret.txt").write_text("must not enter the context\n")
            subprocess.run(["/usr/bin/git", "-C", str(repo), "add", "--all"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "commit", "--quiet", "-m", "fixture"], check=True, env=env)
            commit = subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
                env=env,
            ).stdout.strip()
            context = root / "context with spaces"
            manifest = runner.archive_context(repo, commit, context, git_home)
            files = {entry["path"] for entry in manifest["files"]}
            self.assertEqual(files, runner.REQUIRED_FILES)
            self.assertFalse((context / "README.md").exists())
            self.assertFalse((context / "untracked-secret.txt").exists())

    def test_probe_script_is_bash_syntax_valid_and_never_invokes_context7_or_skills(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory())
        checked = subprocess.run(["/bin/bash", "-n"], input=script, capture_output=True)
        self.assertEqual(checked.returncode, 0, checked.stderr.decode())
        source = script.decode()
        self.assertIn("mise exec --deny-net -- mbx build", source)
        self.assertIn("mise exec --deny-net -- cargo build", source)
        self.assertIn("ctx7 CLI not invoked", source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/ctx7" --', source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/skills" add', source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
