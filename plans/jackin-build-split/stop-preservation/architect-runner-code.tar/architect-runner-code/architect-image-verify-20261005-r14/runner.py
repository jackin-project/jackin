#!/usr/bin/env python3
"""Build and inspect one reviewed Architect image without importing host state."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
from typing import Sequence


REPO = Path("/root/Projects/tailrocks/jackin-project/jackin-the-architect-task")
WORK = Path("/root/.velnor-work/architect-image-verify-20261005-r14")
INVENTORY = WORK / "payload-files.sha256"
INVENTORY_SHA256 = "d4a54b992a0505766c89f544df714d0e58553e88ac53ec5a69c521e8fa61936b"
REVIEWED_SOURCE_COMMIT = "3c9d54642f3a6ea55ccb06c36bc4b204cde1d54c"
REVIEWED_SOURCE_TREE = "f073b27527b0f039c7fe6882575471bfe12504f1"
CARGO_CRATE_AUDIT = WORK / "cargo-crate-archive-audit.tsv"
CARGO_CRATE_AUDIT_SHA256 = "2e6234182d0d1ad111abdff86ab7f0807a576ab3d85ebc0d373b4de5c5bfbe24"
PREBUILT_ASSET_AUDIT = WORK / "prebuilt-asset-audit.tsv"
PREBUILT_ASSET_AUDIT_SHA256 = "a465ae0d0d0ffc0795d0ffcd0ce90d5cdd14aa2c64c9a6175e18ff2ff05e14b7"
PREBUILT_MEMBER_AUDIT = WORK / "prebuilt-archive-members.tsv"
PREBUILT_MEMBER_AUDIT_SHA256 = "ae33d1b307e6f7cd5d9a543ba446d6170fa6b0bb344b75d0a15bfd4f02cf1246"
SOURCE_CONTEXT_PATHS = (
    ".dockerignore",
    "Dockerfile",
    "caveman-config.json",
    "AGENTS.md.d",
    "jackin-toolchain",
    "maintained-image-build/skills-cli/package.json",
    "maintained-image-build/skills-cli/package-lock.json",
)
EXACT_FILES = {
    ".dockerignore",
    "Dockerfile",
    "caveman-config.json",
    "maintained-image-build/skills-cli/package.json",
    "maintained-image-build/skills-cli/package-lock.json",
}
ALLOWED_PREFIXES = ("AGENTS.md.d/", "jackin-toolchain/")
REQUIRED_FILES = {
    ".dockerignore",
    "Dockerfile",
    "caveman-config.json",
    "AGENTS.md.d/caveman.md",
    "AGENTS.md.d/token-tools.md",
    "jackin-toolchain/mise.toml",
    "jackin-toolchain/rust-toolchain.toml",
    "maintained-image-build/skills-cli/package.json",
    "maintained-image-build/skills-cli/package-lock.json",
}
GIT_BIN = Path("/usr/bin/git")
BUILD_JOBS = "4"
MISE_JOBS = "1"
RUNTIME_CPUS = "4"
RUNTIME_MEMORY = "4g"
RUNTIME_TMPFS = "/tmp:rw,noexec,nosuid,nodev,size=2g"
PROBE_HOME_ROOT = "/home/agent/.cache/architect-image-probe"
BUILD_MEMORY = "32g"
BUILD_CPU_QUOTA = "400000"
BUILD_CPU_PERIOD = "100000"
BUILD_TIMEOUT_SECONDS = 4 * 60 * 60
PROBE_TIMEOUT_SECONDS = 10 * 60
PROCESS_TERM_GRACE_SECONDS = 1.0
CARGO_TOOL_VERSIONS = {
    "cargo-audit": "0.22.2",
    "cargo-deny": "0.20.2",
    "cargo-dylint": "6.0.4",
    "cargo-fuzz": "0.13.2",
    "cargo-hack": "0.6.45",
    "cargo-hakari": "0.9.38",
    "cargo-llvm-cov": "0.8.7",
    "cargo-mutants": "27.1.0",
    "cargo-shear": "1.13.4",
    "cargo-zigbuild": "0.23.0",
    "codebook-lsp": "0.3.42",
    "dylint-link": "6.0.4",
    "sccache": "0.17.0",
}
MBX_STATS_PARSER_JS = r'''const fs = require("node:fs");
const report = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
if (report === null || typeof report !== "object" || Array.isArray(report)) {
  throw new Error("MBX stats report must be a JSON object");
}
if (report.version !== 5) throw new Error(`unsupported MBX stats schema: ${report.version}`);
const counters = ["hits", "misses", "unconsulted", "verifications"];
for (const field of counters) {
  if (!Number.isSafeInteger(report[field]) || report[field] < 0) {
    throw new Error(`invalid MBX stats counter: ${field}`);
  }
}
if (report.bypasses === null || typeof report.bypasses !== "object" || Array.isArray(report.bypasses)) {
  throw new Error("MBX stats bypasses must be an object");
}
const bypasses = Object.entries(report.bypasses).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
let bypassActions = 0;
for (const [reason, count] of bypasses) {
  if (!Number.isSafeInteger(count) || count < 0) {
    throw new Error(`invalid MBX bypass counter: ${reason}`);
  }
  bypassActions += count;
  if (!Number.isSafeInteger(bypassActions)) {
    throw new Error("MBX bypass counter total exceeds the safe integer range");
  }
}
const totalActions = report.hits + report.misses + report.unconsulted + report.verifications + bypassActions;
if (!Number.isSafeInteger(totalActions) || totalActions < 1) {
  throw new Error("MBX stats report has no accounted actions");
}
process.stdout.write([
  report.version,
  report.hits,
  report.misses,
  report.unconsulted,
  report.verifications,
  bypassActions,
  JSON.stringify(bypasses),
].join("\t") + "\n");'''
CARGO_CRATE_SHA256 = {
    "cargo-fuzz": "5acfd01930e49823e58c30dd8012d3338a620377d7c7d4cc140ca4b2169400e2",
    "cargo-mutants": "07072e7bcdeb425d5e5fdbfd9f15a2c749e23cb2edf5ef40aee5876760ae1cf9",
}
MBX_CARGO_INSTALLS = (
    'install_mbx_cargo_tool cargo-fuzz "${cargo_fuzz_version}"',
    'install_mbx_cargo_tool cargo-mutants "${cargo_mutants_version}"',
)
PREBUILT_CARGO_INSTALLS = (
    'install_prebuilt_cargo_tool cargo-audit "${cargo_audit_version}"',
    'install_prebuilt_cargo_tool cargo-deny "${cargo_deny_version}"',
    'install_prebuilt_cargo_tool cargo-dylint "${cargo_dylint_version}"',
    'install_prebuilt_cargo_tool cargo-hack "${cargo_hack_version}"',
    'install_prebuilt_cargo_tool cargo-hakari "${cargo_hakari_version}"',
    'install_prebuilt_cargo_tool cargo-llvm-cov "${cargo_llvm_cov_version}"',
    'install_prebuilt_cargo_tool cargo-shear "${cargo_shear_version}"',
    'install_prebuilt_cargo_tool cargo-zigbuild "${cargo_zigbuild_version}"',
    'install_prebuilt_cargo_tool codebook-lsp "${codebook_lsp_version}"',
    'install_prebuilt_cargo_tool dylint-link "${dylint_link_version}"',
)


class RunnerError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_payload_inventory(path: Path = INVENTORY) -> dict[str, dict[str, str]]:
    if sha256_file(path) != INVENTORY_SHA256:
        raise RunnerError(f"payload inventory digest mismatch: {path}")
    skills: dict[str, dict[str, str]] = {"caveman": {}, "jackin-dev": {}, "shadcn-improve": {}}
    for number, line in enumerate(path.read_text().splitlines(), start=1):
        fields = line.split("\t")
        if len(fields) != 3:
            raise RunnerError(f"malformed payload inventory line {number}")
        category, source_path, digest = fields
        if category not in skills or not re.fullmatch(r"[0-9a-f]{64}", digest):
            continue
        if not source_path.endswith("/SKILL.md"):
            continue
        name = PurePosixPath(source_path).parent.name
        if not re.fullmatch(r"[a-z0-9-]+", name) or name in skills[category]:
            raise RunnerError(f"invalid or duplicate skill path on inventory line {number}")
        skills[category][name] = digest
    expected = {"caveman": 20, "jackin-dev": 11, "shadcn-improve": 1}
    observed = {key: len(value) for key, value in skills.items()}
    if observed != expected:
        raise RunnerError(f"payload inventory skill counts differ: {observed}")
    return skills


def validate_cargo_crate_sources(path: Path = CARGO_CRATE_AUDIT) -> dict[str, str]:
    if sha256_file(path) != CARGO_CRATE_AUDIT_SHA256:
        raise RunnerError(f"Cargo archive audit digest mismatch: {path}")
    lines = path.read_text().splitlines()
    expected_header = (
        "name\tversion\tsha256\tarchive_bytes\tmembers\tCargo.toml"
        "\tCargo.lock\tunsafe_members"
    )
    if not lines or lines[0] != expected_header:
        raise RunnerError("Cargo archive audit header differs")
    hashes: dict[str, str] = {}
    for number, line in enumerate(lines[1:], start=2):
        fields = line.split("\t")
        if len(fields) != 8:
            raise RunnerError(f"malformed Cargo archive audit row {number}")
        name, version, digest, byte_count, member_count, manifest, lockfile, unsafe = fields
        if name not in CARGO_CRATE_SHA256 or name in hashes:
            raise RunnerError(f"unexpected or duplicate Cargo archive row {number}: {name}")
        if digest != CARGO_CRATE_SHA256[name] or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise RunnerError(f"Cargo archive digest differs for {name}@{version}")
        if CARGO_TOOL_VERSIONS.get(name) != version:
            raise RunnerError(f"Cargo archive version differs for {name}: {version}")
        if not byte_count.isdecimal() or not member_count.isdecimal():
            raise RunnerError(f"invalid Cargo archive counts on row {number}")
        if (manifest, lockfile, unsafe) != ("yes", "yes", "0"):
            raise RunnerError(f"Cargo archive layout record failed on row {number}")
        archive = WORK / "assets" / "crates" / f"{name}-{version}.crate"
        if sha256_file(archive) != digest:
            raise RunnerError(f"Cargo archive bytes differ for {name}@{version}")
        root_name = f"{name}-{version}"
        with tarfile.open(archive, mode="r:gz") as bundle:
            members = bundle.getmembers()
        observed_files: set[str] = set()
        for member in members:
            parts = member.name.split("/")
            if (
                member.name.startswith("/")
                or not parts
                or parts[0] != root_name
                or any(part in ("", ".", "..") for part in parts)
                or member.issym()
                or member.islnk()
                or member.isdev()
                or member.isfifo()
            ):
                raise RunnerError(f"unsafe Cargo archive member: {name}@{version}:{member.name}")
            if member.isfile():
                observed_files.add(member.name)
        if (
            len(members) != int(member_count)
            or len(archive.read_bytes()) != int(byte_count)
            or f"{root_name}/Cargo.toml" not in observed_files
            or f"{root_name}/Cargo.lock" not in observed_files
        ):
            raise RunnerError(f"Cargo archive contents differ for {name}@{version}")
        hashes[name] = digest
    if hashes != CARGO_CRATE_SHA256:
        raise RunnerError("Cargo archive audit does not cover the exact pinned tool set")
    return hashes


def validate_prebuilt_assets() -> dict[str, dict[str, str]]:
    if sha256_file(PREBUILT_ASSET_AUDIT) != PREBUILT_ASSET_AUDIT_SHA256:
        raise RunnerError(f"prebuilt asset audit digest mismatch: {PREBUILT_ASSET_AUDIT}")
    if sha256_file(PREBUILT_MEMBER_AUDIT) != PREBUILT_MEMBER_AUDIT_SHA256:
        raise RunnerError(f"prebuilt member audit digest mismatch: {PREBUILT_MEMBER_AUDIT}")
    with PREBUILT_ASSET_AUDIT.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        expected_columns = {
            "package",
            "version",
            "repo",
            "release_tag",
            "target_triple",
            "asset_filename",
            "asset_url",
            "official_sha256",
            "download_sha256",
            "executable_member",
            "download_size_bytes",
            "member_count",
            "result",
        }
        if set(reader.fieldnames or ()) != expected_columns:
            raise RunnerError("prebuilt asset audit header differs")
        assets: dict[str, dict[str, str]] = {}
        for number, row in enumerate(reader, start=2):
            package = row["package"]
            version = row["version"]
            target = row["target_triple"]
            arch = "amd64" if target.startswith("x86_64-") else "arm64" if target.startswith("aarch64-") else ""
            key = f"{package}@{version}:{arch}"
            if (
                not arch
                or package not in CARGO_TOOL_VERSIONS
                or CARGO_TOOL_VERSIONS[package] != version
                or key in assets
                or row["result"] != "PASS"
                or row["official_sha256"] != row["download_sha256"]
                or not re.fullmatch(r"[0-9a-f]{64}", row["official_sha256"])
                or not row["asset_url"].startswith("https://github.com/")
                or not row["download_size_bytes"].isdecimal()
                or not row["member_count"].isdecimal()
                or not row["executable_member"]
            ):
                raise RunnerError(f"invalid or duplicate prebuilt asset audit row {number}: {key}")
            expected_url = (
                f"https://github.com/{row['repo']}/releases/download/"
                f"{row['release_tag']}/{row['asset_filename']}"
            )
            if row["asset_url"] != expected_url:
                raise RunnerError(f"prebuilt asset URL disagrees with release fields: {key}")
            assets[key] = row
    expected_keys = {
        f"{name}@{version}:{arch}"
        for name, version in CARGO_TOOL_VERSIONS.items()
        if name != "sccache"
        for arch in (("amd64",) if name in {"cargo-fuzz", "cargo-mutants"} else ("amd64", "arm64"))
    }
    if assets.keys() != expected_keys:
        raise RunnerError(
            f"prebuilt asset audit coverage differs: missing={sorted(expected_keys - assets.keys())}, "
            f"extra={sorted(assets.keys() - expected_keys)}"
        )
    with PREBUILT_MEMBER_AUDIT.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        member_rows = list(reader)
    if len(member_rows) != len(assets):
        raise RunnerError("prebuilt archive member audit row count differs")
    member_labels = set()
    for row in member_rows:
        label = row["label"]
        if label.endswith("_x86_64"):
            package = label[: -len("_x86_64")]
            arch = "amd64"
        elif label.endswith("_aarch64"):
            package = label[: -len("_aarch64")]
            arch = "arm64"
        else:
            package = ""
            arch = ""
        key = f"{package}@{next((item['version'] for item in assets.values() if item['package'] == package), '')}:{arch}"
        item = assets.get(key)
        if (
            not item
            or label in member_labels
            or row["official_expected"] != "MATCH"
            or row["path_safety"] != "SAFE"
            or row["types"] not in {"file", "dir,file"}
            or item["official_sha256"] != row["sha256"]
            or item["executable_member"] not in row["files"].split(",")
        ):
            raise RunnerError(f"prebuilt member audit failed for {label}")
        member_labels.add(label)
    return assets


def validate_prebuilt_dockerfile_pins(
    source: str, assets: dict[str, dict[str, str]]
) -> None:
    function_start = source.find("    install_prebuilt_cargo_tool()")
    function_end = source.find("    install_mbx_cargo_tool()", function_start)
    if function_start < 0 or function_end < 0:
        raise RunnerError("prebuilt Cargo installer function is absent")
    function = source[function_start:function_end]
    branch_pattern = re.compile(
        r"(?m)^\s+([a-z][a-z0-9-]+@\d+\.\d+\.\d+:(?:amd64|arm64))\) \\\s*$"
    )
    branches = list(branch_pattern.finditer(function))
    observed_keys = [match.group(1) for match in branches]
    if len(observed_keys) != len(set(observed_keys)) or set(observed_keys) != set(assets):
        raise RunnerError("Dockerfile prebuilt asset cases differ from the reviewed release audit")
    field_names = ("asset_repo", "release_path", "asset_filename", "asset_sha256", "executable_member")
    for branch in branches:
        key = branch.group(1)
        next_branch = function.find("                ;; \\\n", branch.end())
        if next_branch < 0:
            raise RunnerError(f"Dockerfile prebuilt case has no terminator: {key}")
        block = function[branch.start():next_branch]
        found: dict[str, str] = {}
        for field in field_names:
            match = re.search(rf"\b{field}=([^;\\\n]+)", block)
            if not match:
                raise RunnerError(f"Dockerfile prebuilt case lacks {field}: {key}")
            found[field] = match.group(1).strip()
        record = assets[key]
        actual_url = (
            f"https://github.com/{found['asset_repo']}/releases/download/"
            f"{found['release_path']}/{found['asset_filename']}"
        )
        if (
            actual_url != record["asset_url"]
            or found["asset_sha256"] != record["official_sha256"]
            or found["executable_member"] != record["executable_member"]
        ):
            raise RunnerError(f"Dockerfile prebuilt asset differs from reviewed audit: {key}")


def payload_digest(category: str, source_path: str, path: Path = INVENTORY) -> str:
    if sha256_file(path) != INVENTORY_SHA256:
        raise RunnerError(f"payload inventory digest mismatch: {path}")
    for line in path.read_text().splitlines():
        fields = line.split("\t")
        if len(fields) == 3 and fields[0] == category and fields[1] == source_path:
            return fields[2]
    raise RunnerError(f"payload digest is absent: {category}:{source_path}")


def clean_git_env(home: Path) -> dict[str, str]:
    return {
        "HOME": str(home),
        "PATH": "/usr/bin:/bin",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": os.devnull,
        "GIT_TERMINAL_PROMPT": "0",
        "GIT_OPTIONAL_LOCKS": "0",
        "GIT_LFS_SKIP_SMUDGE": "1",
        "GIT_NO_REPLACE_OBJECTS": "1",
    }


def git_output(repo: Path, args: Sequence[str], home: Path, git_bin: Path = GIT_BIN) -> str:
    completed = subprocess.run(
        [str(git_bin), "-C", str(repo), *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=clean_git_env(home),
        text=True,
    )
    return completed.stdout.strip()


def git_bytes(repo: Path, args: Sequence[str], home: Path) -> bytes:
    completed = subprocess.run(
        [str(GIT_BIN), "-C", str(repo), *args],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=clean_git_env(home),
    )
    if completed.returncode != 0:
        detail = completed.stderr.decode("utf-8", "replace").strip()
        raise RunnerError(f"Git command failed ({completed.returncode}): {args!r}: {detail}")
    return completed.stdout


def git_object_digest(kind: str, data: bytes, object_format: str) -> str:
    if object_format not in {"sha1", "sha256"}:
        raise RunnerError(f"unsupported Git object format: {object_format}")
    header = f"{kind} {len(data)}\0".encode("ascii")
    return hashlib.new(object_format, header + data).hexdigest()


def verify_source(repo: Path, expected_commit: str, home: Path) -> tuple[str, str]:
    if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", expected_commit):
        raise RunnerError("source commit must be a full lowercase Git SHA")
    commit = git_output(repo, ["rev-parse", "--verify", f"{expected_commit}^{{commit}}"], home)
    if commit != expected_commit:
        raise RunnerError(f"Git resolved a different source commit: {commit}")
    object_format = git_output(repo, ["rev-parse", "--show-object-format"], home)
    if len(commit) != {"sha1": 40, "sha256": 64}.get(object_format):
        raise RunnerError(f"commit SHA length does not match Git object format {object_format}")
    commit_data = git_bytes(repo, ["cat-file", "commit", commit], home)
    if git_object_digest("commit", commit_data, object_format) != commit:
        raise RunnerError("raw commit contents do not match the pinned commit ID")
    tree_line = next((line for line in commit_data.splitlines() if line.startswith(b"tree ")), None)
    if tree_line is None:
        raise RunnerError("pinned commit has no root tree")
    tree = tree_line[5:].decode("ascii", "strict")
    if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", tree):
        raise RunnerError("pinned commit contains an invalid root tree ID")
    tree_data = git_bytes(repo, ["cat-file", "tree", tree], home)
    if git_object_digest("tree", tree_data, object_format) != tree:
        raise RunnerError("raw root tree contents do not match the pinned tree ID")
    if expected_commit == REVIEWED_SOURCE_COMMIT and tree != REVIEWED_SOURCE_TREE:
        raise RunnerError(f"reviewed source tree mismatch: {tree}")
    return commit, tree


def path_is_allowed(path: str) -> bool:
    if path in EXACT_FILES:
        return True
    return any(path.startswith(prefix) and len(path) > len(prefix) for prefix in ALLOWED_PREFIXES)


def materialize_tree_context(repo: Path, tree: str, destination: Path, git_home: Path) -> dict[str, object]:
    if destination.exists():
        raise RunnerError(f"context destination already exists: {destination}")
    destination.mkdir(parents=True, mode=0o700)
    object_format = git_output(repo, ["rev-parse", "--show-object-format"], git_home)
    if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", tree):
        raise RunnerError("context source must be a full lowercase Git tree ID")
    if len(tree) != {"sha1": 40, "sha256": 64}.get(object_format):
        raise RunnerError("tree SHA length does not match Git object format")
    tree_data = git_bytes(repo, ["cat-file", "tree", tree], git_home)
    if git_object_digest("tree", tree_data, object_format) != tree:
        raise RunnerError("raw context tree contents do not match the pinned tree ID")
    listing = git_bytes(
        repo,
        ["ls-tree", "-rz", "--full-tree", "-r", tree, "--", *SOURCE_CONTEXT_PATHS],
        git_home,
    )
    seen: set[str] = set()
    for record in listing.split(b"\0"):
        if not record:
            continue
        try:
            metadata, raw_path = record.split(b"\t", 1)
            mode_bytes, kind_bytes, oid_bytes = metadata.split(b" ")
            name = raw_path.decode("utf-8", "strict")
            mode = mode_bytes.decode("ascii")
            kind = kind_bytes.decode("ascii")
            oid = oid_bytes.decode("ascii")
        except (ValueError, UnicodeError) as error:
            raise RunnerError(f"malformed raw Git tree entry: {record!r}") from error
        path = PurePosixPath(name)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise RunnerError(f"unsafe path in Git tree: {name!r}")
        if not path_is_allowed(name):
            raise RunnerError(f"unexpected path in Git tree: {name}")
        if name in seen:
            raise RunnerError(f"duplicate path in Git tree: {name}")
        if kind != "blob" or mode not in {"100644", "100755"}:
            raise RunnerError(f"unsupported Git tree entry: {mode} {kind} {name}")
        if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", oid):
            raise RunnerError(f"invalid Git blob ID: {name}")
        if len(oid) != {"sha1": 40, "sha256": 64}.get(object_format):
            raise RunnerError(f"blob SHA length does not match Git object format: {name}")
        data = git_bytes(repo, ["cat-file", "blob", oid], git_home)
        if git_object_digest("blob", data, object_format) != oid:
            raise RunnerError(f"raw blob contents do not match the pinned blob ID: {name}")
        target = destination.joinpath(*path.parts)
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        file_mode = 0o755 if mode == "100755" else 0o644
        descriptor = os.open(target, flags, file_mode)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
        target.chmod(file_mode)
        seen.add(name)
    missing = REQUIRED_FILES - seen
    if missing:
        raise RunnerError(f"required source files are missing from Git tree: {sorted(missing)}")
    return context_manifest(destination)


def context_manifest(destination: Path) -> dict[str, object]:
    entries: list[dict[str, object]] = []
    for current, directory_names, file_names in os.walk(destination, followlinks=False):
        directory_names.sort()
        file_names.sort()
        for name in [*directory_names, *file_names]:
            path = Path(current) / name
            relative = path.relative_to(destination).as_posix()
            allowed_directory = path.is_dir() and relative in {
                "AGENTS.md.d",
                "jackin-toolchain",
                "maintained-image-build",
                "maintained-image-build/skills-cli",
            }
            if path.is_symlink() or not (path_is_allowed(relative) or allowed_directory):
                raise RunnerError(f"unexpected context entry: {relative}")
            if path.is_file():
                mode = stat.S_IMODE(path.stat().st_mode)
                entries.append({"path": relative, "mode": f"{mode:04o}", "sha256": sha256_file(path)})
    payload = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()
    return {"files": entries, "manifest_sha256": sha256_bytes(payload)}


def validate_dockerfile_contract(dockerfile: Path) -> None:
    source = dockerfile.read_text()
    crate_hashes = validate_cargo_crate_sources()
    assets = validate_prebuilt_assets()
    validate_prebuilt_dockerfile_pins(source, assets)
    required = (
        'add "${shadcn_source}" -a claude-code --yes --global',
        'add "${shadcn_source}" -a codex --yes --global',
        'add "${shadcn_source}" -a amp --yes --global',
        'add "${shadcn_source}" -a opencode --yes --global',
        'add "${shadcn_source}" -a kimi-code-cli --yes --global',
        'add "${caveman_source}" -a codex --yes --global',
        'add "${caveman_source}" -a amp --yes --global',
        'add "${jackin_source}" -s \'*\' -a codex --yes --global',
        'add "${jackin_source}" -s \'*\' -a amp --yes --global',
        "ENV CAVEMAN_DEFAULT_MODE=ultra",
        "ARG CARGO_BUILD_JOBS=4",
        "ARG MISE_JOBS=1",
        'MISE_DISABLE_UPDATE_WARNING=1 "${mise_archive}" --version',
        'case "${mise_version}" in',
        '"${MISE_VERSION} "*) ;;',
        'sccache_sha256=67c4a96dd237c1f518f6b36083f270f9976d516f1e57fce891755ea782e50006',
        'sccache_sha256=821a86343191aa1cbab74bd42f9e93c9a63bf85e4742945f40d3ae84193c1c77',
        'umask 022;',
        'curl -q -fsSL --proto',
        '--netrc-file /dev/null "${asset_url}" -o "${archive}"',
        'install_root="${HOME}/.local/share/mise/installs/${package}/${version}/bin"',
        *PREBUILT_CARGO_INSTALLS,
        'https://static.crates.io/crates/${package}/${package}-${version}.crate',
        '--no-same-owner --no-same-permissions',
        'mise exec -C /tmp/jackin-mise -- mbx install',
        '--locked --path "${source_root}" --root "${install_root}"',
        'test -s "${source_root}/Cargo.toml"',
        'test -s "${source_root}/Cargo.lock"',
        'MISE_CARGO_BINSTALL_ONLY=1 mise install',
        *MBX_CARGO_INSTALLS,
    )
    missing = [line for line in required if line not in source]
    if missing:
        raise RunnerError(f"reviewed Dockerfile contract changed: missing {missing}")
    continued_source = re.sub(r"\\\n[ \t]*", " ", source)
    source_archive_extract = (
        r'tar --extract --file "\$\{archive_path\}"\s+'
        r'--directory "\$\{source_dir\}"\s+'
        r'--no-same-owner --no-same-permissions'
    )
    if not re.search(source_archive_extract, continued_source):
        raise RunnerError("pinned source extraction must mask archived permission bits")
    tar_commands = (
        r'tar --extract --xz\s+--file "\$\{archive\}" --to-stdout\s+'
        r'--no-wildcards -- "\$\{executable_member\}" > "\$\{binary\}"',
        r'tar --extract --gzip\s+--file "\$\{archive\}" --to-stdout\s+'
        r'--no-wildcards -- "\$\{executable_member\}" > "\$\{binary\}"',
    )
    if any(not re.search(pattern, continued_source) for pattern in tar_commands):
        raise RunnerError("verified tar extraction commands differ from the audited member contract")
    if 'mbx install --locked --root "${install_root}" "${package}@${version}"' in source:
        raise RunnerError("registry Cargo install would bypass the MBX cache")
    if not re.search(
        r'(?s)case "\$\{TARGETARCH\}" in \\\s*amd64\) \\\s*'
        r'install_prebuilt_cargo_tool cargo-fuzz .*?'
        r'install_prebuilt_cargo_tool cargo-mutants .*?'
        r'arm64\) \\\s*install_mbx_cargo_tool cargo-fuzz .*?'
        r'install_mbx_cargo_tool cargo-mutants',
        source,
    ):
        raise RunnerError("Cargo fuzz/mutants architecture routes differ from audited asset coverage")
    found_hashes: dict[str, str] = {}
    for line in source.splitlines():
        match = re.search(
            r"^\s*([a-z][a-z0-9-]+)@(\d+\.\d+\.\d+)\) crate_sha256=([0-9a-f]{64}) ;;\s*\\?$",
            line,
        )
        if match:
            package, version, digest = match.groups()
            if package in found_hashes or CARGO_TOOL_VERSIONS.get(package) != version:
                raise RunnerError(f"unexpected or duplicate Cargo crate source pin: {line.strip()}")
            found_hashes[package] = digest
    if found_hashes != crate_hashes:
        raise RunnerError("Dockerfile crates.io checksum pins differ from audited source archives")


def parse_buildx_plugin_info(output: str) -> dict[str, str]:
    plugins: list[object] | None = None
    for line in reversed(output.splitlines()):
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, list):
            plugins = parsed
            break
    if plugins is None:
        raise RunnerError("Docker info did not report client CLI plugins as JSON")
    buildx = [
        entry
        for entry in plugins
        if isinstance(entry, dict) and entry.get("Name") == "buildx"
    ]
    if len(buildx) != 1:
        raise RunnerError(f"expected one Docker Buildx CLI plugin, found {len(buildx)}")
    plugin = buildx[0]
    path = plugin.get("Path")
    version = plugin.get("Version")
    if not isinstance(path, str) or not Path(path).is_absolute():
        raise RunnerError("Docker Buildx plugin path is absent or not absolute")
    if not isinstance(version, str) or not version:
        raise RunnerError("Docker Buildx plugin version is absent")
    return {"path": path, "version": version}


def require_buildx_resource_flag(help_text: str) -> None:
    if not re.search(r"(?m)^\s*--resource\s+\S+", help_text):
        raise RunnerError("Docker Buildx help does not expose the --resource option")


def clean_docker_env(private_home: Path, docker_config: Path, docker_bin: Path) -> dict[str, str]:
    docker_path = str(docker_bin.parent)
    return {
        "HOME": str(private_home),
        "DOCKER_CONFIG": str(docker_config),
        "DOCKER_BUILDKIT": "1",
        "PATH": f"{docker_path}:/usr/bin:/bin",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TZ": "UTC",
    }


def make_build_argv(docker_bin: Path, image_tag: str, context: Path) -> list[str]:
    return [
        str(docker_bin),
        "buildx",
        "build",
        "--platform=linux/amd64",
        "--tag",
        image_tag,
        "--load",
        "--file",
        str(context / "Dockerfile"),
        "--progress=plain",
        "--resource",
        f"memory={BUILD_MEMORY}",
        "--resource",
        f"cpu-quota={BUILD_CPU_QUOTA}",
        "--resource",
        f"cpu-period={BUILD_CPU_PERIOD}",
        "--build-arg",
        f"CARGO_BUILD_JOBS={BUILD_JOBS}",
        "--build-arg",
        f"MISE_JOBS={MISE_JOBS}",
        str(context),
    ]


def expected_skill_hashes(skills: dict[str, dict[str, str]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for source in ("caveman", "jackin-dev"):
        for name, digest in skills[source].items():
            if name in result:
                raise RunnerError(f"skill name collision between pinned sources: {name}")
            result[name] = digest
    if "improve" in result:
        raise RunnerError("shadcn skill name collides with existing universal skill")
    result["improve"] = skills["shadcn-improve"]["improve"]
    return result


def make_probe_script(skills: dict[str, dict[str, str]]) -> bytes:
    hashes = expected_skill_hashes(skills)
    rows = "\n".join(f"  [{name}]={digest}" for name, digest in sorted(hashes.items()))
    plugin_digest = payload_digest("caveman", "src/plugins/opencode/plugin.js")
    cargo_tool_rows = "\n".join(
        f"  [{name}]={version}" for name, version in sorted(CARGO_TOOL_VERSIONS.items())
    )
    script = f'''#!/bin/bash
set -euo pipefail
export MISE_EXEC_AUTO_INSTALL=0
export MISE_JOBS={MISE_JOBS}
export CARGO_BUILD_JOBS={BUILD_JOBS}
export CODEX_HOME=/tmp/architect-empty-codex-home
PROBE_ROOT="{PROBE_HOME_ROOT}"
printf 'IMAGE_ID uid=%s gid=%s groups=%s\\n' "$(id -u)" "$(id -g)" "$(id -G)"
create_probe_directories() {{
  local parent umask_before parent_mode_before parent_uid_before parent_gid_before
  parent="$(dirname "$PROBE_ROOT")"
  umask_before="$(umask)"
  if [ -d "$parent" ]; then
    parent_mode_before="$(stat -Lc '%a' "$parent")"
    parent_uid_before="$(stat -Lc '%u' "$parent")"
    parent_gid_before="$(stat -Lc '%g' "$parent")"
  else
    parent_mode_before=absent
    parent_uid_before=absent
    parent_gid_before=absent
  fi
  printf 'PROBE_DIRECTORY_BEFORE path=%s umask=%s parent_mode=%s parent_uid=%s parent_gid=%s\\n' \\
    "$PROBE_ROOT" "$umask_before" "$parent_mode_before" "$parent_uid_before" "$parent_gid_before"
  umask 077
  mkdir -p "$CODEX_HOME" "$PROBE_ROOT"
  printf 'PROBE_DIRECTORY_CREATED path=%s umask=%s parent_mode=%s parent_uid=%s parent_gid=%s mode=%s uid=%s gid=%s\\n' \\
    "$PROBE_ROOT" "$(umask)" "$(stat -Lc '%a' "$parent")" "$(stat -Lc '%u' "$parent")" \\
    "$(stat -Lc '%g' "$parent")" "$(stat -Lc '%a' "$PROBE_ROOT")" \\
    "$(stat -Lc '%u' "$PROBE_ROOT")" "$(stat -Lc '%g' "$PROBE_ROOT")"
}}
create_probe_directories

die() {{ echo "IMAGE_CHECK_FAIL: $*" >&2; exit 1; }}
check_version() {{
  local label="$1" expected_prefix="$2" actual="$3"
  printf 'VERSION %s %s\\n' "$label" "$actual"
  [[ "$actual" == "$expected_prefix"* ]] || die "$label version mismatch: $actual"
}}
check_mbx_stats_report() {{
  local stats_file="$1" label="$2" output schema hits misses unconsulted verifications bypasses bypass_reasons owner mode digest total
  test -f "$stats_file" || die "$label MBX JSON stats report is missing"
  owner="$(stat -Lc '%u' "$stats_file")"
  test "$owner" = "$(id -u)" || die "$label MBX stats report has unexpected owner: $owner"
  mode="$(stat -Lc '%a' "$stats_file")"
  (( (8#$mode & 0022) == 0 )) || die "$label MBX stats report is writable by group/other: $mode"
  digest="$(sha256sum "$stats_file" | awk '{{print $1}}')"
  printf 'MBX_STATS_FILE %s path=%s mode=%s sha256=%s\\n' "$label" "$stats_file" "$mode" "$digest"
  if ! output="$(mise exec --deny-net -- node -e {shlex.quote(MBX_STATS_PARSER_JS)} "$stats_file" 2>&1)"; then
    printf '%s\\n' "$output" >&2
    die "$label MBX JSON stats report is invalid"
  fi
  [[ "$output" != *$'\\n'* ]] || die "$label MBX JSON stats parser emitted multiple lines"
  IFS=$'\\t' read -r schema hits misses unconsulted verifications bypasses bypass_reasons <<<"$output"
  [[ "$schema" = 5 && "$hits" =~ ^[0-9]+$ && "$misses" =~ ^[0-9]+$ && "$unconsulted" =~ ^[0-9]+$ && "$verifications" =~ ^[0-9]+$ && "$bypasses" =~ ^[0-9]+$ && "$bypass_reasons" == \\[*\\] ]] || die "$label MBX JSON stats parser output is invalid"
  total=$((hits + misses + unconsulted + verifications + bypasses))
  test "$total" -gt 0 || die "$label MBX report has no accounted actions"
  MBX_HIT_ACTIONS=$((MBX_HIT_ACTIONS + hits))
  MBX_MISS_ACTIONS=$((MBX_MISS_ACTIONS + misses))
  MBX_UNCONSULTED_ACTIONS=$((MBX_UNCONSULTED_ACTIONS + unconsulted))
  MBX_VERIFICATION_ACTIONS=$((MBX_VERIFICATION_ACTIONS + verifications))
  MBX_BYPASS_ACTIONS=$((MBX_BYPASS_ACTIONS + bypasses))
  printf 'MBX_STATS_RESULT %s schema=%s hits=%s misses=%s unconsulted=%s verifications=%s bypasses=%s reasons=%s\\n' \\
    "$label" "$schema" "$hits" "$misses" "$unconsulted" "$verifications" "$bypasses" "$bypass_reasons"
}}
mountinfo_line_for() {{
  local target="$1"
  awk -v target="$target" '
    {{
      mountpoint = $5
      covers = target == mountpoint || mountpoint == "/" || (index(target, mountpoint) == 1 && substr(target, length(mountpoint) + 1, 1) == "/")
      if (covers && length(mountpoint) > best_length) {{
        best_length = length(mountpoint)
        best_line = $0
      }}
    }}
    END {{ if (best_line == "") exit 1; print best_line }}
  ' "${{MOUNTINFO_PATH:-/proc/self/mountinfo}}"
}}
verify_probe_mounts() {{
  local tmp_line target_line tmp_options target_options
  test "$PROBE_ROOT" = "{PROBE_HOME_ROOT}" || die 'probe root is outside the reviewed home cache path'
  case "$PROBE_ROOT" in /tmp/*) die 'probe root cannot be under the noexec tmpfs' ;; esac
  tmp_line="$(mountinfo_line_for /tmp)" || die 'unable to find /tmp in mountinfo'
  target_line="$(mountinfo_line_for "$PROBE_ROOT")" || die 'unable to find probe target in mountinfo'
  tmp_options="$(awk '{{print $6}}' <<<"$tmp_line")"
  target_options="$(awk '{{print $6}}' <<<"$target_line")"
  printf 'MOUNTINFO tmp path=/tmp line=%s\\n' "$tmp_line"
  printf 'MOUNTINFO target path=%s line=%s\\n' "$PROBE_ROOT" "$target_line"
  case ",$tmp_options," in *",noexec,"*) ;; *) die '/tmp mount is not noexec' ;; esac
  case ",$tmp_options," in *",nosuid,"*) ;; *) die '/tmp mount is not nosuid' ;; esac
  case ",$tmp_options," in *",nodev,"*) ;; *) die '/tmp mount is not nodev' ;; esac
  case ",$target_options," in *",rw,"*) ;; *) die 'probe target mount is not writable' ;; esac
  case ",$target_options," in *",noexec,"*) die 'probe target mount is noexec' ;; esac
}}
MBX_HIT_ACTIONS=0
MBX_MISS_ACTIONS=0
MBX_UNCONSULTED_ACTIONS=0
MBX_VERIFICATION_ACTIONS=0
MBX_BYPASS_ACTIONS=0
test "$(realpath -e "$PROBE_ROOT")" = "$PROBE_ROOT" || die 'probe root resolves outside its expected home cache path'
probe_root_owner="$(stat -Lc '%u' "$PROBE_ROOT")"
test "$probe_root_owner" = "$(id -u)" || die "unexpected probe root owner: $probe_root_owner"
probe_root_mode="$(stat -Lc '%a' "$PROBE_ROOT")"
(( (8#$probe_root_mode & 0022) == 0 )) || die "probe root writable by group/other: $probe_root_mode"
verify_probe_mounts
check_owned_file() {{
  local file="$1" expected="$2" actual owner mode
  test -f "$file" || die "missing file: $file"
  test -r "$file" || die "unreadable file: $file"
  owner="$(stat -Lc '%u' "$file")"
  test "$owner" = "$(id -u)" || die "unexpected owner $owner: $file"
  mode="$(stat -Lc '%a' "$file")"
  (( (8#$mode & 0022) == 0 )) || die "writable by group/other: $file ($mode)"
  actual="$(sha256sum "$file" | awk '{{print $1}}')"
  test "$actual" = "$expected" || die "digest mismatch: $file ($actual)"
  printf 'FILE_OK %s mode=%s sha256=%s\\n' "$file" "$mode" "$actual"
}}

mise_path="$(command -v mise)"
test -x "$mise_path" || die 'mise path is not executable'
test "$(id -u)" = '1000' || die "unexpected image user: $(id -u)"
check_version mise '2026.9.18 ' "$(mise --version)"
check_version rustc 'rustc 1.98.1' "$(mise exec --deny-net -- rustc --version)"
check_version node 'v24.21.0' "$(mise exec --deny-net -- node --version)"
check_version npm '11.19.0' "$(mise exec --deny-net -- npm --version)"
check_version mbx 'mbx 1.22.0' "$(mise exec --deny-net -- mbx --version)"
verify_cargo_tools() {{
declare -A expected_cargo_tool_version=(
{cargo_tool_rows}
)
for tool in "${{!expected_cargo_tool_version[@]}}"; do
  tool_path="$(mise which "$tool")"
  tool_version="$(mise which "$tool" --version)"
  test "$tool_version" = "${{expected_cargo_tool_version[$tool]}}" || die "$tool version mismatch: $tool_version"
  expected_tool_path="$HOME/.local/share/mise/installs/$tool/$tool_version/bin/$tool"
  test "$tool_path" = "$expected_tool_path" || die "$tool resolved outside its pinned Mise install: $tool_path"
  test -x "$tool_path" || die "$tool path is not executable: $tool_path"
  tool_sha256="$(sha256sum "$tool_path" | awk '{{print $1}}')"
  printf 'CARGO_TOOL %s version=%s path=%s sha256=%s\\n' "$tool" "$tool_version" "$tool_path" "$tool_sha256"
done
}}
verify_cargo_tools
printf 'TOOL_PATH mise=%s cargo=%s mbx=%s node=%s npm=%s\\n' \\
  "$mise_path" \\
  "$(mise exec --deny-net -- sh -c 'command -v cargo')" \\
  "$(mise exec --deny-net -- sh -c 'command -v mbx')" \\
  "$(mise exec --deny-net -- sh -c 'command -v node')" \\
  "$(mise exec --deny-net -- sh -c 'command -v npm')"

mise_config="$HOME/.config/mise/config.toml"
grep -Eq 'mr_boxington[[:space:]]*=[[:space:]]*true' "$mise_config" || die 'mr_boxington Rust option is absent'
grep -Eq 'mr-boxington[[:space:]]*=[[:space:]]*"1\\.22\\.0"' "$mise_config" || die 'mr-boxington version pin is absent'
cargo_dispatch="$(mise exec --deny-net -- sh -c 'command -v cargo')"
verify_native_cargo_wrapper() {{
  local mise_executable="$1" cargo_dispatch="$2"
  local expected_dispatch="$HOME/.local/share/mise/command-wrappers/bin/cargo"
  local wrapper_real mise_real
  test "$cargo_dispatch" = "$expected_dispatch" || die "Cargo does not resolve through Mise native wrapper: $cargo_dispatch"
  test -x "$cargo_dispatch" || die 'Mise Cargo wrapper is not executable'
  wrapper_real="$(readlink -f "$cargo_dispatch")"
  mise_real="$(readlink -f "$mise_executable")"
  test "$wrapper_real" = "$mise_real" || die "Cargo wrapper does not enter the verified Mise executable: $wrapper_real"
  printf 'MBX_WRAPPER path=%s real=%s option=mr_boxington:true\\n' "$cargo_dispatch" "$wrapper_real"
}}
verify_native_cargo_wrapper "$mise_path" "$cargo_dispatch"
check_version wrapped-cargo 'cargo ' "$(mise exec --deny-net -- cargo --version)"

printf 'CODEX_RUNTIME NOT_RUN; installed by Jackin in the derived agent image\\n'
test -x "$HOME/.local/share/architect-node-tools/node_modules/.bin/skills" || die 'skills CLI path is missing'
test -x "$HOME/.local/share/architect-node-tools/node_modules/.bin/ctx7" || die 'ctx7 package executable is missing'
skills_version="$(node -e 'process.stdout.write(require(process.argv[1]).version)' "$HOME/.local/share/architect-node-tools/node_modules/skills/package.json")"
ctx7_version="$(node -e 'process.stdout.write(require(process.argv[1]).version)' "$HOME/.local/share/architect-node-tools/node_modules/ctx7/package.json")"
test "$skills_version" = '1.5.22' || die "skills package version mismatch: $skills_version"
test "$ctx7_version" = '0.5.11' || die "ctx7 package version mismatch: $ctx7_version"
printf 'PACKAGE_VERSION skills=%s ctx7=%s (ctx7 CLI not invoked)\\n' "$skills_version" "$ctx7_version"

test "$CAVEMAN_DEFAULT_MODE" = 'ultra' || die "CAVEMAN_DEFAULT_MODE mismatch: $CAVEMAN_DEFAULT_MODE"
node -e 'const c=require(process.argv[1]); if(c.defaultMode !== "ultra") process.exit(1)' \\
  "$HOME/.config/caveman/config.json" || die 'Caveman config defaultMode mismatch'
test -f "$HOME/.config/opencode/plugins/caveman/plugin.js" || die 'Caveman OpenCode plugin is missing'
check_owned_file "$HOME/.config/opencode/plugins/caveman/plugin.js" "{plugin_digest}"
grep -Rq 'caveman' "$HOME/.config/opencode/opencode.json" "$HOME/.config/opencode/opencode.jsonc" 2>/dev/null || die 'OpenCode Caveman config entry is missing'
printf 'CAVEMAN_MODE %s\\n' "$CAVEMAN_DEFAULT_MODE"

declare -A expected_skill_hash=(
{rows}
)
for skill in "${{!expected_skill_hash[@]}}"; do
  check_owned_file "$HOME/.agents/skills/$skill/SKILL.md" "${{expected_skill_hash[$skill]}}"
done
check_owned_file "$HOME/.claude/skills/improve/SKILL.md" "${{expected_skill_hash[improve]}}"
for skill in "${{!expected_skill_hash[@]}}"; do
  test -f "$HOME/.agents/skills/$skill/SKILL.md" || die "universal skill destination missing: $skill"
done
agent_skill_count="$(find "$HOME/.agents/skills" -mindepth 2 -maxdepth 2 -type f -name SKILL.md | wc -l | tr -d ' ')"
test "$agent_skill_count" -ge 32 || die "expected at least 32 universal skills, saw $agent_skill_count"
printf 'ADAPTER_PATHS codex=~/.agents/skills amp=~/.agents/skills opencode=~/.agents/skills kimi=~/.agents/skills claude=~/.claude/skills\\n'
printf 'SKILL_COUNTS caveman=20 jackin-dev=11 shadcn-improve=1 universal-files=%s\\n' "$agent_skill_count"

for agent in cavecrew-builder cavecrew-investigator cavecrew-reviewer; do
  file="$HOME/.config/opencode/agents/$agent.md"
  test -r "$file" || die "OpenCode agent missing: $file"
  ! grep -q '^tools:' "$file" || die "unexpected tools frontmatter remains: $file"
done
for agent in cavecrew-builder cavecrew-investigator cavecrew-reviewer; do
  ! grep -q '^model:' "$HOME/.config/opencode/agents/$agent.md" || die "providerless model metadata remained after installer sanitization: $agent"
done
printf 'OPENCODE_AGENT_METADATA providerless-model-fields-stripped; no agent invoked\\n'

write_probe() {{
  local name="$1" expected="$2" root="$PROBE_ROOT/$1"
  mkdir -p "$root/src"
  cat > "$root/Cargo.toml" <<EOF
[package]
name = "$name"
version = "0.1.0"
edition = "2021"
EOF
  cat > "$root/Cargo.lock" <<EOF
version = 4

[[package]]
name = "$name"
version = "0.1.0"
EOF
  cat > "$root/src/main.rs" <<EOF
fn main() {{ println!("$expected"); }}
EOF
}}
write_check_probe() {{
  local name="$1" root="$PROBE_ROOT/$1"
  mkdir -p "$root/src"
  cat > "$root/Cargo.toml" <<EOF
[package]
name = "$name"
version = "0.1.0"
edition = "2021"
EOF
  cat > "$root/Cargo.lock" <<EOF
version = 4

[[package]]
name = "$name"
version = "0.1.0"
EOF
  cat > "$root/src/lib.rs" <<EOF
pub fn probe() -> &'static str {{ "$name" }}
EOF
}}

write_probe architect_mbx_probe_explicit MBX_EXPLICIT_BUILD_OK
explicit_stats="$PROBE_ROOT/explicit-mbx-stats.json"
rm -f -- "$explicit_stats"
(
  cd /tmp
  CARGO_TARGET_DIR="$PROBE_ROOT/target-explicit" \\
    MBX_STATS_REPORT="$explicit_stats" mise exec --deny-net -- mbx build --locked --offline --manifest-path "$PROBE_ROOT/architect_mbx_probe_explicit/Cargo.toml"
)
check_mbx_stats_report "$explicit_stats" explicit-mbx
explicit_binary="$PROBE_ROOT/target-explicit/debug/architect_mbx_probe_explicit"
test -f "$explicit_binary" || die 'explicit MBX build did not create its binary'
explicit_mode="$(stat -Lc '%a' "$explicit_binary")"
test -x "$explicit_binary" || die "explicit MBX binary lacks execute permission: mode=$explicit_mode path=$explicit_binary"
printf 'BUILT_EXECUTABLE explicit-mbx path=%s mode=%s uid=%s test_x=yes\\n' "$explicit_binary" "$explicit_mode" "$(stat -Lc '%u' "$explicit_binary")"
test "$("$explicit_binary")" = 'MBX_EXPLICIT_BUILD_OK' || die 'explicit MBX build probe output mismatch'
printf 'MBX_BUILD_ROUTE explicit-mbx-build PASS\\n'

write_check_probe architect_mise_cargo_check_probe
wrapper_target="$PROBE_ROOT/target-mise"
wrapper_workspace="$PROBE_ROOT/architect_mise_cargo_check_probe"
cold_stats="$PROBE_ROOT/wrapper-cold-stats.json"
rm -f -- "$cold_stats"
(
  cd /tmp
  CARGO_TARGET_DIR="$wrapper_target" \\
    MBX_STATS_REPORT="$cold_stats" mise exec --deny-net -- cargo check --lib --locked --offline --manifest-path "$wrapper_workspace/Cargo.toml"
)
check_mbx_stats_report "$cold_stats" mise-cargo-wrapper-cold
rm -rf -- "$wrapper_target"
hits_before_warm="$MBX_HIT_ACTIONS"
warm_stats="$PROBE_ROOT/wrapper-warm-stats.json"
rm -f -- "$warm_stats"
(
  cd /tmp
  CARGO_TARGET_DIR="$wrapper_target" \\
    MBX_STATS_REPORT="$warm_stats" mise exec --deny-net -- cargo check --lib --locked --offline --manifest-path "$wrapper_workspace/Cargo.toml"
)
check_mbx_stats_report "$warm_stats" mise-cargo-wrapper-warm
if [ "$MBX_HIT_ACTIONS" -le "$hits_before_warm" ]; then
  printf 'MBX_CACHE_RESULT mise-cargo-wrapper-warm cache-hit-not-observed; hit-actions=%s\\n' "$MBX_HIT_ACTIONS"
fi
wrapper_metadata="$(find "$wrapper_target/debug/deps" -maxdepth 1 -type f -name 'libarchitect_mise_cargo_check_probe-*.rmeta' -print -quit)"
test -n "$wrapper_metadata" || die 'Mise Cargo wrapper check did not create its metadata output'
printf 'MBX_BUILD_ROUTE mise-cargo-wrapper cargo-check PASS metadata=%s\\n' "$wrapper_metadata"
test "$MBX_HIT_ACTIONS" -gt "$hits_before_warm" || die 'MBX did not report a warm cache hit for the repeated wrapper build'
printf 'MBX_WARM_CACHE_HIT PASS hit-actions=%s\\n' "$MBX_HIT_ACTIONS"
printf 'MBX_SESSION_COUNTS hit-actions=%s miss-actions=%s unconsulted-actions=%s verification-actions=%s bypass-actions=%s\\n' \\
  "$MBX_HIT_ACTIONS" "$MBX_MISS_ACTIONS" "$MBX_UNCONSULTED_ACTIONS" "$MBX_VERIFICATION_ACTIONS" "$MBX_BYPASS_ACTIONS"

printf 'IMAGE_VALIDATION PASS no network, credentials, ctx7 invocation, skill invocation, or model invocation\\n'
'''
    return script.encode()


def make_probe_argv(docker_bin: Path, image_tag: str, cidfile: Path) -> list[str]:
    return [
        str(docker_bin),
        "run",
        "--rm",
        "--interactive",
        "--cidfile",
        str(cidfile),
        "--network=none",
        "--platform=linux/amd64",
        f"--cpus={RUNTIME_CPUS}",
        f"--memory={RUNTIME_MEMORY}",
        "--pids-limit=128",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges:true",
        "--tmpfs",
        RUNTIME_TMPFS,
        "--env",
        f"CARGO_BUILD_JOBS={BUILD_JOBS}",
        "--env",
        f"MISE_JOBS={MISE_JOBS}",
        "--env",
        "MISE_EXEC_AUTO_INSTALL=0",
        "--env",
        "CODEX_HOME=/tmp/architect-empty-codex-home",
        "--workdir",
        "/home/agent",
        "--entrypoint=/bin/bash",
        image_tag,
        "-s",
    ]


def validate_image_id(image_id: str) -> str:
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", image_id):
        raise RunnerError(f"Docker image inspection returned an invalid immutable ID: {image_id!r}")
    return image_id


def tail_log(path: Path, limit: int = 8192) -> str:
    try:
        with path.open("rb") as stream:
            stream.seek(max(0, path.stat().st_size - limit))
            return stream.read().decode("utf-8", "replace")
    except OSError:
        return ""


def process_group_exists(process_group: int) -> bool:
    try:
        os.killpg(process_group, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def terminate_process_group(
    process: subprocess.Popen[bytes], grace: float = PROCESS_TERM_GRACE_SECONDS
) -> None:
    process_group = process.pid
    try:
        os.killpg(process_group, signal.SIGTERM)
    except ProcessLookupError:
        pass
    deadline = time.monotonic() + grace
    while process_group_exists(process_group) and time.monotonic() < deadline:
        try:
            process.wait(timeout=0.05)
        except subprocess.TimeoutExpired:
            pass
        time.sleep(0.05)
    if process_group_exists(process_group):
        try:
            os.killpg(process_group, signal.SIGKILL)
        except ProcessLookupError:
            pass
    process.wait()
    if process.stdin is not None and not process.stdin.closed:
        process.stdin.close()


def run_bounded(
    label: str,
    argv: Sequence[str],
    env: dict[str, str],
    log_path: Path,
    timeout_seconds: int,
    stdin_bytes: bytes | None = None,
) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    log_path.touch(mode=0o600, exist_ok=False)
    started = time.monotonic()
    with log_path.open("wb") as log:
        process = subprocess.Popen(
            list(argv),
            stdin=subprocess.PIPE if stdin_bytes is not None else subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,
            close_fds=True,
        )
        try:
            process.communicate(input=stdin_bytes, timeout=timeout_seconds)
            status = process.returncode
            if status is None:
                raise RunnerError(f"{label} exited without a status")
        except subprocess.TimeoutExpired as error:
            terminate_process_group(process)
            raise RunnerError(
                f"{label} timed out after {timeout_seconds}s; log={log_path}\n{tail_log(log_path)}"
            ) from error
        except BaseException:
            terminate_process_group(process)
            raise
    elapsed = time.monotonic() - started
    record = {"label": label, "argv": list(argv), "status": status, "elapsed_seconds": round(elapsed, 3), "log": str(log_path)}
    print(json.dumps(record, sort_keys=True))
    if status != 0:
        raise RunnerError(f"{label} failed with status {status}; log={log_path}\n{tail_log(log_path)}")
    return status


def collect_docker_toolchain(
    docker_bin: Path, env: dict[str, str], log_dir: Path
) -> dict[str, object]:
    checks = {
        "docker_version": [str(docker_bin), "--version"],
        "buildx_version": [str(docker_bin), "buildx", "version"],
        "buildx_help": [str(docker_bin), "buildx", "build", "--help"],
        "client_plugins": [
            str(docker_bin),
            "info",
            "--format",
            "{{json .ClientInfo.Plugins}}",
        ],
    }
    outputs: dict[str, str] = {}
    for name, argv in checks.items():
        path = log_dir / f"preflight-{name}.log"
        run_bounded(f"docker-preflight-{name}", argv, env, path, 30)
        outputs[name] = path.read_text(encoding="utf-8", errors="replace").strip()
        if not outputs[name]:
            raise RunnerError(f"Docker preflight output is empty: {name}")

    require_buildx_resource_flag(outputs["buildx_help"])
    plugin = parse_buildx_plugin_info(outputs["client_plugins"])
    plugin_path = Path(plugin["path"])
    if not plugin_path.is_file() or not os.access(plugin_path, os.X_OK):
        raise RunnerError(f"Docker Buildx plugin executable is missing: {plugin_path}")
    plugin_real = plugin_path.resolve(strict=True)
    buildx_version = outputs["buildx_version"]
    if plugin["version"] not in buildx_version:
        raise RunnerError("Docker Buildx CLI version differs from the selected plugin metadata")
    return {
        "docker": {
            "path": str(docker_bin),
            "sha256": sha256_file(docker_bin),
            "version_output": outputs["docker_version"],
        },
        "buildx": {
            "path": plugin["path"],
            "realpath": str(plugin_real),
            "sha256": sha256_file(plugin_real),
            "version": plugin["version"],
            "version_output": buildx_version,
            "help_sha256": sha256_bytes(outputs["buildx_help"].encode()),
            "resource_option": "present",
        },
        "docker_info_client_plugins": [plugin],
        "buildx_help_log": str(log_dir / "preflight-buildx_help.log"),
    }


def read_container_id(path: Path) -> str | None:
    try:
        container_id = path.read_text().strip()
    except FileNotFoundError:
        return None
    if not re.fullmatch(r"[0-9a-f]{12,64}", container_id):
        raise RunnerError(f"invalid Docker cidfile contents: {container_id!r}")
    return container_id


def cleanup_owned_container(docker_bin: Path, container_id: str | None, env: dict[str, str], log_dir: Path) -> None:
    if container_id is None:
        return
    cleanup_log = log_dir / "container-cleanup.log"
    try:
        run_bounded(
            "remove-owned-runtime-container",
            [str(docker_bin), "rm", "--force", container_id],
            env,
            cleanup_log,
            30,
        )
    except RunnerError as error:
        print(f"CLEANUP_NOTE {error}", file=os.sys.stderr)


def ensure_private(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.chmod(0o700)


def make_plan(repo: Path, source_commit: str, docker_bin: Path | None = None) -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="architect-git-read-", dir=WORK) as tmp:
        commit, tree = verify_source(repo, source_commit, Path(tmp))
    docker_path = docker_bin or Path("/usr/bin/docker")
    tag = f"architect-image-verify:{commit[:12]}-<UTCSTAMP>-amd64"
    context = Path("<private-raw-tree-context>")
    return {
        "mode": "dry-run-build-and-probe",
        "source_commit": commit,
        "source_tree": tree,
        "included_paths": list(SOURCE_CONTEXT_PATHS),
        "image_tag_template": tag,
        "build_argv": make_build_argv(docker_path, tag, context),
        "image_inspect_argv": [str(docker_path), "image", "inspect", "--format", "{{.Id}}", tag],
        "runtime_argv": make_probe_argv(docker_path, "<inspected-sha256-image-id>", Path("<private-container-cidfile>")),
        "build_limits": {
            "CARGO_BUILD_JOBS": BUILD_JOBS,
            "MISE_JOBS": MISE_JOBS,
            "per_RUN_memory": BUILD_MEMORY,
            "per_RUN_cpu_quota": BUILD_CPU_QUOTA,
            "per_RUN_cpu_period": BUILD_CPU_PERIOD,
        },
        "runtime_limits": {"cpus": RUNTIME_CPUS, "memory": RUNTIME_MEMORY, "pids": "128", "network": "none", "tmpfs": RUNTIME_TMPFS, "probe_root": PROBE_HOME_ROOT},
        "credential_policy": "empty HOME and DOCKER_CONFIG; no inherited credentials or mounts",
        "execution": "not requested",
    }


def execute(repo: Path, source_commit: str) -> Path:
    ensure_private(WORK)
    run_stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_root = WORK / f"run-{source_commit[:12]}-{run_stamp}"
    run_root.mkdir(mode=0o700)
    context = run_root / "context"
    git_home = run_root / "git-home"
    private_home = run_root / "docker-home"
    docker_config = private_home / ".docker"
    log_dir = run_root / "logs"
    for directory in (git_home, private_home, docker_config, log_dir):
        directory.mkdir(parents=True, mode=0o700)
    (docker_config / "config.json").write_text("{}\n")
    (docker_config / "config.json").chmod(0o600)

    commit, tree = verify_source(repo, source_commit, git_home)
    if commit != REVIEWED_SOURCE_COMMIT or tree != REVIEWED_SOURCE_TREE:
        raise RunnerError("execution is pinned to the exact independently reviewed Dockerfile source")
    skills = parse_payload_inventory()
    context_manifest_data = materialize_tree_context(repo, tree, context, git_home)
    validate_dockerfile_contract(context / "Dockerfile")

    docker_name = shutil.which("docker", path="/usr/local/bin:/usr/bin:/bin")
    if docker_name is None:
        raise RunnerError("Docker CLI not found in the approved system paths")
    docker_bin = Path(docker_name).resolve()
    docker_env = clean_docker_env(private_home, docker_config, docker_bin)
    docker_toolchain = collect_docker_toolchain(docker_bin, docker_env, log_dir)
    docker_toolchain_path = run_root / "docker-toolchain.json"
    docker_toolchain_path.write_text(json.dumps(docker_toolchain, indent=2, sort_keys=True) + "\n")
    docker_toolchain_path.chmod(0o600)
    print("DOCKER_TOOLCHAIN " + json.dumps(docker_toolchain, sort_keys=True))
    tag = f"architect-image-verify:{commit[:12]}-{run_stamp.lower()}-amd64"
    build_argv = make_build_argv(docker_bin, tag, context)
    print(json.dumps({"source_commit": commit, "source_tree": tree, "context_manifest": context_manifest_data, "image_tag": tag}, sort_keys=True))
    run_bounded("docker-build-amd64", build_argv, docker_env, log_dir / "docker-build.log", BUILD_TIMEOUT_SECONDS)
    inspect_log = log_dir / "docker-image-inspect.log"
    inspect_argv = [str(docker_bin), "image", "inspect", "--format", "{{.Id}}", tag]
    run_bounded("docker-image-inspect", inspect_argv, docker_env, inspect_log, 60)
    inspected_image_id = validate_image_id(inspect_log.read_text().strip())

    cidfile = run_root / "runtime-container.cid"
    probe_argv = make_probe_argv(docker_bin, inspected_image_id, cidfile)
    probe_script = make_probe_script(skills)
    (run_root / "runtime-probe.sh").write_bytes(probe_script)
    (run_root / "runtime-probe.sh").chmod(0o600)
    try:
        run_bounded(
            "networkless-image-validation",
            probe_argv,
            docker_env,
            log_dir / "runtime-probe.log",
            PROBE_TIMEOUT_SECONDS,
            probe_script,
        )
    except BaseException:
        cleanup_owned_container(docker_bin, read_container_id(cidfile), docker_env, log_dir)
        raise
    image_id = inspected_image_id or None
    evidence = {
        "source_commit": commit,
        "source_tree": tree,
        "context_manifest": context_manifest_data,
        "docker_toolchain": docker_toolchain,
        "image_tag": tag,
        "image_id": image_id,
        "image_inspect_log": str(inspect_log),
        "build_log": str(log_dir / "docker-build.log"),
        "build_skipped_in_run": False,
        "runtime_log": str(log_dir / "runtime-probe.log"),
        "build_job_caps": {
            "CARGO_BUILD_JOBS": BUILD_JOBS,
            "MISE_JOBS": MISE_JOBS,
            "per_RUN_memory": BUILD_MEMORY,
            "per_RUN_cpu_quota": BUILD_CPU_QUOTA,
            "per_RUN_cpu_period": BUILD_CPU_PERIOD,
        },
        "runtime_sandbox": {"network": "none", "cpus": RUNTIME_CPUS, "memory": RUNTIME_MEMORY, "pids": 128, "tmpfs": RUNTIME_TMPFS, "probe_root": PROBE_HOME_ROOT},
        "status": "PASS",
    }
    evidence_path = run_root / "evidence.json"
    evidence_path.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")
    evidence_path.chmod(0o600)
    print(f"EVIDENCE {evidence_path}")
    return evidence_path


def execution_environment_is_isolated() -> bool:
    return (
        sys.flags.isolated == 1
        and sys.flags.no_site == 1
        and set(os.environ) <= {"PATH", "LC_ALL"}
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-commit", default=REVIEWED_SOURCE_COMMIT)
    parser.add_argument("--execute", action="store_true", help="build and validate the reviewed local image")
    args = parser.parse_args(argv)
    ensure_private(WORK)
    if args.source_commit != REVIEWED_SOURCE_COMMIT:
        raise RunnerError("this runner is frozen to the exact reviewed source commit")
    if args.execute:
        if not execution_environment_is_isolated():
            raise RunnerError(
                "execution requires `/usr/bin/env -i PATH=/usr/bin:/bin LC_ALL=C "
                "/usr/bin/python3 -I -S`"
            )
        evidence = execute(REPO, args.source_commit)
        print(f"IMAGE_RUNNER_PASS {evidence}")
        return 0
    plan = make_plan(REPO, args.source_commit)
    print(json.dumps(plan, indent=2, sort_keys=True))
    print("DRY_RUN_ONLY: no Docker command was started")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RunnerError, subprocess.CalledProcessError, OSError, KeyboardInterrupt) as error:
        print(f"IMAGE_RUNNER_FAIL: {error}", file=os.sys.stderr)
        raise SystemExit(1)
