from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import tarfile
import time
import unittest
import shlex

import runner


class RunnerFixtures(unittest.TestCase):
    def test_docker_vectors_keep_space_paths_as_single_arguments(self) -> None:
        docker = Path("/tmp/private bin/docker cli")
        context = Path("/tmp/private build contexts/Architect source")
        cidfile = Path("/tmp/private logs/runtime container.cid")
        tag = "architect-image-verify:fixture-amd64"

        build = runner.make_build_argv(docker, tag, context)
        self.assertEqual(build[0], str(docker))
        self.assertEqual(build[build.index("--file") + 1], str(context / "Dockerfile"))
        self.assertEqual(build[-1], str(context))
        self.assertIn("CARGO_BUILD_JOBS=4", build)
        self.assertIn("MISE_JOBS=1", build)
        self.assertEqual(build[1:3], ["buildx", "build"])
        self.assertIn("--load", build)
        self.assertIn("memory=32g", build)
        self.assertIn("cpu-quota=400000", build)
        self.assertIn("cpu-period=100000", build)

        probe = runner.make_probe_argv(docker, tag, cidfile)
        self.assertEqual(probe[0], str(docker))
        self.assertEqual(probe[probe.index("--cidfile") + 1], str(cidfile))
        self.assertIn("--entrypoint=/bin/bash", probe)
        self.assertEqual(probe[-2:], [tag, "-s"])
        self.assertIn("--network=none", probe)
        self.assertIn("--cpus=4", probe)
        self.assertIn("--memory=4g", probe)
        self.assertEqual(
            probe[probe.index("--tmpfs") + 1],
            "/tmp:rw,noexec,nosuid,nodev,size=2g",
        )
        self.assertNotIn("--mount", probe)
        self.assertNotIn("--privileged", probe)
        self.assertFalse(any("secret" in arg.lower() for arg in probe))

    def test_execution_refuses_nonisolated_python_environment(self) -> None:
        saved = dict(os.environ)
        try:
            os.environ.clear()
            os.environ.update({"PATH": "/usr/bin:/bin", "LC_ALL": "C", "HOME": "/tmp/unexpected-home"})
            self.assertFalse(runner.execution_environment_is_isolated())
        finally:
            os.environ.clear()
            os.environ.update(saved)

    def test_buildx_plugin_metadata_and_resource_help_are_required(self) -> None:
        output = "warning\n[{\"Name\":\"compose\"},{\"Name\":\"buildx\",\"Path\":\"/usr/libexec/docker/cli-plugins/docker-buildx\",\"Version\":\"v0.37.1\"}]\n"
        self.assertEqual(
            runner.parse_buildx_plugin_info(output),
            {"path": "/usr/libexec/docker/cli-plugins/docker-buildx", "version": "v0.37.1"},
        )
        runner.require_buildx_resource_flag("Options:\n      --resource stringArray  Resource limits for build\n")
        with self.assertRaisesRegex(runner.RunnerError, "one Docker Buildx"):
            runner.parse_buildx_plugin_info("[]\n")
        with self.assertRaisesRegex(runner.RunnerError, "--resource"):
            runner.require_buildx_resource_flag("Options:\n      --memory string\n")

    def test_fake_executable_receives_exact_argv_stdin_and_clean_environment(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner argv fixture with spaces ") as raw:
            root = Path(raw)
            executable = root / "fake docker command"
            record = root / "argv record.json"
            source = """#!/usr/bin/python3
import json, os, sys
payload = sys.stdin.buffer.read()
with open(RECORD_PATH, 'w', encoding='utf-8') as f:
    json.dump({'argv': sys.argv[1:], 'stdin': payload.decode(), 'home': os.environ.get('HOME'), 'keys': sorted(os.environ)}, f)
""".replace("RECORD_PATH", json.dumps(str(record)))
            executable.write_text(source)
            executable.chmod(0o700)
            log = root / "fake log.txt"
            home = root / "clean home"
            home.mkdir()
            environment = {"HOME": str(home), "PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
            expected_argv = ["run", "one value with spaces", "--label", "a=b c"]
            script = "printf '%s\\n' 'fixture only'\n"

            self.assertEqual(
                runner.run_bounded("fake-docker-fixture", [str(executable), *expected_argv], environment, log, 5, script.encode()),
                0,
            )
            captured = json.loads(record.read_text())
            self.assertEqual(captured["argv"], expected_argv)
            self.assertEqual(captured["stdin"], script)
            self.assertEqual(captured["home"], str(home))
            self.assertNotIn("GITHUB_TOKEN", captured["keys"])
            self.assertNotIn("OPENAI_API_KEY", captured["keys"])

    def test_fake_child_is_reaped_after_timeout(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner timeout fixture ") as raw:
            root = Path(raw)
            executable = root / "sleeping fake docker"
            child_pid_file = root / "child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                f"sleep 60 & child=$!; printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}; wait\n"
            )
            executable.chmod(0o700)
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded("fake-timeout-fixture", [str(executable)], {"PATH": "/usr/bin:/bin"}, root / "timeout.log", 1)
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.05)
            else:
                self.fail(f"timed-out child process still exists: {child_pid}")

    def test_timeout_covers_blocked_stdin_delivery(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner blocked stdin fixture ") as raw:
            root = Path(raw)
            executable = root / "nonreading fake docker"
            child_pid_file = root / "child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                f"sleep 60 & child=$!; printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}; wait\n"
            )
            executable.chmod(0o700)
            started = time.monotonic()
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded(
                    "fake-blocked-stdin-fixture",
                    [str(executable)],
                    {"PATH": "/usr/bin:/bin"},
                    root / "blocked-stdin.log",
                    1,
                    b"x" * (2 * 1024 * 1024),
                )
            self.assertLess(time.monotonic() - started, 4)
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.05)
            else:
                self.fail(f"blocked-input child process still exists: {child_pid}")

    def test_timeout_kills_ignoring_grandchild_after_leader_exits(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner grandchild fixture ") as raw:
            root = Path(raw)
            executable = root / "ignoring fake docker"
            child_pid_file = root / "ignoring-child.pid"
            executable.write_text(
                "#!/bin/bash\n"
                "python3 -c 'import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(60)' & child=$!\n"
                f"printf '%s\\n' \"$child\" > {shlex.quote(str(child_pid_file))}\n"
                "trap 'exit 0' TERM\n"
                "wait \"$child\"\n"
            )
            executable.chmod(0o700)
            with self.assertRaisesRegex(runner.RunnerError, "timed out"):
                runner.run_bounded(
                    "fake-grandchild-fixture",
                    [str(executable)],
                    {"PATH": "/usr/bin:/bin"},
                    root / "grandchild.log",
                    0.2,
                )
            child_pid = int(child_pid_file.read_text())
            for _ in range(30):
                try:
                    os.kill(child_pid, 0)
                except ProcessLookupError:
                    break
                stat_path = Path(f"/proc/{child_pid}/stat")
                if stat_path.exists() and stat_path.read_text().split(") ", 1)[1].split()[0] == "Z":
                    break
                time.sleep(0.05)
            else:
                self.fail(f"SIGTERM-ignoring process survived group cleanup: {child_pid}")

    def test_raw_tree_context_ignores_replace_refs_attributes_and_worktree_files(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner raw tree fixture with spaces ") as raw:
            root = Path(raw)
            repo = root / "repo with spaces"
            repo.mkdir()
            git_home = root / "isolated git home"
            git_home.mkdir()
            env = runner.clean_git_env(git_home)
            subprocess.run(["/usr/bin/git", "init", "--quiet", str(repo)], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.name", "Fixture"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "config", "user.email", "fixture@example.invalid"], check=True, env=env)
            fixture_files = {
                ".dockerignore": ".git\n",
                "Dockerfile": "FROM scratch\n# $Format:%H$\n",
                ".gitattributes": "Dockerfile export-ignore export-subst\n",
                "caveman-config.json": '{"defaultMode":"ultra"}\n',
                "AGENTS.md.d/caveman.md": "Fixture instructions\n",
                "AGENTS.md.d/token-tools.md": "Fixture tool rules\n",
                "jackin-toolchain/mise.toml": "[tools]\n",
                "jackin-toolchain/rust-toolchain.toml": "[toolchain]\nchannel = \"1.98.1\"\n",
                "maintained-image-build/skills-cli/package.json": '{"name":"fixture"}\n',
                "maintained-image-build/skills-cli/package-lock.json": '{"lockfileVersion":3}\n',
                "README.md": "Tracked but not part of the build context\n",
            }
            for name, contents in fixture_files.items():
                path = repo / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(contents)
            (repo / "untracked-secret.txt").write_text("must not enter the context\n")
            subprocess.run(["/usr/bin/git", "-C", str(repo), "add", "--all"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "commit", "--quiet", "-m", "fixture"], check=True, env=env)
            commit = subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
                env=env,
            ).stdout.strip()
            original_tree = runner.verify_source(repo, commit, git_home)[1]

            attributes = repo / ".git" / "info" / "attributes"
            attributes.write_text("Dockerfile export-ignore export-subst\n")
            dockerfile = repo / "Dockerfile"
            dockerfile.write_text("FROM replaced-object\n")
            subprocess.run(["/usr/bin/git", "-C", str(repo), "add", "Dockerfile"], check=True, env=env)
            subprocess.run(["/usr/bin/git", "-C", str(repo), "commit", "--quiet", "-m", "replacement"], check=True, env=env)
            replacement = subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
                env=env,
            ).stdout.strip()
            replacement_env = dict(env)
            replacement_env.pop("GIT_NO_REPLACE_OBJECTS")
            subprocess.run(
                ["/usr/bin/git", "-C", str(repo), "replace", commit, replacement],
                check=True,
                env=replacement_env,
            )

            pinned_commit, pinned_tree = runner.verify_source(repo, commit, git_home)
            self.assertEqual(pinned_commit, commit)
            self.assertEqual(pinned_tree, original_tree)
            context = root / "context with spaces"
            manifest = runner.materialize_tree_context(repo, original_tree, context, git_home)
            files = {entry["path"] for entry in manifest["files"]}
            self.assertEqual(files, runner.REQUIRED_FILES)
            self.assertEqual((context / "Dockerfile").read_text(), fixture_files["Dockerfile"])
            self.assertFalse((context / ".gitattributes").exists())
            self.assertFalse((context / "README.md").exists())
            self.assertFalse((context / "untracked-secret.txt").exists())

    def test_reviewed_source_tree_passes_dockerfile_contract(self) -> None:
        with tempfile.TemporaryDirectory(prefix="runner reviewed source ") as raw:
            root = Path(raw)
            git_home = root / "git home"
            git_home.mkdir(mode=0o700)
            commit, tree = runner.verify_source(
                runner.REPO, runner.REVIEWED_SOURCE_COMMIT, git_home
            )
            self.assertEqual(commit, runner.REVIEWED_SOURCE_COMMIT)
            self.assertEqual(tree, runner.REVIEWED_SOURCE_TREE)
            context = root / "context"
            runner.materialize_tree_context(runner.REPO, tree, context, git_home)
            runner.validate_dockerfile_contract(context / "Dockerfile")

    def test_pinned_git_archive_modes_are_masked_before_copyfile_install(self) -> None:
        archive = runner.WORK / "assets/caveman-8b0c1d3699b8.tar"
        self.assertEqual(
            runner.sha256_file(archive),
            "954909b361634fad64bd299642ca3d5d5f6320d8b9fb6760efc51a4e83eea718",
        )
        source_paths = {
            "src/plugins/opencode/plugin.js": 0o664,
            "bin/install.js": 0o775,
        }
        with tarfile.open(archive, mode="r:") as bundle:
            for source_path, archive_mode in source_paths.items():
                member = bundle.getmember(source_path)
                self.assertTrue(member.isfile())
                self.assertEqual(member.mode & 0o777, archive_mode)

        node_bin = Path("/root/.local/share/mise/installs/node/24.18.0/bin/node")
        self.assertTrue(node_bin.is_file())
        self.assertEqual(
            runner.sha256_file(node_bin),
            "41a74efb34cbde5c7632cdac0cf8bd1a14d0b8d73dc1e82755014d9a9ce70f5c",
        )
        self.assertEqual(
            subprocess.run(
                [str(node_bin), "--version"],
                check=True,
                capture_output=True,
                text=True,
                env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
                timeout=10,
            ).stdout.strip(),
            "v24.18.0",
        )

        with tempfile.TemporaryDirectory(prefix="runner source mode fixture ", dir="/var/tmp") as raw:
            root = Path(raw)
            source_root = root / "source"
            install_root = root / "installed"
            source_root.mkdir(mode=0o700)
            install_root.mkdir(mode=0o700)
            old_umask = os.umask(0o022)
            try:
                subprocess.run(
                    [
                        "/usr/bin/tar",
                        "--extract",
                        "--file",
                        str(archive),
                        "--directory",
                        str(source_root),
                        "--no-same-owner",
                        "--no-same-permissions",
                    ],
                    check=True,
                    capture_output=True,
                    timeout=20,
                    env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
                )
                copies = [
                    (
                        source_root / "src/plugins/opencode/plugin.js",
                        install_root / "plugin.js",
                        0o644,
                    ),
                    (source_root / "bin/install.js", install_root / "install.js", 0o755),
                ]
                for source, _, expected_mode in copies:
                    self.assertEqual(source.stat().st_mode & 0o777, expected_mode)
                copy_script = (
                    "const fs = require('node:fs'); "
                    "const [pluginSource, installerSource, pluginTarget, installerTarget] = process.argv.slice(1); "
                    "fs.copyFileSync(pluginSource, pluginTarget); "
                    "fs.copyFileSync(installerSource, installerTarget);"
                )
                subprocess.run(
                    [
                        str(node_bin),
                        "-e",
                        copy_script,
                        str(copies[0][0]),
                        str(copies[1][0]),
                        str(copies[0][1]),
                        str(copies[1][1]),
                    ],
                    check=True,
                    capture_output=True,
                    timeout=10,
                    env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
                )
            finally:
                os.umask(old_umask)

            for source, target, expected_mode in copies:
                self.assertEqual(target.stat().st_mode & 0o777, expected_mode)
                self.assertEqual(source.read_bytes(), target.read_bytes())

    def test_cargo_archive_pins_match_reviewed_source_bytes_and_locks(self) -> None:
        hashes = runner.validate_cargo_crate_sources()
        self.assertEqual(hashes, runner.CARGO_CRATE_SHA256)
        self.assertEqual(set(hashes), {"cargo-fuzz", "cargo-mutants"})

    def test_prebuilt_asset_table_matches_exact_dockerfile_case(self) -> None:
        assets = runner.validate_prebuilt_assets()
        self.assertEqual(len(assets), 22)
        source = (runner.REPO / "Dockerfile").read_text()
        runner.validate_prebuilt_dockerfile_pins(source, assets)
        altered = source.replace(
            "asset_sha256=ab28a1bdb54db4d5d8ad5981cf1f959410370b3d28250dbd35f6a44248620e39",
            "asset_sha256=" + "0" * 64,
            1,
        )
        self.assertNotEqual(source, altered)
        with self.assertRaisesRegex(runner.RunnerError, "differs from reviewed audit"):
            runner.validate_prebuilt_dockerfile_pins(altered, assets)

    def test_mbx_json_report_counts_all_outcomes_and_rejects_malformed_fields(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        die_match = re.search(r"(?m)^die\(\) \{.*\}$", script)
        function_match = re.search(
            r"(?ms)^(check_mbx_stats_report\(\) \{\n.*?^\})\nmountinfo_line_for",
            script,
        )
        self.assertIsNotNone(die_match)
        self.assertIsNotNone(function_match)

        mise = Path("/root/.local/bin/mise")
        node_result = subprocess.run(
            [str(mise), "exec", "node@24.18.0", "--", "node", "-p", "process.execPath"],
            env={
                "HOME": "/root",
                "PATH": "/root/.local/bin:/usr/bin:/bin",
                "MISE_EXEC_AUTO_INSTALL": "0",
            },
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        )
        node_bin = Path(node_result.stdout.strip())
        self.assertEqual(
            node_bin.resolve(),
            Path("/root/.local/share/mise/installs/node/24.18.0/bin/node").resolve(),
        )
        node_version = subprocess.run(
            [str(mise), "exec", "node@24.18.0", "--", "node", "--version"],
            env={
                "HOME": "/root",
                "PATH": "/root/.local/bin:/usr/bin:/bin",
                "MISE_EXEC_AUTO_INSTALL": "0",
            },
            capture_output=True,
            text=True,
            timeout=5,
            check=True,
        ).stdout.strip()
        self.assertRegex(node_version, r"^v24\.")

        with tempfile.TemporaryDirectory(prefix="runner MBX JSON fixture with spaces ") as raw:
            root = Path(raw)
            fake_bin = root / "fake bin"
            fake_bin.mkdir()
            fake_mise = fake_bin / "mise"
            fake_mise.write_text(
                "#!/bin/sh\n"
                "test \"$1\" = exec && test \"$2\" = --deny-net && test \"$3\" = -- && test \"$4\" = node || exit 23\n"
                "shift 4\n"
                f"{shlex.quote(str(node_bin))} \"$@\"\n"
                "node_status=$?\n"
                "if [ \"${FAKE_MISE_EXTRA_OUTPUT:-0}\" = 1 ]; then printf 'unexpected extra output\\n'; fi\n"
                "exit \"$node_status\"\n"
            )
            fake_mise.chmod(0o700)

            def run_report(
                payload: dict[str, object] | str,
                *,
                extra_output: bool = False,
            ) -> subprocess.CompletedProcess[str]:
                stats_file = root / "stats report.json"
                contents = payload if isinstance(payload, str) else json.dumps(payload)
                stats_file.write_text(contents)
                stats_file.chmod(0o600)
                bash_script = (
                    "set -euo pipefail\n"
                    "MBX_HIT_ACTIONS=0; MBX_MISS_ACTIONS=0; MBX_UNCONSULTED_ACTIONS=0\n"
                    "MBX_VERIFICATION_ACTIONS=0; MBX_BYPASS_ACTIONS=0\n"
                    f"{die_match.group(0)}\n"
                    f"{function_match.group(1)}\n"
                    f"check_mbx_stats_report {shlex.quote(str(stats_file))} fixture\n"
                    "printf 'MBX_FIXTURE_TOTALS hits=%s misses=%s unconsulted=%s verifications=%s bypasses=%s\\n' "
                    '"$MBX_HIT_ACTIONS" "$MBX_MISS_ACTIONS" "$MBX_UNCONSULTED_ACTIONS" '
                    '"$MBX_VERIFICATION_ACTIONS" "$MBX_BYPASS_ACTIONS"\n'
                )
                env = {
                    "PATH": f"{fake_bin}:/usr/bin:/bin",
                    "LC_ALL": "C",
                }
                if extra_output:
                    env["FAKE_MISE_EXTRA_OUTPUT"] = "1"
                return subprocess.run(
                    ["/bin/bash", "-c", bash_script],
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

            observed = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 0,
                    "unconsulted": 1,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertEqual(observed.returncode, 0, observed.stderr)
            self.assertIn("MBX_STATS_RESULT fixture schema=5 hits=0 misses=0 unconsulted=1", observed.stdout)
            self.assertIn("MBX_FIXTURE_TOTALS hits=0 misses=0 unconsulted=1 verifications=0 bypasses=0", observed.stdout)

            extra_output = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 0,
                    "unconsulted": 1,
                    "verifications": 0,
                    "bypasses": {},
                },
                extra_output=True,
            )
            self.assertNotEqual(extra_output.returncode, 0)
            self.assertIn("parser emitted multiple lines", extra_output.stderr)

            singular_miss = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 1,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertEqual(singular_miss.returncode, 0, singular_miss.stderr)
            self.assertIn("MBX_STATS_RESULT fixture schema=5 hits=0 misses=1 unconsulted=0", singular_miss.stdout)
            self.assertIn("MBX_FIXTURE_TOTALS hits=0 misses=1 unconsulted=0 verifications=0 bypasses=0", singular_miss.stdout)

            mixed = run_report(
                {
                    "version": 5,
                    "hits": 2,
                    "misses": 1,
                    "unconsulted": 3,
                    "verifications": 1,
                    "bypasses": {
                        "unsupported-crate-type": 2,
                        "cc-incremental": 1,
                    },
                }
            )
            self.assertEqual(mixed.returncode, 0, mixed.stderr)
            self.assertIn(
                'MBX_STATS_RESULT fixture schema=5 hits=2 misses=1 unconsulted=3 verifications=1 bypasses=3 reasons=[["cc-incremental",1],["unsupported-crate-type",2]]',
                mixed.stdout,
            )
            self.assertIn("MBX_FIXTURE_TOTALS hits=2 misses=1 unconsulted=3 verifications=1 bypasses=3", mixed.stdout)

            warm = run_report(
                {
                    "version": 5,
                    "hits": 1,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertEqual(warm.returncode, 0, warm.stderr)
            self.assertIn("MBX_STATS_RESULT fixture schema=5 hits=1 misses=0 unconsulted=0", warm.stdout)
            self.assertIn("MBX_FIXTURE_TOTALS hits=1 misses=0 unconsulted=0 verifications=0 bypasses=0", warm.stdout)

            malformed = run_report(
                {
                    "version": 5,
                    "hits": 1.5,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertNotEqual(malformed.returncode, 0)
            self.assertIn("invalid MBX stats counter: hits", malformed.stderr)

            unusual_bypass = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {"future reason\tlabel": 1},
                }
            )
            self.assertEqual(unusual_bypass.returncode, 0, unusual_bypass.stderr)
            self.assertIn('reasons=[["future reason\\tlabel",1]]', unusual_bypass.stdout)
            self.assertIn("MBX_FIXTURE_TOTALS hits=0 misses=0 unconsulted=0 verifications=0 bypasses=1", unusual_bypass.stdout)

            malformed_json = run_report('{"version": 5, "hits":')
            self.assertNotEqual(malformed_json.returncode, 0)
            self.assertIn("MBX JSON stats report is invalid", malformed_json.stderr)

            malformed_bypass_count = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {"future-reason": -1},
                }
            )
            self.assertNotEqual(malformed_bypass_count.returncode, 0)
            self.assertIn("invalid MBX bypass counter", malformed_bypass_count.stderr)

            unknown_schema = run_report(
                {
                    "version": 6,
                    "hits": 1,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertNotEqual(unknown_schema.returncode, 0)
            self.assertIn("unsupported MBX stats schema", unknown_schema.stderr)

            missing_counts = run_report(
                {
                    "version": 5,
                    "hits": 0,
                    "misses": 0,
                    "unconsulted": 0,
                    "verifications": 0,
                    "bypasses": {},
                }
            )
            self.assertNotEqual(missing_counts.returncode, 0)
            self.assertIn("has no accounted actions", missing_counts.stderr)

    def test_probe_root_creation_records_umask_and_keeps_its_leaf_private(self) -> None:
        source = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        function_match = re.search(
            r"(?ms)^(create_probe_directories\(\) \{\n.*?^\})\ncreate_probe_directories",
            source,
        )
        self.assertIsNotNone(function_match)
        self.assertIn('(( (8#$probe_root_mode & 0022) == 0 ))', source)

        with tempfile.TemporaryDirectory(prefix="runner private probe directory ") as raw:
            root = Path(raw)
            parent = root / "group writable parent"
            parent.mkdir()
            parent.chmod(0o775)
            probe_root = parent / "probe root"
            codex_home = root / "codex home"
            bash_script = (
                "set -euo pipefail\n"
                f"PROBE_ROOT={shlex.quote(str(probe_root))}\n"
                f"CODEX_HOME={shlex.quote(str(codex_home))}\n"
                "umask 0002\n"
                f"{function_match.group(1)}\n"
                "create_probe_directories\n"
            )
            created = subprocess.run(
                ["/bin/bash", "-c", bash_script],
                env={"PATH": "/usr/bin:/bin", "LC_ALL": "C"},
                capture_output=True,
                text=True,
                timeout=5,
            )
            self.assertEqual(created.returncode, 0, created.stderr)
            self.assertIn("umask=0002 parent_mode=775", created.stdout)
            self.assertIn("umask=0077 parent_mode=775", created.stdout)
            self.assertEqual(probe_root.stat().st_mode & 0o777, 0o700)
            self.assertEqual(codex_home.stat().st_mode & 0o777, 0o700)
            self.assertEqual(parent.stat().st_mode & 0o777, 0o775)

            existing_root = parent / "existing root"
            existing_root.mkdir(mode=0o775)
            existing_root.chmod(0o775)
            existing_script = (
                "set -euo pipefail\n"
                f"PROBE_ROOT={shlex.quote(str(existing_root))}\n"
                f"CODEX_HOME={shlex.quote(str(root / 'other codex home'))}\n"
                "umask 0002\n"
                f"{function_match.group(1)}\n"
                "create_probe_directories\n"
            )
            existing = subprocess.run(
                ["/bin/bash", "-c", existing_script],
                env={"PATH": "/usr/bin:/bin", "LC_ALL": "C"},
                capture_output=True,
                text=True,
                timeout=5,
            )
            self.assertEqual(existing.returncode, 0, existing.stderr)
            self.assertEqual(existing_root.stat().st_mode & 0o777, 0o775)

    def test_probe_target_stays_outside_noexec_tmpfs_and_mount_guard_is_enforced(self) -> None:
        source = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        self.assertIn(f'PROBE_ROOT="{runner.PROBE_HOME_ROOT}"', source)
        self.assertNotIn("/tmp/architect-image-probe/target", source)
        self.assertIn('CARGO_TARGET_DIR="$PROBE_ROOT/target-explicit"', source)
        self.assertIn('CARGO_TARGET_DIR="$wrapper_target"', source)
        self.assertIn('case "$PROBE_ROOT" in /tmp/*)', source)

        die_match = re.search(r"(?m)^die\(\) \{.*\}$", source)
        line_function = re.search(r"(?ms)^mountinfo_line_for\(\) \{\n.*?^\}", source)
        guard_function = re.search(r"(?ms)^verify_probe_mounts\(\) \{\n.*?^\}", source)
        self.assertIsNotNone(die_match)
        self.assertIsNotNone(line_function)
        self.assertIsNotNone(guard_function)

        with tempfile.TemporaryDirectory(prefix="runner mountinfo fixture ") as raw:
            root = Path(raw)
            mountinfo = root / "mountinfo"
            safe = (
                "35 24 0:32 / / rw,relatime - overlay overlay rw\n"
                "36 35 0:59 / /tmp rw,nosuid,nodev,noexec,relatime - tmpfs tmpfs rw,size=2g\n"
            )

            def run_guard(content: str, probe_root: str = runner.PROBE_HOME_ROOT) -> subprocess.CompletedProcess[str]:
                mountinfo.write_text(content)
                bash_script = (
                    "set -euo pipefail\n"
                    f"PROBE_ROOT={shlex.quote(probe_root)}\n"
                    f"{die_match.group(0)}\n"
                    f"{line_function.group(0)}\n"
                    f"{guard_function.group(0)}\n"
                    "verify_probe_mounts\n"
                )
                return subprocess.run(
                    ["/bin/bash", "-c", bash_script],
                    env={
                        "PATH": "/usr/bin:/bin",
                        "LC_ALL": "C",
                        "MOUNTINFO_PATH": str(mountinfo),
                    },
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

            accepted = run_guard(safe)
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            self.assertIn("MOUNTINFO tmp path=/tmp", accepted.stdout)
            self.assertIn("MOUNTINFO target path=/home/agent/.cache/architect-image-probe", accepted.stdout)

            tmp_exec = safe.replace("rw,nosuid,nodev,noexec,relatime", "rw,nosuid,nodev,relatime")
            rejected_tmp = run_guard(tmp_exec)
            self.assertNotEqual(rejected_tmp.returncode, 0)
            self.assertIn("/tmp mount is not noexec", rejected_tmp.stderr)

            target_noexec = safe.replace(
                "36 35 0:59 / /tmp",
                "36 35 0:58 / /home rw,noexec,relatime - ext4 /dev/test rw\n37 35 0:59 / /tmp",
            )
            rejected_target = run_guard(target_noexec)
            self.assertNotEqual(rejected_target.returncode, 0)
            self.assertIn("probe target mount is noexec", rejected_target.stderr)

            rejected_tmp_target = run_guard(safe, "/tmp/architect-image-probe")
            self.assertNotEqual(rejected_tmp_target.returncode, 0)
            self.assertIn("probe root is outside the reviewed home cache path", rejected_tmp_target.stderr)

    def test_native_cargo_wrapper_must_resolve_to_mise_binary(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        die_match = re.search(r"(?m)^die\(\) \{.*\}$", script)
        function_match = re.search(
            r"(?ms)^verify_native_cargo_wrapper\(\) \{\n.*?^\}", script
        )
        self.assertIsNotNone(die_match)
        self.assertIsNotNone(function_match)

        def run_guard(home: Path) -> subprocess.CompletedProcess[str]:
            mise = home / ".local/bin/mise"
            wrapper = home / ".local/share/mise/command-wrappers/bin/cargo"
            mise.parent.mkdir(parents=True, exist_ok=True)
            wrapper.parent.mkdir(parents=True, exist_ok=True)
            mise.write_text("#!/bin/sh\nexit 0\n")
            mise.chmod(0o700)
            if wrapper.exists() or wrapper.is_symlink():
                wrapper.unlink()
            if home.name.startswith("foreign"):
                wrapper.write_text("#!/bin/sh\nexit 0\n")
                wrapper.chmod(0o700)
            else:
                wrapper.symlink_to(mise)
            bash_script = (
                "set -euo pipefail\n"
                f"{die_match.group(0)}\n"
                f"{function_match.group(0)}\n"
                f"verify_native_cargo_wrapper {shlex.quote(str(mise))} {shlex.quote(str(wrapper))}\n"
            )
            return subprocess.run(
                ["/bin/bash", "-c", bash_script],
                env={"PATH": "/usr/bin:/bin", "HOME": str(home), "LC_ALL": "C"},
                capture_output=True,
                text=True,
                timeout=5,
            )

        with tempfile.TemporaryDirectory(prefix="runner native wrapper fixture ") as raw:
            root = Path(raw)
            accepted = run_guard(root / "accepted")
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            self.assertIn("MBX_WRAPPER", accepted.stdout)
            rejected = run_guard(root / "foreign-target")
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("does not enter the verified Mise executable", rejected.stderr)

    def test_plan_builds_exact_reviewed_source_then_runs_inspected_immutable_id(self) -> None:
        plan = runner.make_plan(runner.REPO, runner.REVIEWED_SOURCE_COMMIT)
        self.assertEqual(plan["mode"], "dry-run-build-and-probe")
        self.assertEqual(plan["source_commit"], "3c9d54642f3a6ea55ccb06c36bc4b204cde1d54c")
        self.assertEqual(plan["source_tree"], "f073b27527b0f039c7fe6882575471bfe12504f1")
        self.assertIn("build_argv", plan)
        self.assertIn("image_inspect_argv", plan)
        self.assertEqual(plan["runtime_argv"][-2], "<inspected-sha256-image-id>")

    def test_runtime_uses_only_a_validated_immutable_image_id(self) -> None:
        immutable_id = "sha256:" + "a" * 64
        self.assertEqual(runner.validate_image_id(immutable_id), immutable_id)
        with self.assertRaisesRegex(runner.RunnerError, "invalid immutable ID"):
            runner.validate_image_id("architect-image-verify:mutable-tag")
        argv = runner.make_probe_argv(Path("/usr/bin/docker"), immutable_id, Path("/tmp/cid"))
        self.assertEqual(argv[-2], immutable_id)

    def test_bare_image_probe_marks_codex_deferred_to_jackin_derived_image(self) -> None:
        source = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        self.assertIn(
            "CODEX_RUNTIME NOT_RUN; installed by Jackin in the derived agent image",
            source,
        )
        self.assertNotIn('codex --version', source)
        self.assertNotIn('check_version codex', source)
        self.assertIn("export CODEX_HOME=/tmp/architect-empty-codex-home", source)
        self.assertIn('IMAGE_ID uid=%s gid=%s groups=%s', source)
        self.assertIn('FILE_OK %s mode=%s sha256=%s', source)
        self.assertIn('MOUNTINFO tmp path=/tmp line=%s', source)
        self.assertIn('BUILT_EXECUTABLE explicit-mbx path=%s mode=%s uid=%s test_x=yes', source)
        self.assertIn('MBX_WARM_CACHE_HIT PASS hit-actions=%s', source)
        self.assertIn('MBX_BUILD_ROUTE mise-cargo-wrapper cargo-check PASS', source)

    def test_probe_script_is_bash_syntax_valid_and_never_invokes_context7_or_skills(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory())
        checked = subprocess.run(["/bin/bash", "-n"], input=script, capture_output=True)
        self.assertEqual(checked.returncode, 0, checked.stderr.decode())
        source = script.decode()
        self.assertIn("mise exec --deny-net -- mbx build", source)
        self.assertIn("mise exec --deny-net -- cargo check --lib", source)
        self.assertIn('MBX_STATS_REPORT="$explicit_stats" mise exec --deny-net -- mbx build', source)
        self.assertIn('MBX_STATS_REPORT="$cold_stats" mise exec --deny-net -- cargo check --lib', source)
        self.assertIn('MBX_STATS_REPORT="$warm_stats" mise exec --deny-net -- cargo check --lib', source)
        self.assertIn('const report = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));', source)
        self.assertIn("if (report.version !== 5)", source)
        self.assertIn("JSON.stringify(bypasses)", source)
        self.assertNotIn("mbx explain --last", source)
        self.assertLess(
            source.index("mise exec --deny-net -- mbx build"),
            source.index('check_mbx_stats_report "$explicit_stats" explicit-mbx'),
        )
        self.assertLess(
            source.index('check_mbx_stats_report "$explicit_stats" explicit-mbx'),
            source.index('test "$("$explicit_binary")"'),
        )
        self.assertIn("ctx7 CLI not invoked", source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/ctx7" --', source)
        self.assertNotIn('"$HOME/.local/share/architect-node-tools/node_modules/.bin/skills" add', source)

    def test_mise_probe_matches_recorded_output_and_rejects_old_prefix(self) -> None:
        script = runner.make_probe_script(runner.parse_payload_inventory()).decode()
        die_match = re.search(r"(?m)^die\(\) \{.*\}$", script)
        function_match = re.search(r"(?ms)^check_version\(\) \{\n.*?^\}", script)
        self.assertIsNotNone(die_match)
        self.assertIsNotNone(function_match)
        call_match = re.search(
            r'(?m)^check_version mise \'([^\']+)\' "\$\(mise --version\)"$', script
        )
        self.assertIsNotNone(call_match)

        output_record = (runner.WORK / "mise-version-output.txt").read_text()
        recorded_output = next(
            line.removeprefix("stdout=")
            for line in output_record.splitlines()
            if line.startswith("stdout=")
        )
        self.assertEqual(recorded_output, "2026.9.18 linux-x64 (2026-09-30)")

        with tempfile.TemporaryDirectory(prefix="runner mise version fixture ") as raw:
            root = Path(raw)
            fake_bin = root / "bin"
            fake_bin.mkdir()
            fake_mise = fake_bin / "mise"

            def run_probe(expected_prefix: str) -> subprocess.CompletedProcess[str]:
                fake_mise.write_text(
                    "#!/bin/sh\nprintf '%s\\n' " + shlex.quote(recorded_output) + "\n"
                )
                fake_mise.chmod(0o700)
                call = f"check_version mise {shlex.quote(expected_prefix)} \"$(mise --version)\""
                bash_script = (
                    f"set -euo pipefail\n{die_match.group(0)}\n"
                    f"{function_match.group(0)}\n{call}\n"
                )
                return subprocess.run(
                    ["/bin/bash", "-c", bash_script],
                    env={"PATH": f"{fake_bin}:/usr/bin:/bin", "LC_ALL": "C"},
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

            self.assertEqual(call_match.group(1), "2026.9.18 ")
            accepted = run_probe(call_match.group(1))
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            self.assertIn(recorded_output, accepted.stdout)

            rejected = run_probe("mise 2026.9.18")
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("mise version mismatch", rejected.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
