#!/bin/bash
set -euo pipefail
export MISE_EXEC_AUTO_INSTALL=0
export MISE_JOBS=1
export CARGO_BUILD_JOBS=4
export CODEX_HOME=/tmp/architect-empty-codex-home
mkdir -p "$CODEX_HOME" /tmp/architect-image-probe

die() { echo "IMAGE_CHECK_FAIL: $*" >&2; exit 1; }
check_version() {
  local label="$1" expected_prefix="$2" actual="$3"
  printf 'VERSION %s %s\n' "$label" "$actual"
  [[ "$actual" == "$expected_prefix"* ]] || die "$label version mismatch: $actual"
}
check_mbx_build_record() {
  local workspace="$1" label="$2" output
  if ! output="$(cd "$workspace" && mise exec --deny-net -- mbx explain --last 2>&1)"; then
    printf '%s\n' "$output" >&2
    die "$label MBX build record is unavailable"
  fi
  printf '%s\n' "$output"
  grep -Eq 'cache explanation: last recorded build' <<<"$output" || die "$label MBX build record is missing"
  grep -Eq '^[[:space:]]*results: .*([1-9][0-9]* miss)' <<<"$output" || die "$label MBX recorded no cold compiler miss"
  printf 'MBX_COMPILER_ACTION %s cold-miss-recorded\n' "$label"
}
check_owned_file() {
  local file="$1" expected="$2" actual owner mode
  test -f "$file" || die "missing file: $file"
  test -r "$file" || die "unreadable file: $file"
  owner="$(stat -Lc '%u' "$file")"
  test "$owner" = "$(id -u)" || die "unexpected owner $owner: $file"
  mode="$(stat -Lc '%a' "$file")"
  (( (8#$mode & 0022) == 0 )) || die "writable by group/other: $file ($mode)"
  actual="$(sha256sum "$file" | awk '{print $1}')"
  test "$actual" = "$expected" || die "digest mismatch: $file ($actual)"
  printf 'FILE_OK %s mode=%s sha256=%s\n' "$file" "$mode" "$actual"
}

mise_path="$(command -v mise)"
test -x "$mise_path" || die 'mise path is not executable'
test "$(id -u)" = '1000' || die "unexpected image user: $(id -u)"
printf 'IMAGE_ID uid=%s gid=%s groups=%s\n' "$(id -u)" "$(id -g)" "$(id -G)"
check_version mise '2026.9.18 ' "$(mise --version)"
check_version rustc 'rustc 1.98.1' "$(mise exec --deny-net -- rustc --version)"
check_version node 'v24.21.0' "$(mise exec --deny-net -- node --version)"
check_version npm '11.19.0' "$(mise exec --deny-net -- npm --version)"
check_version mbx 'mbx 1.22.0' "$(mise exec --deny-net -- mbx --version)"
verify_cargo_tools() {
declare -A expected_cargo_tool_version=(
  [cargo-audit]=0.22.2
  [cargo-deny]=0.20.2
  [cargo-dylint]=6.0.4
  [cargo-fuzz]=0.13.2
  [cargo-hack]=0.6.45
  [cargo-hakari]=0.9.38
  [cargo-llvm-cov]=0.8.7
  [cargo-mutants]=27.1.0
  [cargo-shear]=1.13.4
  [cargo-zigbuild]=0.23.0
  [codebook-lsp]=0.3.42
  [dylint-link]=6.0.4
  [sccache]=0.17.0
)
for tool in "${!expected_cargo_tool_version[@]}"; do
  tool_path="$(mise which "$tool")"
  tool_version="$(mise which "$tool" --version)"
  test "$tool_version" = "${expected_cargo_tool_version[$tool]}" || die "$tool version mismatch: $tool_version"
  expected_tool_path="$HOME/.local/share/mise/installs/$tool/$tool_version/bin/$tool"
  test "$tool_path" = "$expected_tool_path" || die "$tool resolved outside its pinned Mise install: $tool_path"
  test -x "$tool_path" || die "$tool path is not executable: $tool_path"
  tool_sha256="$(sha256sum "$tool_path" | awk '{print $1}')"
  printf 'CARGO_TOOL %s version=%s path=%s sha256=%s\n' "$tool" "$tool_version" "$tool_path" "$tool_sha256"
done
}
verify_cargo_tools
printf 'TOOL_PATH mise=%s cargo=%s mbx=%s node=%s npm=%s\n' \
  "$mise_path" \
  "$(mise exec --deny-net -- sh -c 'command -v cargo')" \
  "$(mise exec --deny-net -- sh -c 'command -v mbx')" \
  "$(mise exec --deny-net -- sh -c 'command -v node')" \
  "$(mise exec --deny-net -- sh -c 'command -v npm')"

mise_config="$HOME/.config/mise/config.toml"
grep -Eq 'mr_boxington[[:space:]]*=[[:space:]]*true' "$mise_config" || die 'mr_boxington Rust option is absent'
grep -Eq 'mr-boxington[[:space:]]*=[[:space:]]*"1\.22\.0"' "$mise_config" || die 'mr-boxington version pin is absent'
cargo_dispatch="$(mise exec --deny-net -- sh -c 'command -v cargo')"
verify_native_cargo_wrapper() {
  local mise_executable="$1" cargo_dispatch="$2"
  local expected_dispatch="$HOME/.local/share/mise/command-wrappers/bin/cargo"
  local wrapper_real mise_real
  test "$cargo_dispatch" = "$expected_dispatch" || die "Cargo does not resolve through Mise native wrapper: $cargo_dispatch"
  test -x "$cargo_dispatch" || die 'Mise Cargo wrapper is not executable'
  wrapper_real="$(readlink -f "$cargo_dispatch")"
  mise_real="$(readlink -f "$mise_executable")"
  test "$wrapper_real" = "$mise_real" || die "Cargo wrapper does not enter the verified Mise executable: $wrapper_real"
  printf 'MBX_WRAPPER path=%s real=%s option=mr_boxington:true\n' "$cargo_dispatch" "$wrapper_real"
}
verify_native_cargo_wrapper "$mise_path" "$cargo_dispatch"
check_version wrapped-cargo 'cargo ' "$(mise exec --deny-net -- cargo --version)"

printf 'CODEX_RUNTIME NOT_RUN; installed by Jackin in the derived agent image\n'
test -x "$HOME/.local/share/architect-node-tools/node_modules/.bin/skills" || die 'skills CLI path is missing'
test -x "$HOME/.local/share/architect-node-tools/node_modules/.bin/ctx7" || die 'ctx7 package executable is missing'
skills_version="$(node -e 'process.stdout.write(require(process.argv[1]).version)' "$HOME/.local/share/architect-node-tools/node_modules/skills/package.json")"
ctx7_version="$(node -e 'process.stdout.write(require(process.argv[1]).version)' "$HOME/.local/share/architect-node-tools/node_modules/ctx7/package.json")"
test "$skills_version" = '1.5.22' || die "skills package version mismatch: $skills_version"
test "$ctx7_version" = '0.5.11' || die "ctx7 package version mismatch: $ctx7_version"
printf 'PACKAGE_VERSION skills=%s ctx7=%s (ctx7 CLI not invoked)\n' "$skills_version" "$ctx7_version"

test "$CAVEMAN_DEFAULT_MODE" = 'ultra' || die "CAVEMAN_DEFAULT_MODE mismatch: $CAVEMAN_DEFAULT_MODE"
node -e 'const c=require(process.argv[1]); if(c.defaultMode !== "ultra") process.exit(1)' \
  "$HOME/.config/caveman/config.json" || die 'Caveman config defaultMode mismatch'
test -f "$HOME/.config/opencode/plugins/caveman/plugin.js" || die 'Caveman OpenCode plugin is missing'
check_owned_file "$HOME/.config/opencode/plugins/caveman/plugin.js" "8892c69b346b87be0709274c772bca295aba62003dc0f9fe22bcbddf88408f7a"
grep -Rq 'caveman' "$HOME/.config/opencode/opencode.json" "$HOME/.config/opencode/opencode.jsonc" 2>/dev/null || die 'OpenCode Caveman config entry is missing'
printf 'CAVEMAN_MODE %s\n' "$CAVEMAN_DEFAULT_MODE"

declare -A expected_skill_hash=(
  [cavecrew]=c05f8e8d16bd8ae1c8d0b0abf6e8b9671051bde61653c4986304c2de3a1cf5d4
  [caveman]=0bf09a0a9a017d004a81d4b693e5a2d830e1a28230a5885df773e1ed9c0571cc
  [caveman-commit]=c788a282fc75b981b421dfdad5d84ea7f83f946c126daa39cfc7d3f97845e193
  [caveman-compress]=377b0b8682d9db1a832c20ee6732ed0f19f55e4f7048955296128244c869c916
  [caveman-discover]=0483d17fce14ca5bbfcf1e085c180412dc20a672f5e8e4171fd0bbbb6f42b81a
  [caveman-evidence-review]=05bd896c76a41918fe7b87113dabe852117727a579a7e445891aa41391ed57c2
  [caveman-explore]=908f504ce45f5f8517ac7b64dc89fef57c4519d26f92b0b1843febf4b6fe2ac8
  [caveman-help]=3effbc5b8943900c7500da48f73ab9de297866705c105df1b324d4337dec3a9a
  [caveman-learn]=8b210c266f5c14cfded85b1c32b3742b4b23b4a0628b9cafa6627fd954609026
  [caveman-manage]=3404a3c8651d63b6a7c02ccda17fcb4fca2489e931bb814580979a9ff548a48e
  [caveman-optimize]=93f391beb93198b5bf9c0c21bc8b7b194e57cb7855fbf05384a4a5d6dd8c06cb
  [caveman-review]=599330563f19b5c59c3efddffcd7e8d9098b74c29817ab422ccd3253b103fcb8
  [caveman-setup]=42c8b8eeba19c6d4ffd3c421be60a7e8b5c0e5108fd4496f0be3c7ced90bfd5f
  [caveman-stats]=4632f1611a56483df7851a0dabcc1e0c1952393cd8f5d08ddeda17f81a4e1e50
  [improve]=1599aa29e9b16424cb767779efac53fa56e3f38be92dff4ac587393a1ad5070a
  [investigate-first]=7cc19dd2fc457eb20d65c44dee4d1b72dcdfcd1617182f5bff666700f2a055d8
  [jackin-brainstorm]=afda534174a35c7da4a39d3982849e05f1f123fcb732d681cdf6a6bb71e8a329
  [jackin-checkout-pr]=288ddb285e18b63847520269318849599d078d9cce72793a2222bb30b5de17f8
  [jackin-create-pr]=48ad3f63686e8d9864a8f739566846d48adce97c110f5af4fa36701df48e149d
  [jackin-goal-prompt]=b6657734102dcabca3a74104e67d4dbbb0c2876a6d184a8984c4ab7be6ac6d94
  [jackin-merge-pr]=60d1c1c8de6185173d19b803d047e1aba032cfc2f658cd0252d9a9675a0d8dc0
  [jackin-propose]=57f86f3654b317e24a52ae686a08eae3512aca43716983a7e6bd612feb221372
  [jackin-refresh-pr]=e26be1eb234040ffbc1780cc949a42b84a5d18a3ec75e361d45900c9ad0ac048
  [jackin-release]=2573a491fa5317e12a841d403f60429b1a94d3081b630127b7c0c25b415971a7
  [jackin-release-check]=c6b9fda70e51abb13280270263b36027298199da290a1ded8bb15afff3d0a7db
  [jackin-release-notes]=2e76f3efb58ed87e26959af9ffb9a00ddf068d61cd72e6c3aec5249edb9020c4
  [jackin-research]=1a0b545acdd234b3de6592f3871a359e6163cb7829b115f6c09cd8fcb5352bfc
  [lean-build]=4d498073c6312858b220e9a04b7456c2485c734edb077f6bb17d88a7ed96ad7a
  [migration]=fe7cf96a58b0521130fbb886dab2a326869d6ed0001e0306fd244014ba7a9662
  [safe-refactor]=cd52867aba26aafb53379d43068cef9b2feca3a3fff850f877a99f710ccd02c0
  [surgical-patch]=81ea9f7b51409970099e04b98875dd65806cd35472f9a774b847030328187387
  [verify-and-stop]=3d5599f49771b864eba94f27f456fda295c48c1a37fa6ba2f65fdcb13cc32acb
)
for skill in "${!expected_skill_hash[@]}"; do
  check_owned_file "$HOME/.agents/skills/$skill/SKILL.md" "${expected_skill_hash[$skill]}"
done
check_owned_file "$HOME/.claude/skills/improve/SKILL.md" "${expected_skill_hash[improve]}"
for skill in "${!expected_skill_hash[@]}"; do
  test -f "$HOME/.agents/skills/$skill/SKILL.md" || die "universal skill destination missing: $skill"
done
agent_skill_count="$(find "$HOME/.agents/skills" -mindepth 2 -maxdepth 2 -type f -name SKILL.md | wc -l | tr -d ' ')"
test "$agent_skill_count" -ge 32 || die "expected at least 32 universal skills, saw $agent_skill_count"
printf 'ADAPTER_PATHS codex=~/.agents/skills amp=~/.agents/skills opencode=~/.agents/skills kimi=~/.agents/skills claude=~/.claude/skills\n'
printf 'SKILL_COUNTS caveman=20 jackin-dev=11 shadcn-improve=1 universal-files=%s\n' "$agent_skill_count"

for agent in cavecrew-builder cavecrew-investigator cavecrew-reviewer; do
  file="$HOME/.config/opencode/agents/$agent.md"
  test -r "$file" || die "OpenCode agent missing: $file"
  ! grep -q '^tools:' "$file" || die "unexpected tools frontmatter remains: $file"
done
for agent in cavecrew-builder cavecrew-investigator cavecrew-reviewer; do
  ! grep -q '^model:' "$HOME/.config/opencode/agents/$agent.md" || die "providerless model metadata remained after installer sanitization: $agent"
done
printf 'OPENCODE_AGENT_METADATA providerless-model-fields-stripped; no agent invoked\n'

write_probe() {
  local name="$1" expected="$2" root="/tmp/architect-image-probe/$1"
  mkdir -p "$root/src"
  cat > "$root/Cargo.toml" <<EOF
[package]
name = "$name"
version = "0.1.0"
edition = "2021"
EOF
  cat > "$root/Cargo.lock" <<EOF
version = 4

[[package]]
name = "$name"
version = "0.1.0"
EOF
  cat > "$root/src/main.rs" <<EOF
fn main() { println!("$expected"); }
EOF
}

write_probe architect_mbx_probe_explicit MBX_EXPLICIT_BUILD_OK
(
  cd /tmp
  CARGO_TARGET_DIR=/tmp/architect-image-probe/target-explicit \
    mise exec --deny-net -- mbx build --locked --offline --manifest-path /tmp/architect-image-probe/architect_mbx_probe_explicit/Cargo.toml
)
test "$(/tmp/architect-image-probe/target-explicit/debug/architect_mbx_probe_explicit)" = 'MBX_EXPLICIT_BUILD_OK' || die 'explicit MBX build probe output mismatch'
printf 'MBX_BUILD_ROUTE explicit-mbx-build PASS\n'
check_mbx_build_record /tmp/architect-image-probe/architect_mbx_probe_explicit explicit-mbx

write_probe architect_mise_cargo_probe MISE_CARGO_WRAPPER_BUILD_OK
(
  cd /tmp
  CARGO_TARGET_DIR=/tmp/architect-image-probe/target-mise \
    mise exec --deny-net -- cargo build --locked --offline --manifest-path /tmp/architect-image-probe/architect_mise_cargo_probe/Cargo.toml
)
test "$(/tmp/architect-image-probe/target-mise/debug/architect_mise_cargo_probe)" = 'MISE_CARGO_WRAPPER_BUILD_OK' || die 'Mise Cargo wrapper build probe output mismatch'
printf 'MBX_BUILD_ROUTE mise-cargo-wrapper PASS\n'
check_mbx_build_record /tmp/architect-image-probe/architect_mise_cargo_probe mise-cargo-wrapper

printf 'IMAGE_VALIDATION PASS no network, credentials, ctx7 invocation, skill invocation, or model invocation\n'
