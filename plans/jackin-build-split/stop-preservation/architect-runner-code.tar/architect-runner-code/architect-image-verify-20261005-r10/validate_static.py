from __future__ import annotations

import csv
import hashlib
from pathlib import Path
import re
import subprocess


REPO = Path("/root/Projects/tailrocks/jackin-project/jackin-the-architect-task")
WORK = Path("/root/.velnor-work/architect-image-verify-20261005-r10")
ASSET_AUDIT = Path("/root/.velnor-work/architect-prebuilt-asset-audit-20261005/asset-audit.tsv")
EXPECTED_COMMIT = "818ea17a727ec1ace911be44d78b13995e3f6571"
EXPECTED_TREE = "567569245dfb4c170ba22469aba7ecb5746ed3cc"
EXPECTED_AUDIT_SHA256 = "a465ae0d0d0ffc0795d0ffcd0ce90d5cdd14aa2c64c9a6175e18ff2ff05e14b7"


def main() -> None:
    clean_env = {
        "HOME": str(WORK),
        "PATH": "/usr/bin:/bin",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_NO_REPLACE_OBJECTS": "1",
        "GIT_OPTIONAL_LOCKS": "0",
    }
    commit = subprocess.run(
        ["/usr/bin/git", "-C", str(REPO), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
        env=clean_env,
    ).stdout.strip()
    tree = subprocess.run(
        ["/usr/bin/git", "-C", str(REPO), "rev-parse", "HEAD^{tree}"],
        check=True,
        capture_output=True,
        text=True,
        env=clean_env,
    ).stdout.strip()
    if (commit, tree) != (EXPECTED_COMMIT, EXPECTED_TREE):
        raise SystemExit(f"source identity mismatch: {commit} {tree}")
    if hashlib.sha256(ASSET_AUDIT.read_bytes()).hexdigest() != EXPECTED_AUDIT_SHA256:
        raise SystemExit("official prebuilt asset audit digest mismatch")
    dockerfile = (REPO / "Dockerfile").read_text()
    with ASSET_AUDIT.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    if len(rows) != 22:
        raise SystemExit(f"expected 22 official assets, found {len(rows)}")
    for row in rows:
        arch = "amd64" if row["target_triple"].startswith("x86_64-") else "arm64"
        key = f"{row['package']}@{row['version']}:{arch}"
        start = dockerfile.index(f"            {key}) \\\n")
        end = dockerfile.index("                ;; \\\n", start)
        block = dockerfile[start:end]
        fields: dict[str, str] = {}
        for field in ("asset_repo", "release_path", "asset_filename", "asset_sha256", "executable_member"):
            match = re.search(rf"\b{field}=([^;\\\n]+)", block)
            if not match:
                raise SystemExit(f"missing Dockerfile field: {key} {field}")
            fields[field] = match.group(1).strip()
        actual_url = (
            f"https://github.com/{fields['asset_repo']}/releases/download/"
            f"{fields['release_path']}/{fields['asset_filename']}"
        )
        if (
            actual_url != row["asset_url"]
            or fields["asset_sha256"] != row["official_sha256"]
            or fields["executable_member"] != row["executable_member"]
        ):
            raise SystemExit(f"release source mismatch: {key}")
        arch_label = "aarch64" if arch == "arm64" else "x86_64"
        archive = ASSET_AUDIT.parent / f"{row['package']}_{arch_label}.archive"
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        if digest != row["official_sha256"] or digest != row["download_sha256"]:
            raise SystemExit(f"asset byte digest mismatch: {key}")
        compression = ["--xz"] if row["asset_filename"].endswith(".tar.xz") else ["--gzip"]
        streamed = subprocess.run(
            [
                "/usr/bin/tar",
                "--extract",
                *compression,
                "--file",
                str(archive),
                "--to-stdout",
                "--no-wildcards",
                "--",
                row["executable_member"],
            ],
            check=True,
            capture_output=True,
        ).stdout
        if not streamed.startswith(b"\x7fELF"):
            raise SystemExit(f"archive member is not ELF: {key}")
    installer_lines = dockerfile.splitlines()
    installer_start = next(
        i for i, line in enumerate(installer_lines)
        if line.startswith("RUN . ~/.profile && set -eu; \\")
    )
    installer_shell: list[str] = []
    for line_number, line in enumerate(installer_lines[installer_start:]):
        stripped = line.rstrip()
        if line_number == 0:
            stripped = stripped.removeprefix("RUN ")
        if stripped.endswith("\\"):
            installer_shell.append(stripped[:-1] + " ")
        else:
            installer_shell.append(stripped)
            break
    installer_text = "\n".join(installer_shell)
    if "umask 022;" not in installer_text or "--no-same-owner --no-same-permissions" not in installer_text:
        raise SystemExit("pinned installer source permissions are not masked")
    subprocess.run(["/bin/bash", "-n"], input=installer_text, text=True, check=True)
    lines = dockerfile[dockerfile.index("# Install checksum-verified upstream binaries"):].splitlines()
    start = next(i for i, line in enumerate(lines) if line == "    set -eu; \\")
    shell: list[str] = []
    for line in lines[start:]:
        if line.rstrip().endswith("\\"):
            shell.append(line.rstrip()[:-1] + " ")
        else:
            shell.append(line)
            break
    subprocess.run(["/bin/bash", "-n"], input="\n".join(shell), text=True, check=True)
    subprocess.run(
        ["/usr/bin/git", "-C", str(REPO), "show", "--check", "--oneline", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
        env=clean_env,
    )
    print(f"SOURCE {commit} TREE {tree}")
    print(f"ASSET_CASES {len(rows)} URL_HASH_MEMBER_MATCH")
    print("ASSET_BYTES 22_SHA256_MATCH TAR_STDOUT_ELF PASS")
    print("SOURCE_INSTALLER_RUN_BASH_N PASS; archive permission mask PRESENT")
    print("DOCKER_RUN_BASH_N PASS")
    print("GIT_SHOW_CHECK PASS")
    print("NO_DOCKER_OR_RUST_EXECUTION")


if __name__ == "__main__":
    main()
