#!/usr/bin/bash
# Exact-source, offline MBX route for the pinned PR #1111 corrected 24b8 commit.
# Run one phase at a time with a clean environment; do not invoke build phases before independent approval.
set -Eeuo pipefail
umask 077
readonly EVIDENCE=/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8
readonly SELF=/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/launcher-pr1111-24b8-v13.sh
readonly TASK_ROOT=/opt/.jackin-pr1111-24b8-mbx-20261005-v1
readonly ROOTFS=/opt/.jackin-mbx-current-17b2b1b-v5-62dfd1ac/rootfs-clean-3986dfdd-v1
readonly WORK=${TASK_ROOT}/work
readonly OUT_DIR=${WORK}/out
readonly SOURCE_DIR=${TASK_ROOT}/source-24b8d5423a212130e4a1c60beffed860248b7f27
readonly SEED_SNAPSHOT=${TASK_ROOT}/seed-cargo-home
readonly SEED_REGISTRY=${SEED_SNAPSHOT}/registry
readonly SEED_GIT=${SEED_SNAPSHOT}/git
readonly SOURCE_HELPER=${EVIDENCE}/source-rebind-24b8-v4.py
readonly SOURCE_HELPER_SHA256=be26db1164e8f8cae10b3fdce8978f4b392d8f759b0cd58ec8e11c069706be27
readonly SOURCE_FIXTURE=${EVIDENCE}/source-rebind-fixture-24b8-v4.py
readonly SOURCE_FIXTURE_SHA256=16396828fe8f9be90add3e77dfbf8cd02273e576274ce3892aefd20a629477f2
readonly SOURCE_STATE_FIXTURE=${EVIDENCE}/source-state-fixture-24b8-v15.py
readonly SOURCE_STATE_FIXTURE_SHA256=8ac459ee068af4e60ecf80d5bb94a11fa110d0a48b19bd3a9384c9b671a0a89a
readonly ROOTFS_HELPER=/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-current-17b2b1b/rootfs-clone-tools-3986dfdd-v1.py
readonly ROOTFS_HELPER_SHA256=44943b28c536e6e504b8c7ee8c5176cfba302070f979e2e60fc34734297ec873
readonly ROOTFS_PASS_MARKER=/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-current-17b2b1b/rootfs-clean-3986dfdd-v5.pass
readonly ROOTFS_PASS_MARKER_SHA256=10bf5c7bf1a8a70211762a8413bef236184d7f58ef89c2e415ac1fbb21fd47c7
readonly ROOTFS_PASS_CONTENT='rootfs_clone=PASS helper_sha256=44943b28c536e6e504b8c7ee8c5176cfba302070f979e2e60fc34734297ec873 delta_sha256=5c3ac4edd660aae7b060e01de1d13c37fe22b2907fcd771e34f41c3eca1f75cf'
readonly SOURCE_ARCHIVE=/root/.jackin-pr1111-source-24b8-20261005/jackin-24b8d5423a212130e4a1c60beffed860248b7f27.tar
readonly SOURCE_ARCHIVE_SHA256=c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a
readonly SOURCE_ARCHIVE_SIZE=39147520
readonly SOURCE_PACKET=/root/.jackin-pr1111-source-24b8-20261005/source-packet.md
readonly SOURCE_PACKET_SHA256=22a0a9e3a777fbac13c3fbbec01505ab53bb3ebe18acc3d91f3fb1cfbe28bf2a
readonly SOURCE_COMMIT=24b8d5423a212130e4a1c60beffed860248b7f27
readonly SOURCE_TREE=63e21941838f728583e22220e9432f6afceb90b9
readonly SOURCE_CARGO_LOCK_SHA256=5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097
readonly SOURCE_MISE_TOML_SHA256=c7f84dc3562e423814617ae55acc27e97f9a5f367d1ea6fbef56bb5e11ef2c8e
readonly SOURCE_MISE_LOCK_SHA256=ac3b0998f110538c5bb34f2653afaf7f2713d7f9f026dde1bb3f50845cef06ef
readonly SOURCE_TOOLCHAIN_SHA256=d62dfea7074d89dd8c5e26fbde9e3cf1e9480b8b7a89165ed18177b0d43c9dbf
readonly SOURCE_VELNOR_SHA256=17af85b335ebaa266bdbf488cf1f11634cea14eb16730cfd06fbc33078f2cd61
readonly BASE_CREATOR=/root/.velnor-work/mbx-review.uXg3BZsJ/launcher-build-measurements-v8.sh
readonly BASE_CREATOR_SHA256=45291b393424ab976f8181b8001e08ce3210014d0666ced45d179db7705a37ca
readonly HOST_RUNTIME_MANIFEST=/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-current-17b2b1b/host-runtime-provenance-v4.json
readonly HOST_RUNTIME_MANIFEST_SHA256=ce49f0e9447b396ff66355282275588650afe5ef3553dea8e3566e71846f2253
readonly ROOTFS_MARKER=preflight-rootfs-24b8-v3.pass
readonly SOURCE_MARKER=source-recovery-24b8-v1.pass
readonly SEED_MARKER=seed-verify-24b8-v3.pass
readonly ROUTE_MARKER=tool-route-24b8-v3.pass
readonly METADATA_MARKER=metadata-resolution-24b8-v3.pass
readonly CLIPPY_MARKER=clippy-24b8-v3.pass
readonly TESTS_MARKER=tests-24b8-v3.pass
readonly MISE_VERSION=2026.10.1
readonly RUST_VERSION=1.97.1
readonly RUST_TOOLCHAIN=1.97.1-x86_64-unknown-linux-gnu
readonly ALLOWED_PHASES='source-recover-marker verify-source'

if [[ ${0##*/} != __jackin_24b8_v13_clean__ ]]; then
  exec /usr/bin/env -i PATH=/usr/sbin:/usr/bin:/sbin:/bin /usr/bin/python3 -I -c '
import ctypes,os,stat,sys
script,*args=sys.argv[1:]
expected="/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/launcher-pr1111-24b8-v13.sh"
if script!=expected: raise SystemExit("unexpected launcher path")
fd=os.open(script,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(0,0,0o600) or st.st_size>131072: raise SystemExit("unsafe launcher file")
with os.fdopen(fd,"rb") as f: source=f.read().decode("utf-8")
libc=ctypes.CDLL(None,use_errno=True); close_range=getattr(libc,"close_range",None)
if close_range is None: raise SystemExit("libc close_range unavailable")
close_range.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.c_uint]; close_range.restype=ctypes.c_int
if close_range(3,0xffffffff,0)!=0: raise OSError(ctypes.get_errno(),"close_range failed")
os.execve("/usr/bin/bash",["/usr/bin/bash","-c",source,"__jackin_24b8_v13_clean__",*args],{"PATH":"/usr/sbin:/usr/bin:/sbin:/bin"})
' "$0" "$@"
fi

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
verify_evidence_dir() {
  /usr/bin/python3 -I - "$EVIDENCE" <<'PY'
import os,pathlib,stat,sys
p=pathlib.PurePosixPath(sys.argv[1]); fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
    for i,name in enumerate(p.parts[1:],1):
        nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(nxt)
        if st.st_uid!=0 or st.st_gid!=0 or st.st_mode&0o022: os.close(nxt); raise SystemExit('unsafe evidence path component: '+name)
        if i==len(p.parts)-1 and stat.S_IMODE(st.st_mode)!=0o700: os.close(nxt); raise SystemExit('unsafe evidence directory mode')
        os.close(fd); fd=nxt
finally: os.close(fd)
PY
}
verify_pinned_file() {
  /usr/bin/python3 -I - "$1" "$2" "$3" "$4" <<'PY'
import hashlib,os,pathlib,stat,sys
path,want,mode,max_size=sys.argv[1:]; mode=int(mode,8); max_size=int(max_size)
p=pathlib.PurePosixPath(path)
if not p.is_absolute() or any(x in ('','.','..') for x in p.parts[1:]): raise SystemExit('unsafe pinned path')
fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
    for name in p.parts[1:-1]:
        nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(nxt)
        if not stat.S_ISDIR(st.st_mode) or st.st_uid!=0 or st.st_gid!=0 or st.st_mode&0o022: os.close(nxt); raise SystemExit('unsafe pinned ancestor: '+name)
        os.close(fd); fd=nxt
    leaf=os.open(p.name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(leaf)
    if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,mode,1) or st.st_size<=0 or st.st_size>max_size: os.close(leaf); raise SystemExit('unsafe pinned file: '+path)
    h=hashlib.sha256()
    with os.fdopen(leaf,'rb') as stream:
        while True:
            block=stream.read(1024*1024)
            if not block: break
            h.update(block)
    if h.hexdigest()!=want: raise SystemExit('pinned file digest mismatch: '+path)
finally: os.close(fd)
PY
}
verify_rootfs_marker() {
  verify_pinned_file "$ROOTFS_PASS_MARKER" "$ROOTFS_PASS_MARKER_SHA256" 600 4096
  /usr/bin/python3 -I - "$ROOTFS_PASS_MARKER" "$ROOTFS_PASS_CONTENT" <<'PY'
import os,sys
p,want=sys.argv[1:]; fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
with os.fdopen(fd,'rb') as f: raw=f.read(4097)
if raw!=(want+'\n').encode(): raise SystemExit('rootfs pass marker content mismatch')
PY
}
verify_source_helper_artifact() {
  verify_pinned_file "$SOURCE_HELPER" "$SOURCE_HELPER_SHA256" 600 65536
  verify_pinned_file "$SOURCE_FIXTURE" "$SOURCE_FIXTURE_SHA256" 600 65536
  verify_pinned_file "$SOURCE_STATE_FIXTURE" "$SOURCE_STATE_FIXTURE_SHA256" 600 65536
}
verify_source_packet_fixture() {
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5s 5m /usr/bin/python3 -I "$SOURCE_FIXTURE"
}
verify_source_state_fixture() {
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5s 5m /usr/bin/python3 -I "$SOURCE_STATE_FIXTURE" "$SELF"
}
verify_host_runtime() {
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5s 5m /usr/bin/python3 -I - "$HOST_RUNTIME_MANIFEST" "$HOST_RUNTIME_MANIFEST_SHA256" "$BASE_CREATOR" "$BASE_CREATOR_SHA256" <<'PY'
import hashlib,json,os,pathlib,stat,subprocess,sys
manifest_path,manifest_hash,creator_path,creator_hash=sys.argv[1:]
def open_root_file(path,limit,mode):
    parts=pathlib.PurePosixPath(path); parent=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        for name in parts.parts[1:-1]:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); st=os.fstat(nxt)
            if st.st_uid!=0 or st.st_gid!=0 or st.st_mode&0o022: os.close(nxt); raise SystemExit('unsafe evidence ancestor: '+name)
            os.close(parent); parent=nxt
        fd=os.open(parts.parts[-1],os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,mode,1) or st.st_size<0 or st.st_size>limit: os.close(fd); raise SystemExit('unsafe pinned evidence file: '+path)
        with os.fdopen(fd,'rb') as stream: data=stream.read(limit+1)
        if len(data)!=st.st_size or len(data)>limit: raise SystemExit('pinned evidence size changed: '+path)
        return data
    finally: os.close(parent)
creator=open_root_file(creator_path,131072,0o600)
if hashlib.sha256(creator).hexdigest()!=creator_hash: raise SystemExit('base creator digest mismatch')
raw=open_root_file(manifest_path,1024*1024,0o600)
if hashlib.sha256(raw).hexdigest()!=manifest_hash: raise SystemExit('host runtime provenance digest mismatch')
m=json.loads(raw)
if m.get('schema')!='jackin-debian-host-runtime-provenance-v4' or m.get('base_rootfs_creator')!=creator_path or m.get('base_rootfs_creator_sha256')!=creator_hash: raise SystemExit('host runtime provenance identity mismatch')
if m.get('dpkg_verify',{}).get('status')!=0 or m.get('dpkg_verify',{}).get('output')!='': raise SystemExit('captured Debian package verification was not clean')
def metadata(st): return {'uid':st.st_uid,'gid':st.st_gid,'mode':stat.S_IMODE(st.st_mode),'size':st.st_size,'type':'symlink' if stat.S_ISLNK(st.st_mode) else 'regular' if stat.S_ISREG(st.st_mode) else 'other'}
def hash_resolved(path):
    p=pathlib.PurePosixPath(path); parent=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        for name in p.parts[1:-1]:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); os.close(parent); parent=nxt
        fd=os.open(p.parts[-1],os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode): os.close(fd); raise SystemExit('runtime target is not regular: '+path)
        h=hashlib.sha256()
        with os.fdopen(fd,'rb') as stream:
            while True:
                block=stream.read(1024*1024)
                if not block: break
                h.update(block)
        return h.hexdigest(),metadata(st)
    finally: os.close(parent)
def verify_record(rec):
    path=rec.get('path'); resolved=rec.get('resolved')
    if not isinstance(path,str) or not path.startswith('/') or not isinstance(resolved,str) or not resolved.startswith('/'): raise SystemExit('malformed runtime provenance path')
    actual=os.lstat(path)
    if metadata(actual)!=rec.get('lstat'): raise SystemExit('host runtime metadata changed: '+path)
    link=rec.get('symlink_target')
    if stat.S_ISLNK(actual.st_mode):
        if link is None or os.readlink(path)!=link: raise SystemExit('host runtime symlink changed: '+path)
    elif link is not None: raise SystemExit('host runtime path lost expected symlink: '+path)
    if os.path.realpath(path)!=resolved: raise SystemExit('host runtime resolution changed: '+path)
    digest,meta=hash_resolved(resolved)
    if meta!=rec.get('resolved_lstat') or digest!=rec.get('sha256'): raise SystemExit('host runtime target changed: '+path)
records=list(m.get('direct_runtime_paths',[]))
for name,item in m.get('elf_loader_dependencies',{}).items():
    if item.get('status')!=0 or 'not found' in item.get('output',''): raise SystemExit('captured ELF dependency resolution failed: '+name)
    records.extend(item.get('libraries',[]))
for name,item in m.get('gcc_child_tool_resolution',{}).items():
    if item.get('status')!=0: raise SystemExit('captured GCC child tool resolution failed: '+name)
    records.append(item.get('file_provenance',{}))
if len(records)<38: raise SystemExit('host runtime provenance is incomplete')
for rec in records: verify_record(rec)
packages=m.get('verified_package_versions')
if not isinstance(packages,dict) or not packages or any(not isinstance(x,str) or not x or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.:_-' for c in x) for x in packages): raise SystemExit('invalid pinned Debian package list')
if m['dpkg_verify'].get('argv')!=['/usr/bin/dpkg','--verify',*packages.keys()]: raise SystemExit('unexpected Debian verification command')
for package,pinned in packages.items():
    if not isinstance(pinned,dict) or pinned.get('status')!=0 or not isinstance(pinned.get('output'),str) or pinned.get('argv')!=['/usr/bin/dpkg-query','-W','-f=${binary:Package}\t${Version}\n',package]: raise SystemExit('malformed pinned Debian package record')
    query=subprocess.run(pinned['argv'],capture_output=True,text=True,timeout=30,check=False)
    if query.returncode!=0 or query.stdout!=pinned['output']+'\n' or query.stderr: raise SystemExit('Debian package version changed: '+package)
verify=subprocess.run(m['dpkg_verify']['argv'],capture_output=True,text=True,timeout=120,check=False)
if verify.returncode!=0 or verify.stdout or verify.stderr: raise SystemExit('Debian package verification is not clean')
mount=m.get('host_usr_mount',{})
if mount.get('argv')!=['/usr/bin/findmnt','-no','SOURCE,FSTYPE,OPTIONS','/usr']: raise SystemExit('unexpected host /usr probe')
mounted=subprocess.run(mount['argv'],capture_output=True,text=True,timeout=10,check=False)
if mounted.returncode!=mount.get('status') or mounted.stdout!=mount.get('output') or mounted.stderr: raise SystemExit('host /usr mount state changed')
release=open('/usr/lib/os-release','rb').read(65537).decode()
if len(release)>65536 or release!=m.get('host_release'): raise SystemExit('Debian release identity changed')
print('host_runtime_provenance=PASS direct_paths=%d elf_objects=%d packages=%d'%(len(m.get('direct_runtime_paths',[])),len(m.get('elf_loader_dependencies',{})),len(packages)))
PY
}
need_host() {
  [[ $(/usr/bin/id -u) == 0 ]] || die 'effective uid is not zero'
  [[ $(/usr/bin/hostname -s) == bastion ]] || die 'host is not bastion'
  verify_evidence_dir
  [[ -d /opt && ! -L /opt && $(/usr/bin/stat -c '%u:%g:%a' /opt) == 0:0:755 ]] || die '/opt ownership or mode changed'
}
no_builder_processes() {
  if /usr/bin/pgrep -u 65534 >/dev/null 2>&1; then die 'uid 65534 already has a process'; fi
}
no_task_mounts() {
  if /usr/bin/findmnt -rn -o TARGET | /usr/bin/awk -v p="$TASK_ROOT" -v r="$ROOTFS" '$0==p || index($0,p"/")==1 || $0==r || index($0,r"/")==1 { found=1 } END { exit !found }'; then die 'task-owned or reused-rootfs mount remains'; fi
}
no_usr_submounts() {
  if /usr/bin/findmnt -rn -o TARGET | /usr/bin/awk '$0 ~ /^\/usr\// { found=1 } END { exit !found }'; then die 'nested mount below /usr prevents safe read-only bind'; fi
}
verify_task_state() {
  local want_seed=${1:-no}
  /usr/bin/python3 -I - "$TASK_ROOT" "$WORK" "$SOURCE_DIR" "$OUT_DIR" "$SEED_SNAPSHOT" "$want_seed" <<'PY'
import os,pathlib,stat,sys
TASK,WORK,SOURCE,OUT,SEED,want_seed=sys.argv[1:]
def check_dir(parent,name,uid,gid,mode):
    fd=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); st=os.fstat(fd)
    if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(uid,gid,mode): os.close(fd); raise SystemExit('unsafe directory identity: '+name)
    return fd
def open_absolute(path):
    p=pathlib.PurePosixPath(path); fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        for name in p.parts[1:]:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or st.st_uid!=0 or st.st_gid!=0 or st.st_mode&0o022: os.close(nxt); raise SystemExit('unsafe ancestor: '+name)
            os.close(fd); fd=nxt
        return fd
    except BaseException:
        os.close(fd); raise
opt=open_absolute('/opt')
task=check_dir(opt,os.path.basename(TASK),0,0,0o700); os.close(opt)
expected={'work',os.path.basename(SOURCE)}
if want_seed=='yes': expected.add(os.path.basename(SEED))
if set(os.listdir(task))!=expected: raise SystemExit('task-root inventory mismatch')
work=check_dir(task,'work',65534,65534,0o700)
expected_work={'home','tmp','cargo-home','rustup-home','mise-data','mise-cache','mise-config','xdg-cache','xdg-config','xdg-data','xdg-state','target','mbx-cache','out','.phase.sh'}
if set(os.listdir(work))!=expected_work: raise SystemExit('task work inventory mismatch')
phase=os.open('.phase.sh',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=work); ps=os.fstat(phase)
if not stat.S_ISREG(ps.st_mode) or (ps.st_uid,ps.st_gid,stat.S_IMODE(ps.st_mode),ps.st_nlink,ps.st_size)!=(0,0,0o444,1,len(b'jackin-24b8-phase-mountpoint-v1\n')): os.close(phase); raise SystemExit('unsafe private phase mountpoint')
if os.read(phase,128)!=b'jackin-24b8-phase-mountpoint-v1\n': os.close(phase); raise SystemExit('private phase mountpoint content mismatch')
os.close(phase)
for name in sorted(expected_work-{'out','.phase.sh'}):
    fd=check_dir(work,name,65534,65534,0o700)
    if name=='cargo-home' and set(os.listdir(fd))!={'registry','git'}: raise SystemExit('task Cargo home inventory mismatch')
    os.close(fd)
cargo=os.open('cargo-home',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=work)
for name in ('registry','git'):
    child=check_dir(cargo,name,65534,65534,0o700)
    if os.listdir(child): raise SystemExit('Cargo seed mountpoint is not empty: '+name)
    os.close(child)
os.close(cargo)
out=check_dir(work,'out',65534,65534,0o700); os.close(out)
source=check_dir(task,os.path.basename(SOURCE),0,0,0o755); os.close(source)
if want_seed=='yes':
    seed=check_dir(task,os.path.basename(SEED),0,0,0o700)
    if set(os.listdir(seed))!={'registry','git'}: raise SystemExit('private Cargo snapshot inventory mismatch')
    for name in ('registry','git'):
        child=check_dir(seed,name,65534,65534,0o700); os.close(child)
    os.close(seed)
os.close(work); os.close(task)
print('task_state=PASS seed_snapshot='+want_seed)
PY
}
check_rootfs_mountpoints() {
  /usr/bin/python3 -I - "$ROOTFS" <<'PY'
import os,stat,sys
root=sys.argv[1]; fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(0,0,0o755): raise SystemExit('rootfs root metadata mismatch')
work=os.open('work',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
if os.listdir(work): raise SystemExit('verified rootfs /work mountpoint is not empty')
source=os.open('source',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
if not os.listdir(source): raise SystemExit('historical rootfs /source mountpoint unexpectedly empty')
print('rootfs_mountpoints=PASS work_empty=true historical_source_nonempty=true')
os.close(source); os.close(work); os.close(fd)
PY
}
verify_rootfs() {
  verify_pinned_file "$ROOTFS_HELPER" "$ROOTFS_HELPER_SHA256" 600 131072
  verify_rootfs_marker
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 25m /usr/bin/python3 -I "$ROOTFS_HELPER" verify
  check_rootfs_mountpoints
}
verify_source() {
  verify_source_helper_artifact
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5s 5m /usr/bin/python3 -I "$SOURCE_HELPER" verify
}
write_pass_marker() {
  /usr/bin/python3 -I - "$EVIDENCE" "$1" "$2" <<'PY'
import os,stat,sys
root,name,payload=sys.argv[1:]
if '/' in name or name in ('','.','..'): raise SystemExit('unsafe pass marker name')
fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(0,0,0o700): raise SystemExit('unsafe evidence directory')
try: os.stat(name,dir_fd=fd,follow_symlinks=False)
except FileNotFoundError: pass
else: raise SystemExit('pass marker already exists; preserve it and use a new launcher version')
out=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=fd)
raw=(payload+'\n').encode(); view=memoryview(raw)
while view: view=view[os.write(out,view):]
os.fsync(out); os.close(out); os.fsync(fd); os.close(fd)
print('pass_marker='+name)
PY
}
require_pass_marker() {
  /usr/bin/python3 -I - "$EVIDENCE" "$1" "$2" <<'PY'
import os,stat,sys
root,name,want=sys.argv[1:]; fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(0,0,0o700): raise SystemExit('unsafe evidence directory')
f=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(f)
if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,0o600,1) or st.st_size>4096: os.close(f); raise SystemExit('unsafe phase marker')
with os.fdopen(f,'rb') as stream: data=stream.read(4097)
os.close(fd)
if data!=(want+'\n').encode(): raise SystemExit('phase predecessor marker mismatch: '+name)
print('predecessor_marker=PASS '+name)
PY
}
preflight_rootfs() {
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  verify_host_runtime
  verify_rootfs
  /usr/bin/python3 -I - "$TASK_ROOT" <<'PY'
import os,stat,sys
path=sys.argv[1]; fd=os.open('/opt',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try: os.stat(os.path.basename(path),dir_fd=fd,follow_symlinks=False)
except FileNotFoundError: pass
else: raise SystemExit('task root already exists; preserve it and use a fresh task-root version')
os.close(fd)
PY
  printf 'rootfs=%s\nsource_commit=%s\nsource_tree=%s\narchive_sha256=%s\npacket_sha256=%s\n' "$ROOTFS" "$SOURCE_COMMIT" "$SOURCE_TREE" "$SOURCE_ARCHIVE_SHA256" "$SOURCE_PACKET_SHA256"
  write_pass_marker "$ROOTFS_MARKER" "rootfs-preflight=PASS rootfs=$ROOTFS helper=$ROOTFS_HELPER_SHA256 marker=$ROOTFS_PASS_MARKER_SHA256"
}
source_rebind() {
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  require_pass_marker "$ROOTFS_MARKER" "rootfs-preflight=PASS rootfs=$ROOTFS helper=$ROOTFS_HELPER_SHA256 marker=$ROOTFS_PASS_MARKER_SHA256"
  verify_rootfs_marker; verify_source_helper_artifact
  verify_source_packet_fixture
  verify_source_state_fixture
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 10m /usr/bin/python3 -I "$SOURCE_HELPER" prepare
  verify_source
  verify_task_state no
  write_pass_marker "$SOURCE_MARKER" "source-recovery=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE archive=$SOURCE_ARCHIVE_SHA256 packet=$SOURCE_PACKET_SHA256 helper=$SOURCE_HELPER_SHA256 fixture=$SOURCE_FIXTURE_SHA256 state_fixture=$SOURCE_STATE_FIXTURE_SHA256"
}
source_recover_marker() {
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  require_pass_marker "$ROOTFS_MARKER" "rootfs-preflight=PASS rootfs=$ROOTFS helper=$ROOTFS_HELPER_SHA256 marker=$ROOTFS_PASS_MARKER_SHA256"
  verify_rootfs_marker; verify_source_helper_artifact
  verify_source_packet_fixture
  verify_source_state_fixture
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 10m /usr/bin/python3 -I "$SOURCE_HELPER" verify
  verify_task_state no
  write_pass_marker "$SOURCE_MARKER" "source-recovery=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE archive=$SOURCE_ARCHIVE_SHA256 packet=$SOURCE_PACKET_SHA256 helper=$SOURCE_HELPER_SHA256 fixture=$SOURCE_FIXTURE_SHA256 state_fixture=$SOURCE_STATE_FIXTURE_SHA256"
}
verify_source_phase() {
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  require_pass_marker "$ROOTFS_MARKER" "rootfs-preflight=PASS rootfs=$ROOTFS helper=$ROOTFS_HELPER_SHA256 marker=$ROOTFS_PASS_MARKER_SHA256"
  require_pass_marker "$SOURCE_MARKER" "source-recovery=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE archive=$SOURCE_ARCHIVE_SHA256 packet=$SOURCE_PACKET_SHA256 helper=$SOURCE_HELPER_SHA256 fixture=$SOURCE_FIXTURE_SHA256 state_fixture=$SOURCE_STATE_FIXTURE_SHA256"
  verify_source; verify_task_state no
}

readonly SEED_SNAPSHOT_HELPER=${EVIDENCE}/cargo-seed-snapshot-24b8-v3.py
readonly SEED_SNAPSHOT_HELPER_SHA256=dea94ae043e368c3d0d2b76ebf2d743c1b0ba6a0396e5fa6a9461e45f360e609
readonly SEED_VERIFIER=${EVIDENCE}/cargo-seed-verify-24b8-v3.py
readonly SEED_VERIFIER_SHA256=3d7f76376b421ea82f83c798ba7750c468fed1eb145e459c1d561e292c184efc
readonly SNAPSHOT_FIXTURE=${EVIDENCE}/cargo-seed-snapshot-fixture-24b8-v3.py
readonly SNAPSHOT_FIXTURE_SHA256=5ffe18d8c9435f4e55c859908f5f1e14bd21a22d57a5ac627409e7c68b3cfe5e
readonly GIT_GUARD_FIXTURE=${EVIDENCE}/cargo-seed-verify-fixture-24b8-v3.py
readonly GIT_GUARD_FIXTURE_SHA256=3b27b1737cb6b750b19a9eecead41ced3d1f881f1b38949f82b02221c1039bd5
readonly SEED_MANIFEST=${EVIDENCE}/cargo-seed-24b8-v3.json
readonly SEED_MANIFEST_NAME=cargo-seed-24b8-v3.json
readonly SEED_SCHEMA=jackin-cargo-source-seed-24b8-v3
readonly SNAPSHOT_HELPER_PAYLOAD='cargo_seed_snapshot=PASS roots=registry,git'

verify_seed_artifacts() {
  verify_pinned_file "$SEED_SNAPSHOT_HELPER" "$SEED_SNAPSHOT_HELPER_SHA256" 600 65536
  verify_pinned_file "$SEED_VERIFIER" "$SEED_VERIFIER_SHA256" 600 65536
  verify_pinned_file "$SNAPSHOT_FIXTURE" "$SNAPSHOT_FIXTURE_SHA256" 600 65536
  verify_pinned_file "$GIT_GUARD_FIXTURE" "$GIT_GUARD_FIXTURE_SHA256" 600 65536
}
verify_seed_manifest() {
  /usr/bin/python3 -I - "$EVIDENCE" "$SEED_MANIFEST_NAME" "$SEED_MANIFEST_SHA256_EXPECTED" "$SEED_SCHEMA" "$SEED_SNAPSHOT" "$SOURCE_COMMIT" "$SOURCE_TREE" "$SOURCE_CARGO_LOCK_SHA256" <<'PY'
import hashlib,json,os,stat,sys
root,name,want,schema,seed,commit,tree,lock=sys.argv[1:]
dfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); ds=os.fstat(dfd)
if (ds.st_uid,ds.st_gid,stat.S_IMODE(ds.st_mode))!=(0,0,0o700): raise SystemExit('unsafe Cargo manifest evidence directory')
fd=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd); st=os.fstat(fd)
if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,0o600,1) or st.st_size<=0 or st.st_size>64*1024*1024: os.close(fd); raise SystemExit('unsafe Cargo seed manifest')
h=hashlib.sha256(); chunks=[]
with os.fdopen(fd,'rb') as stream:
    while True:
        block=stream.read(1024*1024)
        if not block: break
        chunks.append(block); h.update(block)
os.close(dfd); raw=b''.join(chunks)
if h.hexdigest()!=want: raise SystemExit('Cargo seed manifest digest differs from pass marker')
m=json.loads(raw)
if (m.get('schema'),m.get('seed_root'),m.get('source_commit'),m.get('source_tree'),m.get('cargo_lock_sha256'))!=(schema,seed,commit,tree,lock): raise SystemExit('Cargo seed manifest identity mismatch')
if (m.get('source_archive_sha256'),m.get('included_roots'),m.get('registry_packages'),m.get('git_packages'),m.get('registry_archive_checksums_verified'),m.get('registry_extracted_crates_content_verified'),m.get('git_checkout_blobs_verified'))!=('c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a',['registry','git'],762,3,762,762,3): raise SystemExit('Cargo seed manifest coverage mismatch')
if m.get('snapshot_method')!='task-root-private FICLONE of registry and git only': raise SystemExit('Cargo seed snapshot method mismatch')
rows=m.get('inventory')
if not isinstance(rows,list) or len(rows)!=m.get('entries') or len(rows)>100000: raise SystemExit('Cargo seed manifest inventory count mismatch')
if sum(r.get('type')=='file' for r in rows)!=m.get('regular_files') or sum(r.get('type')=='dir' for r in rows)!=m.get('directories') or sum(r.get('type')=='symlink' for r in rows)!=m.get('symlinks'): raise SystemExit('Cargo seed manifest aggregate inventory mismatch')
print('cargo_seed_manifest=PASS sha256='+h.hexdigest()+' entries='+str(len(rows)))
PY
}
verify_seed_marker() {
  /usr/bin/python3 -I - "$EVIDENCE" "$SEED_MARKER" "$SEED_MANIFEST_NAME" "$SEED_SNAPSHOT_HELPER_SHA256" "$SEED_VERIFIER_SHA256" "$SNAPSHOT_FIXTURE_SHA256" "$GIT_GUARD_FIXTURE_SHA256" "$SOURCE_COMMIT" "$SOURCE_TREE" "$SOURCE_CARGO_LOCK_SHA256" <<'PY'
import hashlib,json,os,re,stat,sys
root,marker,manifest,helper,verifier,snapshot_fixture,git_fixture,commit,tree,lock=sys.argv[1:]
def read_at(dfd,name,limit):
    fd=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd); st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,0o600,1) or st.st_size<=0 or st.st_size>limit: os.close(fd); raise SystemExit('unsafe seed evidence file: '+name)
    with os.fdopen(fd,'rb') as stream: data=stream.read(limit+1)
    if len(data)!=st.st_size or len(data)>limit: raise SystemExit('seed evidence size changed: '+name)
    return data
fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(0,0,0o700): raise SystemExit('unsafe seed evidence directory')
raw=read_at(fd,marker,4096).decode('ascii')
match=re.fullmatch(r'seed-verify=PASS source='+re.escape(commit)+r' tree='+re.escape(tree)+r' lock='+re.escape(lock)+r' snapshot-helper='+re.escape(helper)+r' verifier='+re.escape(verifier)+r' snapshot-fixture='+re.escape(snapshot_fixture)+r' git-fixture='+re.escape(git_fixture)+r' manifest_sha256=([0-9a-f]{64})\n',raw)
if match is None: raise SystemExit('Cargo seed pass marker identity mismatch')
manifest_raw=read_at(fd,manifest,64*1024*1024)
if hashlib.sha256(manifest_raw).hexdigest()!=match.group(1): raise SystemExit('Cargo seed manifest changed after verification')
m=json.loads(manifest_raw)
if (m.get('schema'),m.get('source_commit'),m.get('source_tree'),m.get('cargo_lock_sha256'))!=('jackin-cargo-source-seed-24b8-v3',commit,tree,lock): raise SystemExit('Cargo seed manifest source identity changed')
os.close(fd)
print('cargo_seed_pass=PASS manifest_sha256='+match.group(1))
PY
}
verify_mise_state() {
  /usr/bin/python3 -I - "$WORK" <<'PY'
import os,pathlib,stat,sys
work=pathlib.Path(sys.argv[1])
def directory(path):
    st=os.lstat(path)
    if not stat.S_ISDIR(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(65534,65534,0o700): raise SystemExit('unsafe Mise directory: '+str(path))
    return sorted(os.listdir(path))
for rel in ('mise-data','mise-data/installs','mise-data/installs/rust','mise-data/installs/mr-boxington','mise-data/shims'):
    if not (work/rel).is_dir() or (work/rel).is_symlink(): raise SystemExit('unsafe Mise directory: '+rel)
if directory(work/'mise-data')!=['installs','shims'] or directory(work/'mise-data/installs')!=['mr-boxington','rust'] or directory(work/'mise-data/installs/rust')!=['1.97.1'] or directory(work/'mise-data/installs/mr-boxington')!=['1.22.0'] or directory(work/'mise-data/shims'):
    raise SystemExit('Mise registration inventory changed')
for rel,target in {'mise-data/installs/rust/1.97.1':'/tools/rust-1.97.1','mise-data/installs/mr-boxington/1.22.0':'/tools/mbx-1.22.0'}.items():
    path=work/rel; st=os.lstat(path)
    if not stat.S_ISLNK(st.st_mode) or (st.st_uid,st.st_gid)!=(65534,65534) or os.readlink(path)!=target: raise SystemExit('Mise tool registration changed: '+rel)
print('mise_registration=PASS rust=1.97.1 mr-boxington=1.22.0')
PY
}
seed_verify() {
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  verify_source_phase; verify_seed_artifacts; verify_task_state no
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 10m /usr/bin/python3 -I "$SNAPSHOT_FIXTURE"
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 10m /usr/bin/python3 -I "$GIT_GUARD_FIXTURE"
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 20m /usr/bin/python3 -I "$SEED_SNAPSHOT_HELPER" prepare
  verify_task_state yes
  /usr/bin/timeout --foreground --signal=TERM --kill-after=10s 35m /usr/bin/python3 -I "$SEED_VERIFIER"
  readonly SEED_MANIFEST_SHA256_EXPECTED=$(/usr/bin/python3 -I - "$SEED_MANIFEST" <<'PY'
import hashlib,os,stat,sys
p=sys.argv[1]; fd=os.open(p,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,0o600,1) or st.st_size<=0 or st.st_size>64*1024*1024: os.close(fd); raise SystemExit('unsafe seed manifest')
h=hashlib.sha256()
with os.fdopen(fd,'rb') as f:
    for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
print(h.hexdigest())
PY
)
  verify_seed_manifest
  write_pass_marker "$SEED_MARKER" "seed-verify=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE lock=$SOURCE_CARGO_LOCK_SHA256 snapshot-helper=$SEED_SNAPSHOT_HELPER_SHA256 verifier=$SEED_VERIFIER_SHA256 snapshot-fixture=$SNAPSHOT_FIXTURE_SHA256 git-fixture=$GIT_GUARD_FIXTURE_SHA256 manifest_sha256=$SEED_MANIFEST_SHA256_EXPECTED"
}
verify_all_markers() {
  require_pass_marker "$ROOTFS_MARKER" "rootfs-preflight=PASS rootfs=$ROOTFS helper=$ROOTFS_HELPER_SHA256 marker=$ROOTFS_PASS_MARKER_SHA256"
  require_pass_marker "$SOURCE_MARKER" "source-recovery=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE archive=$SOURCE_ARCHIVE_SHA256 packet=$SOURCE_PACKET_SHA256 helper=$SOURCE_HELPER_SHA256 fixture=$SOURCE_FIXTURE_SHA256 state_fixture=$SOURCE_STATE_FIXTURE_SHA256"
  verify_seed_marker
}
verify_log_targets_absent() {
  local phase=$1
  /usr/bin/python3 -I - "$OUT_DIR" "$phase" <<'PY'
import os,stat,sys
path,phase=sys.argv[1:]; fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC); st=os.fstat(fd)
if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(65534,65534,0o700): raise SystemExit('unsafe MBX output directory')
for suffix in ('mbx-stats.json','mbx-bypasses.tsv'):
    name=phase+'-'+suffix
    try: os.stat(name,dir_fd=fd,follow_symlinks=False)
    except FileNotFoundError: continue
    raise SystemExit('phase output already exists: '+name)
extra={'tool-route':'tool-route-mbx-help.txt','metadata-check':'metadata-resolution.json'}.get(phase)
if extra is not None:
    try: os.stat(extra,dir_fd=fd,follow_symlinks=False)
    except FileNotFoundError: pass
    else: raise SystemExit('phase output already exists: '+extra)
os.close(fd)
PY
}
run_isolated() {
  local limit=$1 phase=$2 body=$3 status=0
  case "$phase" in tool-route|metadata-check|clippy|tests) ;; *) die "unknown isolated phase" ;; esac
  no_builder_processes; no_task_mounts; no_usr_submounts
  verify_all_markers; verify_source; verify_task_state yes; verify_mise_state; verify_log_targets_absent "$phase"
  local -a envargs=(/usr/bin/env -i PATH=/usr/sbin:/usr/bin:/sbin:/bin ROOTFS="$ROOTFS" WORK="$WORK" SOURCE_DIR="$SOURCE_DIR" SEED_SNAPSHOT="$SEED_SNAPSHOT" OUT_DIR="$OUT_DIR")
  /usr/bin/timeout --foreground --signal=TERM --kill-after=15s "$limit" "${envargs[@]}" \
    /usr/bin/unshare --mount --pid --ipc --uts --fork --kill-child --propagation private --net -- \
    /usr/bin/bash -euo pipefail -c '
      set -euo pipefail
      rootfs=$1; work=$2; source_dir=$3; seed=$4; out_dir=$5; body=$6; phase=$7
      /usr/bin/mount --make-rprivate /
      /usr/bin/mount --bind "$rootfs" "$rootfs"
      /usr/bin/mount -o remount,bind,ro "$rootfs"
      /usr/bin/mount -t proc -o ro,nosuid,nodev,noexec,hidepid=2 proc "$rootfs/proc"
      /usr/bin/mount --bind /usr "$rootfs/usr"
      /usr/bin/mount -o remount,bind,ro "$rootfs/usr"
      /usr/bin/mount --bind "$work" "$rootfs/work"
      /usr/bin/mount --bind "$source_dir" "$rootfs/source"
      /usr/bin/mount -o remount,bind,ro,nosuid,nodev,noexec "$rootfs/source"
      /usr/bin/mount --bind "$seed/registry" "$rootfs/work/cargo-home/registry"
      /usr/bin/mount -o remount,bind,ro,nosuid,nodev,noexec "$rootfs/work/cargo-home/registry"
      /usr/bin/mount --bind "$seed/git" "$rootfs/work/cargo-home/git"
      /usr/bin/mount -o remount,bind,ro,nosuid,nodev,noexec "$rootfs/work/cargo-home/git"
      /usr/bin/mount -t tmpfs -o size=64m,nosuid,nodev,noexec tmpfs "$rootfs/tmp"
      /usr/bin/mount --bind /dev/null "$rootfs/dev/null"
      exec /usr/sbin/chroot "$rootfs" /usr/bin/python3 -I -c \
        "import ctypes,os,sys; os.chdir(\"/work\"); a=sys.argv[sys.argv.index(\"--\")+1:]; libc=ctypes.CDLL(None,use_errno=True); f=getattr(libc,\"close_range\",None); f is not None or sys.exit(90); f.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.c_uint]; f.restype=ctypes.c_int; r=f(3,0xffffffff,0); r==0 or sys.exit(91); os.execv(a[0],a)" \
        -- /usr/bin/setpriv --reuid=65534 --regid=65534 --clear-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs --pdeathsig=KILL --reset-env -- /usr/bin/env -i \
        HOME=/work/home USER=builder LOGNAME=builder SHELL=/usr/bin/bash \
        PATH=/tools/rustup-proxy:/tools/mise/bin:/usr/bin:/bin TMPDIR=/work/tmp CARGO_HOME=/work/cargo-home RUSTUP_HOME=/work/rustup-home CARGO_TARGET_DIR=/work/target CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true \
        MBX_CACHE_DIR=/work/mbx-cache MBX_SUMMARY=full MBX_STATS_REPORT="/work/out/$phase-mbx-stats.json" MBX_BYPASS_LOG="/work/out/$phase-mbx-bypasses.tsv" \
        MBX_SCHEDULER_CPUS=4 MBX_SCHEDULER_RESERVE_CPUS=1 MBX_SCHEDULER_MEMORY=32GiB MBX_SCHEDULER_PRESSURE=1 MBX_SCHEDULER_PRIORITY=low MBX_SCHEDULER_TESTS=1 RUST_TEST_THREADS=3 NO_COLOR=1 \
        MISE_DATA_DIR=/work/mise-data MISE_CACHE_DIR=/work/mise-cache MISE_CONFIG_DIR=/work/mise-config MISE_JOBS=1 MISE_ENABLE_TOOLS=rust,mr-boxington \
        MISE_AUTO_INSTALL=0 MISE_EXEC_AUTO_INSTALL=0 MISE_NOT_FOUND_AUTO_INSTALL=0 MISE_AUTO_UPDATE=0 MISE_NO_HOOKS=1 MISE_NO_ENV=1 MISE_OFFLINE=1 MISE_TRUSTED_CONFIG_PATHS=/source \
        RUSTUP_TOOLCHAIN=1.97.1-x86_64-unknown-linux-gnu RUSTUP_AUTO_INSTALL=0 \
        XDG_DATA_HOME=/work/xdg-data XDG_CACHE_HOME=/work/xdg-cache XDG_STATE_HOME=/work/xdg-state XDG_CONFIG_HOME=/work/xdg-config \
        GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 \
        /usr/bin/bash -euo pipefail -c "$body" -- "$phase"
    ' _ "$ROOTFS" "$WORK" "$SOURCE_DIR" "$SEED_SNAPSHOT" "$OUT_DIR" "$body" "$phase" || status=$?
  no_task_mounts; no_builder_processes
  return "$status"
}
run_tool_route() {
  verify_all_markers
  run_isolated 5m tool-route '
    /usr/bin/python3 /tools/check_sandbox.py
    cd /source
    /usr/bin/python3 -I /tools/rustup-home-prep-v4.py
    exec /tools/mise/bin/mise --no-config --no-env --no-hooks exec --no-deps --locked --deny-net --deny-env mr-boxington@1.22.0 -- mbx --help > /work/out/tool-route-mbx-help.txt
  '
  local info support help_hash
  info=$(metadata_cli_status); read -r support help_hash <<<"$info"
  write_pass_marker "$ROUTE_MARKER" "tool-route=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE rust=$RUST_VERSION mise=$MISE_VERSION mbx=1.22.0 seed=$SEED_VERIFIER_SHA256 metadata=$support help_sha256=$help_hash"
}
metadata_cli_status() {
  /usr/bin/python3 -I - "$OUT_DIR" <<'PY'
import hashlib,os,re,stat,sys
root=sys.argv[1]; dfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
    fd=os.open('tool-route-mbx-help.txt',os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd); st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(65534,65534,0o600,1) or st.st_size<=0 or st.st_size>65536:
        os.close(fd); raise SystemExit('unsafe pinned MBX help output')
    with os.fdopen(fd,'rb') as stream: raw=stream.read(65537)
    if len(raw)!=st.st_size or len(raw)>65536: raise SystemExit('MBX help output changed while reading')
finally: os.close(dfd)
try: help_text=raw.decode('utf-8')
except UnicodeDecodeError: raise SystemExit('MBX help output is not UTF-8')
supported=any(re.match(r'^\s*metadata(?:\s|$|\[)',line,re.IGNORECASE) for line in help_text.splitlines())
print(('supported' if supported else 'unsupported')+' '+hashlib.sha256(raw).hexdigest())
PY
}
verify_route_marker() {
  local info support help_hash
  info=$(metadata_cli_status); read -r support help_hash <<<"$info"
  require_pass_marker "$ROUTE_MARKER" "tool-route=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE rust=$RUST_VERSION mise=$MISE_VERSION mbx=1.22.0 seed=$SEED_VERIFIER_SHA256 metadata=$support help_sha256=$help_hash"
}
verify_metadata_output_absent() {
  /usr/bin/python3 -I - "$OUT_DIR" <<'PY'
import os,sys
fd=os.open(sys.argv[1],os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try: os.stat('metadata-resolution.json',dir_fd=fd,follow_symlinks=False)
except FileNotFoundError: pass
else: raise SystemExit('unexpected Cargo metadata output when MBX does not support metadata')
os.close(fd)
PY
}
verify_metadata_output() {
  /usr/bin/python3 -I - "$OUT_DIR" "$WORK" <<'PY'
import hashlib,json,os,stat,sys
out,work=sys.argv[1:]; dfd=os.open(out,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
    fd=os.open('metadata-resolution.json',os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd); st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(65534,65534,0o600,1) or st.st_size<=0 or st.st_size>128*1024*1024:
        os.close(fd); raise SystemExit('unsafe Cargo metadata output')
    with os.fdopen(fd,'rb') as stream: raw=stream.read(128*1024*1024+1)
finally: os.close(dfd)
if len(raw)!=st.st_size or len(raw)>128*1024*1024: raise SystemExit('Cargo metadata output changed while reading')
try: data=json.loads(raw)
except (UnicodeDecodeError,json.JSONDecodeError) as e: raise SystemExit('Cargo metadata output is invalid JSON: '+str(e))
if not isinstance(data,dict) or not isinstance(data.get('packages'),list) or not data.get('packages') or not isinstance(data.get('workspace_members'),list) or not data.get('workspace_members') or not isinstance(data.get('target_directory'),str): raise SystemExit('Cargo metadata output has an unexpected shape')
if data.get('target_directory')!=work+'/target': raise SystemExit('Cargo metadata target directory escaped task work')
print('sha256='+hashlib.sha256(raw).hexdigest()+' packages=%d workspace_members=%d'%(len(data['packages']),len(data['workspace_members'])))
PY
}
verify_metadata_marker() {
  local info support help_hash metadata_info metadata_hash want
  info=$(metadata_cli_status); read -r support help_hash <<<"$info"
  verify_route_marker
  case "$support" in supported)
    metadata_info=$(verify_metadata_output); read -r metadata_hash _ <<<"$metadata_info"
    want="metadata-resolution=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE help_sha256=$help_hash metadata_sha256=$metadata_hash command=mbx-metadata-locked-offline"
    ;;
    unsupported)
    verify_metadata_output_absent
    want="metadata-resolution=SKIP unsupported source=$SOURCE_COMMIT tree=$SOURCE_TREE help_sha256=$help_hash"
    ;;
    *) die 'unrecognized pinned MBX help status' ;;
  esac
  require_pass_marker "$METADATA_MARKER" "$want"
}
run_metadata_resolution() {
  verify_all_markers
  verify_route_marker
  local info support help_hash metadata_info metadata_hash
  need_host; no_builder_processes; no_task_mounts; no_usr_submounts
  verify_source; verify_task_state yes; verify_route_marker
  info=$(metadata_cli_status); read -r support help_hash <<<"$info"
  case "$support" in
    supported)
      run_isolated 20m metadata-check '
        /usr/bin/python3 /tools/check_sandbox.py
        cd /source
        /usr/bin/python3 -I /tools/rustup-home-prep-v4.py
        exec /tools/mise/bin/mise --no-config --no-env --no-hooks exec --no-deps --locked --deny-net --deny-env mr-boxington@1.22.0 -- mbx metadata --locked --offline --manifest-path /source/Cargo.toml > /work/out/metadata-resolution.json
      '
      metadata_info=$(verify_metadata_output); read -r metadata_hash _ <<<"$metadata_info"
      write_pass_marker "$METADATA_MARKER" "metadata-resolution=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE help_sha256=$help_hash metadata_sha256=$metadata_hash command=mbx-metadata-locked-offline"
      ;;
    unsupported)
      verify_metadata_output_absent
      write_pass_marker "$METADATA_MARKER" "metadata-resolution=SKIP unsupported source=$SOURCE_COMMIT tree=$SOURCE_TREE help_sha256=$help_hash"
      ;;
    *) die 'unrecognized pinned MBX help status' ;;
  esac
}
run_clippy() {
  verify_all_markers
  verify_route_marker
  verify_metadata_marker
  run_isolated 45m clippy '
    /usr/bin/python3 /tools/check_sandbox.py
    cd /source
    /usr/bin/python3 -I /tools/rustup-home-prep-v4.py
    exec /tools/mise/bin/mise --no-config --no-env --no-hooks exec --no-deps --locked --deny-net --deny-env mr-boxington@1.22.0 -- mbx clippy --locked --offline --manifest-path Cargo.toml --package jackin-instance --all-targets -- -D warnings
  '
  write_pass_marker "$CLIPPY_MARKER" "clippy=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE command=jackin-instance-all-targets"
}
run_tests() {
  verify_all_markers
  verify_route_marker
  verify_metadata_marker
  require_pass_marker "$CLIPPY_MARKER" "clippy=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE command=jackin-instance-all-targets"
  run_isolated 60m tests '
    /usr/bin/python3 /tools/check_sandbox.py
    cd /source
    /usr/bin/python3 -I /tools/rustup-home-prep-v4.py
    exec /tools/mise/bin/mise --no-config --no-env --no-hooks exec --no-deps --locked --deny-net --deny-env mr-boxington@1.22.0 -- mbx test --locked --offline --manifest-path Cargo.toml --package jackin-instance
  '
  write_pass_marker "$TESTS_MARKER" "tests=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE command=jackin-instance"
}
cleanup_check() {
  need_host; no_task_mounts; no_builder_processes; no_usr_submounts
  verify_all_markers
  verify_route_marker
  verify_metadata_marker
  require_pass_marker "$CLIPPY_MARKER" "clippy=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE command=jackin-instance-all-targets"
  require_pass_marker "$TESTS_MARKER" "tests=PASS source=$SOURCE_COMMIT tree=$SOURCE_TREE command=jackin-instance"
  printf 'cleanup_check=PASS task_processes=0 task_mounts=0 retained_work=%s\n' "$WORK"
}
argv_fixture() {
  [[ $# -eq 2 ]] || die 'argv fixture requires exactly one phase token'
  case "$2" in
    source-recover-marker|verify-source)
      printf 'argv-fixture=PASS argc=1 phase=<%s>\n' "$2"
      ;;
    *) die 'argv fixture rejected phase token' ;;
  esac
}
case ${1:-} in
  --argv-fixture) argv_fixture "$@" ;;
  source-recover-marker) [[ $# -eq 1 ]] || die 'phase accepts no extra arguments'; source_recover_marker ;;
  verify-source) [[ $# -eq 1 ]] || die 'phase accepts no extra arguments'; verify_source_phase ;;
  *) die "usage: ${SELF##*/} {${ALLOWED_PHASES// /|}}" ;;
esac
