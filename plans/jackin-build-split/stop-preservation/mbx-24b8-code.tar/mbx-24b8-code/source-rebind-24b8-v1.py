#!/usr/bin/python3
"""Bounded PR #1111 source rebinder. It validates archive bytes as data and never executes them."""
import hashlib
import io
import os
import pathlib
import stat
import sys
import tarfile

TASK_ROOT = "/opt/.jackin-pr1111-24b8-mbx-20261005-v1"
ROOTFS = "/opt/.jackin-mbx-current-17b2b1b-v5-62dfd1ac/rootfs-clean-3986dfdd-v1"
WORK = TASK_ROOT + "/work"
SOURCE_DIR = TASK_ROOT + "/source-24b8d5423a212130e4a1c60beffed860248b7f27"
OUT_DIR = WORK + "/out"
ARCHIVE = "/root/.jackin-pr1111-source-24b8-20261005/jackin-24b8d5423a212130e4a1c60beffed860248b7f27.tar"
ARCHIVE_SHA = "c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a"
ARCHIVE_SIZE = 39147520
PACKET = "/root/.jackin-pr1111-source-24b8-20261005/source-packet.md"
PACKET_SHA = "22a0a9e3a777fbac13c3fbbec01505ab53bb3ebe18acc3d91f3fb1cfbe28bf2a"
COMMIT = "24b8d5423a212130e4a1c60beffed860248b7f27"
TREE = "63e21941838f728583e22220e9432f6afceb90b9"
PINNED = {
    "Cargo.lock": "5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097",
    "mise.toml": "c7f84dc3562e423814617ae55acc27e97f9a5f367d1ea6fbef56bb5e11ef2c8e",
    "mise.lock": "ac3b0998f110538c5bb34f2653afaf7f2713d7f9f026dde1bb3f50845cef06ef",
    "rust-toolchain.toml": "d62dfea7074d89dd8c5e26fbde9e3cf1e9480b8b7a89165ed18177b0d43c9dbf",
    ".velnor/config.toml": "17af85b335ebaa266bdbf488cf1f11634cea14eb16730cfd06fbc33078f2cd61",
    ".cargo/config.toml": "36b63bef2052043dc4c0abaae5085b741dfd0c0f93b11cca9cc0b859bcb55f0b",
    ".config/nextest.toml": "60c172b437eb6b35dedb12267db307d7216613e2c9ff0a538ad0dfb5cf884f88",
    "crates/jackin/Cargo.toml": "afdb61f7afd4c5b786f2bae8d17fb8b8803742df31f949779a3db6230de60533",
    "crates/jackin-xtask/Cargo.toml": "3748c0a863835f4b94d19c6004905a2460a854aa622ecf0dfc2f2225240a5556",
    "Cargo.toml": "a82c1cfcc049aa83c77bc17cc93c06efaa6d14ab781c5dfeb2f316f176d4d124",
    ".codex/config.toml": "039f8ee8026408cef6d4953c5bf93521c468a9221434509b27731ea0d09c3e70",
}
LINKS = {"CLAUDE.md": "AGENTS.md", ".github/CLAUDE.md": "AGENTS.md"}
MAX_ARCHIVE = 64 * 1024 * 1024
MAX_PACKET = 1024 * 1024
MAX_FILE = 64 * 1024 * 1024
MAX_TOTAL = 1024 * 1024 * 1024


def open_abs_dir(path):
    parts = pathlib.PurePosixPath(path)
    if not parts.is_absolute() or any(x in ("", ".", "..") for x in parts.parts[1:]):
        raise SystemExit("unsafe absolute directory")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        for index, name in enumerate(parts.parts[1:], 1):
            nxt = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
            st = os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or st.st_gid != 0 or st.st_mode & 0o022:
                os.close(nxt)
                raise SystemExit("unsafe root-owned directory ancestor: " + name)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise


def open_regular(path, expected_hash, expected_size, limit, mode=0o400):
    parts = pathlib.PurePosixPath(path)
    parent = open_abs_dir(str(parts.parent))
    try:
        fd = os.open(parts.name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode), st.st_nlink) != (0, 0, mode, 1):
            os.close(fd)
            raise SystemExit("unsafe pinned input file: " + path)
        if st.st_size <= 0 or st.st_size > limit or (expected_size is not None and st.st_size != expected_size):
            os.close(fd)
            raise SystemExit("pinned input size mismatch: " + path)
        data = bytearray()
        h = hashlib.sha256()
        while True:
            block = os.read(fd, min(1024 * 1024, limit + 1 - len(data)))
            if not block:
                break
            data.extend(block)
            h.update(block)
            if len(data) > limit:
                os.close(fd)
                raise SystemExit("pinned input exceeds size limit: " + path)
        after = os.fstat(fd)
        os.close(fd)
        if len(data) != st.st_size or (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise SystemExit("pinned input changed while reading: " + path)
        if h.hexdigest() != expected_hash:
            raise SystemExit("pinned input SHA-256 mismatch: " + path)
        return bytes(data)
    finally:
        os.close(parent)


def open_child_dir(parent_fd, name, uid, gid, mode):
    fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
    st = os.fstat(fd)
    if (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != (uid, gid, mode):
        os.close(fd)
        raise SystemExit("unsafe directory identity: " + name)
    return fd


def create_dir_at(parent, name, uid, gid, mode):
    os.mkdir(name, 0o700, dir_fd=parent)
    fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
    try:
        os.fchown(fd, uid, gid)
        os.fchmod(fd, mode)
        os.fsync(fd)
    except BaseException:
        os.close(fd)
        raise
    return fd


def ensure_dir_at(parent, name, uid, gid, mode, create):
    if create:
        try:
            fd = create_dir_at(parent, name, uid, gid, mode)
        except FileExistsError:
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
    else:
        fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
    st = os.fstat(fd)
    if not stat.S_ISDIR(st.st_mode) or (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != (uid, gid, mode):
        os.close(fd)
        raise SystemExit("unsafe task directory: " + name)
    return fd


def ensure_nested(root_fd, parts, uid, gid, mode, create):
    fd = os.dup(root_fd)
    try:
        for name in parts:
            nxt = ensure_dir_at(fd, name, uid, gid, mode, create)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise


def ensure_link_at(parent, name, target, uid, gid):
    created = False
    try:
        os.symlink(target, name, dir_fd=parent)
        created = True
    except FileExistsError:
        pass
    if created:
        os.chown(name, uid, gid, dir_fd=parent, follow_symlinks=False)
    st = os.stat(name, dir_fd=parent, follow_symlinks=False)
    if not stat.S_ISLNK(st.st_mode) or (st.st_uid, st.st_gid) != (uid, gid) or os.readlink(name, dir_fd=parent) != target:
        raise SystemExit("unexpected Mise registration link: " + name)


def ensure_phase_placeholder(work_fd, create):
    raw = b"jackin-a64-phase-mountpoint-v1\n"
    if create:
        fd = os.open(".phase.sh", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=work_fd)
        try:
            view = memoryview(raw)
            while view:
                view = view[os.write(fd, view):]
            os.fchown(fd, 0, 0)
            os.fchmod(fd, 0o444)
            os.fsync(fd)
        finally:
            os.close(fd)
    fd = os.open(".phase.sh", os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=work_fd)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode), st.st_nlink, st.st_size) != (0, 0, 0o444, 1, len(raw)):
            raise SystemExit("unsafe private phase mountpoint")
        if os.read(fd, len(raw) + 1) != raw:
            raise SystemExit("private phase mountpoint content changed")
    finally:
        os.close(fd)


def create_work(work_fd, create):
    top = ("home", "tmp", "cargo-home", "rustup-home", "mise-data", "mise-cache", "mise-config", "xdg-cache", "xdg-config", "xdg-data", "xdg-state", "target", "mbx-cache", "out")
    opened = {}
    try:
        for name in top:
            opened[name] = ensure_dir_at(work_fd, name, 65534, 65534, 0o700, create)
        for name in ("registry", "git"):
            child = ensure_dir_at(opened["cargo-home"], name, 65534, 65534, 0o700, create)
            os.close(child)
        data = opened["mise-data"]
        installs = ensure_dir_at(data, "installs", 65534, 65534, 0o700, create)
        rust = ensure_dir_at(installs, "rust", 65534, 65534, 0o700, create)
        box = ensure_dir_at(installs, "mr-boxington", 65534, 65534, 0o700, create)
        shims = ensure_dir_at(data, "shims", 65534, 65534, 0o700, create)
        ensure_link_at(rust, "1.97.1", "/tools/rust-1.97.1", 65534, 65534)
        ensure_link_at(box, "1.22.0", "/tools/mbx-1.22.0", 65534, 65534)
        ensure_phase_placeholder(work_fd, create)
        if os.listdir(shims):
            raise SystemExit("unexpected private Mise shim entries")
        os.close(shims)
        os.close(box)
        os.close(rust)
        os.close(installs)
    finally:
        for fd in opened.values():
            os.close(fd)


def open_rootfs_mountpoints():
    root = open_abs_dir(ROOTFS)
    try:
        st = os.fstat(root)
        if (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != (0, 0, 0o755):
            raise SystemExit("unsafe sealed rootfs root")
        for name in ("source", "work"):
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=root)
            cst = os.fstat(child)
            if (cst.st_uid, cst.st_gid, stat.S_IMODE(cst.st_mode)) != (0, 0, 0o755):
                os.close(child)
                raise SystemExit("sealed rootfs mountpoint metadata mismatch: " + name)
            # The verified base image contains an older source tree at /source.
            # The runner overlays its exact archive read-only inside a private mount namespace.
            if name == "work" and os.listdir(child):
                os.close(child)
                raise SystemExit("sealed rootfs work mountpoint is not empty")
            os.close(child)
    finally:
        os.close(root)


def open_task_paths(create=False):
    opt = os.open("/opt", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        optst = os.fstat(opt)
        if (optst.st_uid, optst.st_gid, stat.S_IMODE(optst.st_mode)) != (0, 0, 0o755):
            raise SystemExit("unsafe /opt directory")
        task_name = os.path.basename(TASK_ROOT)
        if create:
            try:
                os.stat(task_name, dir_fd=opt, follow_symlinks=False)
            except FileNotFoundError:
                pass
            else:
                raise SystemExit("task root already exists; preserve it and choose a new version")
            os.mkdir(task_name, 0o700, dir_fd=opt)
            task = os.open(task_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=opt)
        else:
            task = ensure_dir_at(opt, task_name, 0, 0, 0o700, False)
    finally:
        os.close(opt)
    try:
        if create:
            work = create_dir_at(task, "work", 65534, 65534, 0o700)
        else:
            work = ensure_dir_at(task, "work", 65534, 65534, 0o700, False)
        try:
            create_work(work, create)
            rootfs_source = os.path.basename(SOURCE_DIR)
            if create:
                source = create_dir_at(task, rootfs_source, 0, 0, 0o755)
            else:
                source = ensure_dir_at(task, rootfs_source, 0, 0, 0o755, False)
            if not create:
                out = ensure_dir_at(work, "out", 65534, 65534, 0o700, False)
                os.close(out)
            os.close(source)
        finally:
            os.close(work)
    finally:
        os.close(task)
    open_rootfs_mountpoints()
    opt = os.open("/opt", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    task = ensure_dir_at(opt, os.path.basename(TASK_ROOT), 0, 0, 0o700, False)
    os.close(opt)
    source = ensure_dir_at(task, os.path.basename(SOURCE_DIR), 0, 0, 0o755, False)
    os.close(task)
    return source

def safe_parent(root_fd, parts):
    fd = os.dup(root_fd)
    try:
        for name in parts:
            try:
                nxt = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
            except FileNotFoundError:
                os.mkdir(name, 0o700, dir_fd=fd)
                nxt = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                os.fchown(nxt, 0, 0)
                os.fchmod(nxt, 0o755)
            st = os.fstat(nxt)
            if (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != (0, 0, 0o755):
                os.close(nxt)
                raise SystemExit("unsafe source parent directory: " + name)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise


def validate_archive(tf):
    root_seen = False
    seen = set()
    links = {}
    files = {}
    total = 0
    members = tf.getmembers()
    if not members or len(members) > 10000:
        raise SystemExit("source archive member count outside bound")
    normalized_members = []
    for member in members:
        original = member.name
        if original == "jackin":
            if root_seen or not member.isdir() or member.mode & 0o7000:
                raise SystemExit("unsafe or duplicate archive root")
            root_seen = True
            continue
        if not original.startswith("jackin/"):
            raise SystemExit("archive member is outside the single jackin/ root")
        raw = original[len("jackin/"):]
        if raw.startswith("/") or "\\" in raw or "//" in raw or "\x00" in raw or len(raw) > 512:
            raise SystemExit("unsafe archive path")
        name = raw[:-1] if member.isdir() and raw.endswith("/") else raw
        if raw.endswith("/") and not member.isdir():
            raise SystemExit("non-directory archive member has a trailing slash")
        path = pathlib.PurePosixPath(name)
        if not name or path.is_absolute() or str(path) != name or any(part in ("", ".", "..") for part in path.parts) or name in seen:
            raise SystemExit("unsafe or duplicate normalized archive path")
        if member.mode & 0o7000:
            raise SystemExit("set-id or sticky archive member")
        seen.add(name)
        member.name = name
        if member.isdir():
            normalized_members.append((member, "dir"))
            continue
        if member.isfile():
            if member.size < 0 or member.size > MAX_FILE:
                raise SystemExit("archive file exceeds per-file size bound")
            total += member.size
            if total > MAX_TOTAL:
                raise SystemExit("archive expanded size exceeds bound")
            normalized_members.append((member, "file"))
            stream = tf.extractfile(member)
            if stream is None:
                raise SystemExit("source file data missing: " + name)
            h = hashlib.sha256()
            count = 0
            with stream:
                while True:
                    block = stream.read(1024 * 1024)
                    if not block:
                        break
                    count += len(block)
                    if count > member.size:
                        raise SystemExit("source file exceeds declared size: " + name)
                    h.update(block)
            if count != member.size:
                raise SystemExit("source file length mismatch: " + name)
            files[name] = h.hexdigest()
            continue
        if member.issym() and name in LINKS and member.linkname == LINKS[name]:
            links[name] = member.linkname
            normalized_members.append((member, "symlink"))
            continue
        raise SystemExit("unsupported archive member type")
    if not root_seen or links != LINKS or any(files.get(name) != digest for name, digest in PINNED.items()):
        raise SystemExit("archive root, symlink set, or pinned input set changed")
    kinds = {member.name: kind for member, kind in normalized_members}
    for member, _kind in normalized_members:
        p = pathlib.PurePosixPath(member.name)
        if any(str(parent) in LINKS for parent in p.parents):
            raise SystemExit("archive member descends through a symlink")
        for parent in p.parents:
            parent_name = str(parent)
            if parent_name != "." and kinds.get(parent_name) != "dir":
                raise SystemExit("archive member has a non-directory parent: " + member.name)
    expected = {}
    for member, kind in normalized_members:
        if kind == "dir":
            expected[member.name] = {"type": "dir", "mode": 0o755}
        elif kind == "symlink":
            expected[member.name] = {"type": "symlink", "target": member.linkname}
        else:
            expected[member.name] = {
                "type": "file",
                "mode": 0o555 if member.mode & 0o111 else 0o444,
                "size": member.size,
                "sha256": files[member.name],
            }
    return normalized_members, expected


def extract_source(data, source_fd):
    created = 0
    # Re-open the same already hash-verified immutable byte string.  Keep the
    # TarFile alive for every extractfile call; never reopen the host path.
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as tf:
        normalized, expected = validate_archive(tf)
        for member, kind in normalized:
            parts = pathlib.PurePosixPath(member.name).parts
            parent = safe_parent(source_fd, parts[:-1])
            try:
                leaf = parts[-1]
                if kind == "dir":
                    try:
                        os.mkdir(leaf, 0o700, dir_fd=parent)
                    except FileExistsError:
                        pass
                    dfd = os.open(leaf, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
                    os.fchown(dfd, 0, 0)
                    os.fchmod(dfd, 0o755)
                    os.fsync(dfd)
                    os.close(dfd)
                    continue
                if kind == "symlink":
                    os.symlink(member.linkname, leaf, dir_fd=parent)
                    created += 1
                    continue
                mode = 0o555 if member.mode & 0o111 else 0o444
                fd = os.open(leaf, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=parent)
                stream = tf.extractfile(member)
                if stream is None:
                    os.close(fd)
                    raise SystemExit("archive file data missing: " + member.name)
                h = hashlib.sha256()
                count = 0
                try:
                    while True:
                        block = stream.read(1024 * 1024)
                        if not block:
                            break
                        count += len(block)
                        if count > member.size:
                            raise SystemExit("archive file grew during extraction")
                        h.update(block)
                        view = memoryview(block)
                        while view:
                            view = view[os.write(fd, view):]
                    if count != member.size:
                        raise SystemExit("archive file length mismatch: " + member.name)
                    os.fchown(fd, 0, 0)
                    os.fchmod(fd, mode)
                    os.fsync(fd)
                finally:
                    os.close(fd)
                if h.hexdigest() != expected[member.name]["sha256"]:
                    raise SystemExit("source file digest changed during extraction: " + member.name)
                created += 1
            finally:
                os.close(parent)
    for rel, target in LINKS.items():
        parts = pathlib.PurePosixPath(rel).parts
        parent = safe_parent(source_fd, parts[:-1])
        try:
            # Archive symlink rows are validated and created by their member entry.
            st = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
            if not stat.S_ISLNK(st.st_mode) or os.readlink(parts[-1], dir_fd=parent) != target:
                raise SystemExit("source symlink mismatch: " + rel)
        finally:
            os.close(parent)
    return created, expected


def verify_tree(source_fd, expected):
    rows = 0
    links = {}
    seen = set()
    total = 0
    stack = [(os.dup(source_fd), "")]
    while stack:
        fd, prefix = stack.pop()
        try:
            for name in os.listdir(fd):
                if name in ("", ".", "..") or "/" in name or "\\" in name:
                    raise SystemExit("unsafe source tree entry name")
                rel = (prefix + "/" if prefix else "") + name
                want = expected.get(rel)
                if want is None:
                    raise SystemExit("unexpected source tree entry: " + rel)
                seen.add(rel)
                st = os.stat(name, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    if (want["type"], st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != ("dir", 0, 0, want["mode"]):
                        raise SystemExit("unsafe source directory metadata: " + rel)
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                    opened = os.fstat(child)
                    if (opened.st_dev, opened.st_ino, opened.st_uid, opened.st_gid, stat.S_IMODE(opened.st_mode)) != (st.st_dev, st.st_ino, 0, 0, want["mode"]):
                        os.close(child)
                        raise SystemExit("source directory changed while opening: " + rel)
                    stack.append((child, rel))
                elif stat.S_ISREG(st.st_mode):
                    if (want["type"], st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode), st.st_nlink, st.st_size) != ("file", 0, 0, want["mode"], 1, want["size"]) or st.st_size < 0 or st.st_size > MAX_FILE:
                        raise SystemExit("unsafe source regular file metadata: " + rel)
                    leaf = os.open(name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                    opened = os.fstat(leaf)
                    if (opened.st_dev, opened.st_ino, opened.st_size, opened.st_uid, opened.st_gid, stat.S_IMODE(opened.st_mode), opened.st_nlink) != (st.st_dev, st.st_ino, st.st_size, 0, 0, want["mode"], 1):
                        os.close(leaf)
                        raise SystemExit("source file changed while opening: " + rel)
                    h = hashlib.sha256()
                    count = 0
                    with os.fdopen(leaf, "rb") as stream:
                        while True:
                            block = stream.read(1024 * 1024)
                            if not block:
                                break
                            count += len(block)
                            total += len(block)
                            if count > st.st_size or total > MAX_TOTAL:
                                raise SystemExit("source tree byte bound exceeded")
                            h.update(block)
                    if count != want["size"] or h.hexdigest() != want["sha256"]:
                        raise SystemExit("source file content mismatch: " + rel)
                elif stat.S_ISLNK(st.st_mode):
                    target = os.readlink(name, dir_fd=fd)
                    if st.st_uid != 0 or st.st_gid != 0 or want.get("type") != "symlink" or LINKS.get(rel) != target or want.get("target") != target:
                        raise SystemExit("unexpected source symlink: " + rel)
                    links[rel] = target
                else:
                    raise SystemExit("special source tree entry: " + rel)
                rows += 1
                if rows > 10000:
                    raise SystemExit("source tree entry count exceeds bound")
        finally:
            os.close(fd)
    if links != LINKS or seen != set(expected):
        raise SystemExit("source tree inventory mismatch: missing=%d extra=%d" % (len(set(expected) - seen), len(seen - set(expected))))
    return rows


def prepare():
    archive = open_regular(ARCHIVE, ARCHIVE_SHA, ARCHIVE_SIZE, MAX_ARCHIVE)
    packet = open_regular(PACKET, PACKET_SHA, None, MAX_PACKET)
    packet_text = packet.decode("utf-8")
    for value in (COMMIT, TREE, ARCHIVE_SHA, "Requested focused MBX checks", "mise exec --locked --deny-net -- mbx clippy --locked --offline --manifest-path Cargo.toml --package jackin-instance --all-targets -- -D warnings"):
        if value not in packet_text:
            raise SystemExit("source packet does not bind expected input: " + value)
    source_fd = open_task_paths(create=True)
    try:
        created, expected = extract_source(archive, source_fd)
        rows = verify_tree(source_fd, expected)
    finally:
        os.close(source_fd)
    print("source_rebind=PASS")
    print("source_commit=" + COMMIT)
    print("source_tree=" + TREE)
    print("source_archive_sha256=" + ARCHIVE_SHA)
    print("source_packet_sha256=" + PACKET_SHA)
    print("source_path=" + SOURCE_DIR)
    print("source_entries=" + str(rows))
    print("source_files_written=" + str(created))
    print("output_path=" + OUT_DIR)


def verify():
    archive = open_regular(ARCHIVE, ARCHIVE_SHA, ARCHIVE_SIZE, MAX_ARCHIVE)
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:*") as tf:
        _normalized, expected = validate_archive(tf)
    source_fd = open_task_paths(create=False)
    try:
        rows = verify_tree(source_fd, expected)
    finally:
        os.close(source_fd)
    print("source_snapshot=PASS commit=" + COMMIT + " tree=" + TREE + " entries=" + str(rows))


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("prepare", "verify"):
        raise SystemExit("usage: source-rebind-pr1111-a64.py {prepare|verify}")
    if sys.argv[1] == "prepare":
        prepare()
    else:
        verify()
