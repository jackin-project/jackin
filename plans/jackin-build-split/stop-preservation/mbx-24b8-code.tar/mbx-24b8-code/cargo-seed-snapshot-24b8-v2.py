#!/usr/bin/python3
"""Copy only public Cargo registry and Git source caches into a private seed snapshot."""
import fcntl
import os
import pathlib
import posixpath
import stat
import sys

TASK = "/opt/.jackin-pr1111-24b8-mbx-20261005-v1"
SOURCE_TASK = "/opt/.jackin-mbx-current-17b2b1b-v5-62dfd1ac"
DEST_NAME = "seed-cargo-home"
UID = 65534
GID = 65534
FICLONE = 0x40049409
MAX_ENTRIES = 200_000
MAX_FILE = 512 * 1024 * 1024
MAX_TOTAL = 8 * 1024 * 1024 * 1024
DIR = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
FILE = os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC


def directory(fd, uid, gid, mode, label):
    st = os.fstat(fd)
    if not stat.S_ISDIR(st.st_mode) or (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) != (uid, gid, mode):
        raise SystemExit("unsafe directory identity: " + label)
    return st


def open_dir(parent, name, uid, gid, mode):
    fd = os.open(name, DIR, dir_fd=parent)
    try:
        directory(fd, uid, gid, mode, name)
        return fd
    except BaseException:
        os.close(fd)
        raise


def check_names(fd):
    names = os.listdir(fd)
    for name in names:
        if name in ("", ".", "..") or "/" in name or "\\" in name or "\x00" in name:
            raise SystemExit("unsafe Cargo cache name")
    return sorted(names)


def safe_link_target(prefix, name, target):
    if not target or target.startswith("/") or "\\" in target or "\x00" in target:
        raise SystemExit("unsafe Cargo cache symlink: " + name)
    resolved = posixpath.normpath(posixpath.join(prefix, target))
    if resolved == ".." or resolved.startswith("../"):
        raise SystemExit("Cargo cache symlink escapes its root: " + name)


def clone_tree(source, destination_parent, name, prefix, state):
    src = open_dir(source, name, UID, GID, 0o700)
    try:
        before = os.fstat(src)
        os.mkdir(name, 0o700, dir_fd=destination_parent)
        dst = os.open(name, DIR, dir_fd=destination_parent)
        try:
            os.fchown(dst, UID, GID)
            os.fchmod(dst, 0o700)
            dst_st=os.fstat(dst)
            if (dst_st.st_uid,dst_st.st_gid,stat.S_IMODE(dst_st.st_mode))!=(UID,GID,0o700):
                raise SystemExit("Cargo cache snapshot directory metadata mismatch: "+prefix)
            names = check_names(src)
            for leaf in names:
                if leaf in ("", ".", ".."):
                    raise SystemExit("unsafe Cargo cache entry")
                rel = prefix + "/" + leaf
                st = os.stat(leaf, dir_fd=src, follow_symlinks=False)
                state["entries"] += 1
                if state["entries"] > MAX_ENTRIES:
                    raise SystemExit("Cargo cache snapshot entry limit exceeded")
                if st.st_uid != UID or st.st_gid != GID:
                    raise SystemExit("Cargo cache source owner mismatch: " + rel)
                if stat.S_ISDIR(st.st_mode):
                    if stat.S_IMODE(st.st_mode) != 0o700:
                        raise SystemExit("Cargo cache directory mode mismatch: " + rel)
                    clone_tree(src, dst, leaf, rel, state)
                elif stat.S_ISREG(st.st_mode):
                    if st.st_mode & 0o022 or st.st_nlink != 1 or st.st_size < 0 or st.st_size > MAX_FILE:
                        raise SystemExit("Cargo cache file metadata mismatch: " + rel)
                    source_file = os.open(leaf, FILE, dir_fd=src)
                    try:
                        opened = os.fstat(source_file)
                        if (opened.st_dev, opened.st_ino, opened.st_size, opened.st_uid, opened.st_gid, opened.st_nlink) != (st.st_dev, st.st_ino, st.st_size, UID, GID, 1):
                            raise SystemExit("Cargo cache source changed while opening: " + rel)
                        target_file = os.open(leaf, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dst)
                        try:
                            fcntl.ioctl(target_file, FICLONE, source_file)
                            os.fchown(target_file, UID, GID)
                            os.fchmod(target_file, stat.S_IMODE(st.st_mode))
                            os.fsync(target_file)
                            copied = os.fstat(target_file)
                            after = os.fstat(source_file)
                            if (copied.st_uid, copied.st_gid, stat.S_IMODE(copied.st_mode), copied.st_nlink, copied.st_size) != (UID, GID, stat.S_IMODE(st.st_mode), 1, st.st_size):
                                raise SystemExit("Cargo cache snapshot file metadata mismatch: " + rel)
                            if (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) != (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns):
                                raise SystemExit("Cargo cache source mutated during reflink: " + rel)
                        finally:
                            os.close(target_file)
                    finally:
                        os.close(source_file)
                    state["bytes"] += st.st_size
                    if state["bytes"] > MAX_TOTAL:
                        raise SystemExit("Cargo cache snapshot byte limit exceeded")
                elif stat.S_ISLNK(st.st_mode):
                    target = os.readlink(leaf, dir_fd=src)
                    safe_link_target(prefix, leaf, target)
                    os.symlink(target, leaf, dir_fd=dst)
                    os.chown(leaf, UID, GID, dir_fd=dst, follow_symlinks=False)
                    copied=os.stat(leaf,dir_fd=dst,follow_symlinks=False)
                    if not stat.S_ISLNK(copied.st_mode) or (copied.st_uid,copied.st_gid)!=(UID,GID) or os.readlink(leaf,dir_fd=dst)!=target:
                        raise SystemExit("Cargo cache snapshot symlink metadata mismatch: "+rel)
                    after = os.stat(leaf, dir_fd=src, follow_symlinks=False)
                    if (after.st_dev, after.st_ino, after.st_uid, after.st_gid) != (st.st_dev, st.st_ino, UID, GID) or os.readlink(leaf, dir_fd=src) != target:
                        raise SystemExit("Cargo cache symlink mutated during snapshot: " + rel)
                else:
                    raise SystemExit("special Cargo cache source entry: " + rel)
            if check_names(src) != names:
                raise SystemExit("Cargo cache directory changed during snapshot: " + prefix)
            after_dir = os.fstat(src)
            if (after_dir.st_dev, after_dir.st_ino, after_dir.st_mtime_ns, after_dir.st_ctime_ns) != (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_ctime_ns):
                raise SystemExit("Cargo cache directory metadata changed during snapshot: " + prefix)
            os.fsync(dst)
        finally:
            os.close(dst)
    finally:
        os.close(src)


def open_task(path):
    p = pathlib.PurePosixPath(path)
    if not p.is_absolute() or any(x in ("", ".", "..") for x in p.parts[1:]):
        raise SystemExit("unsafe absolute path")
    fd = os.open("/", DIR)
    try:
        for name in p.parts[1:]:
            nxt = os.open(name, DIR, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise


def prepare():
    opt = os.open("/opt", DIR)
    directory(opt, 0, 0, 0o755, "/opt")
    source_task = open_task(SOURCE_TASK)
    directory(source_task, 0, 0, 0o700, "Cargo seed task")
    old_work = open_dir(source_task, "work", UID, GID, 0o700)
    old_home = open_dir(old_work, "cargo-home", UID, GID, 0o700)
    if set(os.listdir(old_home)) != {".global-cache", ".package-cache", ".package-cache-mutate", "bin", "git", "registry"}:
        raise SystemExit("source Cargo home has unexpected entries")
    task = open_dir(opt, pathlib.PurePosixPath(TASK).name, 0, 0, 0o700)
    expected_source = "source-24b8d5423a212130e4a1c60beffed860248b7f27"
    if set(os.listdir(task)) != {"work", expected_source}:
        raise SystemExit("24b8 task root is not at the expected pre-snapshot state")
    seed = os.open(DEST_NAME, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=task) if DEST_NAME in os.listdir(task) else -1
    if seed >= 0:
        os.close(seed)
        raise SystemExit("Cargo seed snapshot already exists; preserve it and choose a fresh task root")
    os.mkdir(DEST_NAME, 0o700, dir_fd=task)
    seed = open_dir(task, DEST_NAME, 0, 0, 0o700)
    state = {"entries": 0, "bytes": 0}
    try:
        for cache in ("registry", "git"):
            clone_tree(old_home, seed, cache, cache, state)
        os.fsync(seed)
    finally:
        os.close(seed)
        os.close(task)
        os.close(old_home)
        os.close(old_work)
        os.close(source_task)
        os.close(opt)
    print("cargo_seed_snapshot=PASS roots=registry,git entries=%d bytes=%d method=FICLONE private_parent=root:root0700" % (state["entries"], state["bytes"]))


if __name__ == "__main__":
    if sys.argv[1:] != ["prepare"]:
        raise SystemExit("usage: cargo-seed-snapshot-24b8-v2.py prepare")
    prepare()
