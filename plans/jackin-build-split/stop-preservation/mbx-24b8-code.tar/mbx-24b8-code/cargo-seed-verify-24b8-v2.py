#!/usr/bin/python3
"""Read-only verifier for the exact PR #1111 24b8 Cargo source seed."""
import hashlib, io, json, os, pathlib, posixpath, re, stat, subprocess, tarfile, tomllib
from datetime import datetime
SEED='/opt/.jackin-pr1111-24b8-mbx-20261005-v1/seed-cargo-home'
SEED_ORIGIN='/opt/.jackin-mbx-current-17b2b1b-v5-62dfd1ac/work/cargo-home'
SOURCE='/opt/.jackin-pr1111-24b8-mbx-20261005-v1/source-24b8d5423a212130e4a1c60beffed860248b7f27'
LOCK_SHA='5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097'
REGISTRY='index.crates.io-1949cf8c6b5b557f'
UID=65534; GID=65534; MAX_ENTRIES=100000; MAX_FILE=512*1024*1024; MAX_TOTAL=5*1024*1024*1024
MAX_INDEX=32*1024*1024

def abs_dir(path):
    p=pathlib.PurePosixPath(path)
    if not p.is_absolute() or any(x in ('','.','..') for x in p.parts[1:]): raise SystemExit('unsafe absolute path')
    fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        for i,n in enumerate(p.parts[1:],1):
            nxt=os.open(n,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
            st=os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or st.st_uid!=0 or st.st_gid!=0 or (i<len(p.parts)-1 and st.st_mode&0o022):
                os.close(nxt); raise SystemExit('unsafe root path component: '+n)
            if p.parts[1]=='opt' and i==1 and stat.S_IMODE(st.st_mode)!=0o755: os.close(nxt); raise SystemExit('/opt mode mismatch')
            if p.parts[1]=='root' and i==1 and stat.S_IMODE(st.st_mode)!=0o700: os.close(nxt); raise SystemExit('/root mode mismatch')
            os.close(fd); fd=nxt
        return fd
    except BaseException:
        os.close(fd); raise

def read_regular_at(parent,name,owner,group,mode_limit=0o022,max_size=8*1024*1024):
    fd=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent); st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid)!=(owner,group) or st.st_mode&mode_limit or st.st_nlink!=1 or st.st_size<0 or st.st_size>max_size:
        os.close(fd); raise SystemExit('unsafe regular input: '+name)
    chunks=[]; total=0; h=hashlib.sha256()
    while True:
        b=os.read(fd,min(1024*1024,max_size+1-total))
        if not b: break
        total+=len(b)
        if total>max_size: os.close(fd); raise SystemExit('input exceeds size bound: '+name)
        chunks.append(b); h.update(b)
    after=os.fstat(fd); os.close(fd)
    if total!=st.st_size or (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
        raise SystemExit('input changed while reading: '+name)
    return b''.join(chunks),h.hexdigest(),st

def relative_dir(rootfd,parts,uid,gid):
    fd=os.dup(rootfd)
    try:
        for name in parts:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); st=os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or (st.st_uid,st.st_gid)!=(uid,gid) or st.st_mode&0o022:
                os.close(nxt); raise SystemExit('unsafe cache directory: '+name)
            os.close(fd); fd=nxt
        return fd
    except BaseException:
        os.close(fd); raise

def index_path(name):
    n=name.lower()
    if not n or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789_-+' for c in n): raise SystemExit('invalid registry package name')
    if len(n)==1: return '1/'+n
    if len(n)==2: return '2/'+n
    if len(n)==3: return '3/'+n[0]+'/'+n
    return n[:2]+'/'+n[2:4]+'/'+n

def read_relative_file(rootfd, parts, max_size=8*1024*1024):
    """Read one cache file through nofollow dirfds and verify its stable identity."""
    if not parts or any(not part or part in ('.','..') or '/' in part or '\\' in part for part in parts):
        raise SystemExit('unsafe relative cache file path')
    parent=os.dup(rootfd)
    try:
        for name in parts[:-1]:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
            st=os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700):
                os.close(nxt); raise SystemExit('unsafe Git cache directory: '+name)
            os.close(parent); parent=nxt
        fd=os.open(parts[-1],os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(UID,GID,0o600,1) or st.st_size<0 or st.st_size>max_size:
            os.close(fd); raise SystemExit('unsafe Git metadata file: '+'/'.join(parts))
        data=bytearray()
        while True:
            block=os.read(fd,min(65536,max_size+1-len(data)))
            if not block: break
            data.extend(block)
            if len(data)>max_size: os.close(fd); raise SystemExit('Git metadata exceeds bound')
        after=os.fstat(fd); os.close(fd)
        if len(data)!=st.st_size or (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
            raise SystemExit('Git metadata changed while reading: '+'/'.join(parts))
        return bytes(data)
    finally:
        os.close(parent)

def git_checkout_config(repo,db_name):
    return (('[core]\n\tbare = false\n\trepositoryformatversion = 0\n\tfilemode = true\n\tlogallrefupdates = true\n\tautocrlf = false\n'
             '[remote "origin"]\n\turl = file:///work/cargo-home/git/db/'+db_name+'\n\tfetch = +refs/heads/*:refs/remotes/origin/*\n'
             '[branch "master"]\n\tremote = origin\n\tmerge = refs/heads/master\n').encode())

def validate_git_metadata(repo,db_name,revision,checkout_head,checkout_ref,checkout_config,db_head,db_ref,db_config):
    expected_config=git_checkout_config(repo,db_name)
    expected_db_config=b'[core]\n\tbare = true\n\trepositoryformatversion = 0\n\tfilemode = true\n'
    if checkout_head!=b'ref: refs/heads/master\n' or checkout_ref!=(revision+'\n').encode():
        raise SystemExit('Git checkout HEAD/ref mismatch: '+repo)
    if checkout_config!=expected_config:
        raise SystemExit('Git checkout config differs from the exact local cache route: '+repo)
    if db_head!=b'ref: refs/heads/master\n' or db_ref!=(revision+'\n').encode() or db_config!=expected_db_config:
        raise SystemExit('Git object database identity/config mismatch: '+repo)

def require_empty_object_info(gitdir_fd,repo,label):
    objects=os.open('objects',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=gitdir_fd)
    try:
        info=os.open('info',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=objects)
        try:
            if os.listdir(info):
                raise SystemExit('Git '+label+' contains external alternates or unexpected info files: '+repo)
        finally: os.close(info)
    finally: os.close(objects)

def verify_git_seed(gitfd, gitpkgs):
    expected={
        'termrock':('termrock-80ba21de23b1804f','1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4'),
        'termpane':('termpane-bf9ac2d357304fc4','04382971db3d13c8f23e0749b8330be4bb08324a'),
    }
    package_sources={
        'termpane':'git+https://github.com/tailrocks/termpane.git?tag=v0.1.0#04382971db3d13c8f23e0749b8330be4bb08324a',
        'termrock':'git+https://github.com/tailrocks/termrock.git?rev=1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4#1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4',
        'termrock-raster':'git+https://github.com/tailrocks/termrock.git?rev=1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4#1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4',
    }
    if {p['name']:p['source'] for p in gitpkgs}!=package_sources:
        raise SystemExit('24b8 Cargo.lock Git package identities differ')
    if set(os.listdir(gitfd))!={'CACHEDIR.TAG','db','checkouts'}:
        raise SystemExit('unexpected Git cache root inventory')
    dbfd=os.open('db',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=gitfd)
    checkoutfd=os.open('checkouts',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=gitfd)
    try:
        if set(os.listdir(dbfd))!={x[0] for x in expected.values()} or set(os.listdir(checkoutfd))!={x[0] for x in expected.values()}:
            raise SystemExit('Git cache contains missing or unexpected repositories')
        verified=[]
        for repo,(db_name,revision) in expected.items():
            db=os.open(db_name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dbfd)
            checkout_repo=os.open(db_name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=checkoutfd)
            try:
                for dfd,label in ((db,'database'),(checkout_repo,'checkout')):
                    st=os.fstat(dfd)
                    if not stat.S_ISDIR(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700):
                        raise SystemExit('unsafe Git '+label+' root: '+repo)
                short=revision[:7]
                if set(os.listdir(checkout_repo))!={short}:
                    raise SystemExit('Git checkout path does not match locked revision: '+repo)
                checkout=os.open(short,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=checkout_repo)
                try:
                    validate_git_metadata(
                        repo,db_name,revision,
                        read_relative_file(checkout,('.git','HEAD')),
                        read_relative_file(checkout,('.git','refs','heads','master')),
                        read_relative_file(checkout,('.git','config')),
                        read_relative_file(db,('HEAD',)),
                        read_relative_file(db,('refs','commit',revision)),
                        read_relative_file(db,('config',)),
                    )
                    # No alternates, hooks, transport remapping, or credential-bearing URL is accepted.
                    dotgit=os.open('.git',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=checkout)
                    try: require_empty_object_info(dotgit,repo,'checkout objects/info')
                    finally: os.close(dotgit)
                    require_empty_object_info(db,repo,'bare object database objects/info')
                    checkout_path=SEED+'/git/checkouts/'+db_name+'/'+short
                    env={'PATH':'/usr/bin:/bin','HOME':'/nonexistent','LC_ALL':'C','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1'}
                    rev=subprocess.run(['/usr/bin/git','--no-pager','-c','safe.directory='+checkout_path,'-C',checkout_path,'rev-parse','--verify','HEAD^{commit}'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False,env=env)
                    if rev.returncode!=0 or rev.stdout!=(revision+'\n').encode() or rev.stderr:
                        raise SystemExit('pinned Git checkout does not resolve to locked commit: '+repo)
                    verify_git_checkout_tree(checkout,checkout_path,revision,env)
                    status=subprocess.run(['/usr/bin/git','--no-pager','-c','safe.directory='+checkout_path,'-C',checkout_path,'status','--porcelain=v1','--untracked-files=all','--ignore-submodules=none'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False,env=env)
                    if status.returncode!=0 or status.stdout or status.stderr:
                        raise SystemExit('pinned Git checkout is not clean: '+repo)
                    object_check=subprocess.run(['/usr/bin/git','--no-pager','--git-dir='+SEED+'/git/db/'+db_name,'cat-file','-e',revision+'^{commit}'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False,env=env)
                    if object_check.returncode!=0 or object_check.stdout or object_check.stderr:
                        raise SystemExit('locked Git commit object is unavailable: '+repo)
                finally: os.close(checkout)
                verified.append(repo+':'+revision)
            finally:
                os.close(db); os.close(checkout_repo)
        return sorted(verified)
    finally:
        os.close(dbfd); os.close(checkoutfd)

def open_relative_dir(rootfd, parts):
    fd=os.dup(rootfd)
    try:
        for name in parts:
            nxt=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
            st=os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700):
                os.close(nxt); raise SystemExit('unsafe registry source directory: '+name)
            os.close(fd); fd=nxt
        return fd
    except BaseException:
        os.close(fd); raise

def verify_extracted_crate(registryfd,name,version,checksum):
    base=name+'-'+version
    archive_path=f'cache/{REGISTRY}/{base}.crate'
    archive_parts=archive_path.split('/')
    archive_parent=open_relative_dir(registryfd,archive_parts[:-1])
    try: archive,archive_hash,_=read_regular_at(archive_parent,archive_parts[-1],UID,GID,max_size=MAX_FILE)
    finally: os.close(archive_parent)
    if archive_hash!=checksum: raise SystemExit('locked .crate archive changed while opening: '+base)
    expected={base:{'type':'dir'}}
    total=0
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:*') as tf:
        members=tf.getmembers()
        if not members or len(members)>100000: raise SystemExit('crate archive member count outside bound: '+base)
        for member in members:
            original=member.name
            if original.endswith('/') and member.isdir(): original=original[:-1]
            p=pathlib.PurePosixPath(original)
            if not original or p.is_absolute() or str(p)!=original or '\\' in original or '\x00' in original or any(x in ('','.','..') for x in p.parts) or p.parts[0]!=base:
                raise SystemExit('unsafe path in locked crate archive: '+base)
            rel='/'.join(p.parts)
            if rel==base:
                if not member.isdir(): raise SystemExit('crate archive root is not a directory: '+base)
                continue
            if rel in expected or member.mode&0o7000: raise SystemExit('duplicate or special-mode crate archive path: '+rel)
            if member.isdir():
                expected[rel]={'type':'dir'}
            elif member.isfile():
                if member.size<0 or member.size>MAX_FILE: raise SystemExit('crate archive member exceeds size bound: '+rel)
                stream=tf.extractfile(member)
                if stream is None: raise SystemExit('crate archive file is unreadable: '+rel)
                h=hashlib.sha256(); count=0
                with stream:
                    while True:
                        block=stream.read(1024*1024)
                        if not block: break
                        count+=len(block); total+=len(block)
                        if count>member.size or total>MAX_TOTAL: raise SystemExit('crate archive expanded size exceeds bound: '+base)
                        h.update(block)
                if count!=member.size: raise SystemExit('crate archive member length mismatch: '+rel)
                expected[rel]={'type':'file','size':count,'sha256':h.hexdigest()}
            elif member.issym():
                target=member.linkname
                if not target or target.startswith('/') or '\\' in target or '\x00' in target:
                    raise SystemExit('unsafe crate archive symlink: '+rel)
                resolved=pathlib.PurePosixPath(os.path.normpath(str(p.parent/target)))
                if resolved.is_absolute() or any(x=='..' for x in resolved.parts):
                    raise SystemExit('crate archive symlink escapes package: '+rel)
                expected[rel]={'type':'symlink','target':target}
            else:
                raise SystemExit('unsupported locked crate archive member type: '+rel)
            for parent in p.parents:
                parent_name='/'.join(parent.parts)
                if parent_name in ('','.'): continue
                if parent_name not in expected:
                    if parent.parts[0]!=base: raise SystemExit('crate archive parent escapes package')
                    expected[parent_name]={'type':'dir'}
                elif expected[parent_name]['type']!='dir':
                    raise SystemExit('crate archive member descends through non-directory')
    # Cargo adds this fixed marker after extraction; it is not part of the archive.
    expected[base+'/.cargo-ok']={'type':'file','size':7,'sha256':hashlib.sha256(b'{"v":1}').hexdigest()}
    source_root=open_relative_dir(registryfd,['src',REGISTRY,base])
    try:
        seen={base}; stack=[(os.dup(source_root),base)]
        while stack:
            dfd,prefix=stack.pop()
            try:
                for leaf in os.listdir(dfd):
                    rel=prefix+'/'+leaf
                    want=expected.get(rel)
                    if want is None: raise SystemExit('unexpected extracted crate path: '+rel)
                    st=os.stat(leaf,dir_fd=dfd,follow_symlinks=False)
                    if stat.S_ISDIR(st.st_mode):
                        if want['type']!='dir' or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700):
                            raise SystemExit('extracted crate directory metadata/content mismatch: '+rel)
                        child=os.open(leaf,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
                        opened=os.fstat(child)
                        if (opened.st_dev,opened.st_ino)!=(st.st_dev,st.st_ino): os.close(child); raise SystemExit('extracted crate directory changed: '+rel)
                        stack.append((child,rel)); seen.add(rel)
                    elif stat.S_ISREG(st.st_mode):
                        if want['type']!='file' or (st.st_uid,st.st_gid,st.st_nlink)!=(UID,GID,1) or st.st_mode&0o022 or st.st_size!=want['size']:
                            raise SystemExit('extracted crate file metadata mismatch: '+rel)
                        fd=os.open(leaf,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
                        opened=os.fstat(fd)
                        if (opened.st_dev,opened.st_ino,opened.st_size,opened.st_uid,opened.st_gid)!=(st.st_dev,st.st_ino,st.st_size,UID,GID): os.close(fd); raise SystemExit('extracted crate file changed: '+rel)
                        h=hashlib.sha256(); count=0
                        while True:
                            block=os.read(fd,1024*1024)
                            if not block: break
                            count+=len(block)
                            if count>st.st_size: os.close(fd); raise SystemExit('extracted crate file grew: '+rel)
                            h.update(block)
                        os.close(fd)
                        if count!=want['size'] or h.hexdigest()!=want['sha256']: raise SystemExit('extracted crate bytes differ from locked archive: '+rel)
                        seen.add(rel)
                    elif stat.S_ISLNK(st.st_mode):
                        if want['type']!='symlink' or st.st_uid!=UID or st.st_gid!=GID or os.readlink(leaf,dir_fd=dfd)!=want['target']:
                            raise SystemExit('extracted crate symlink differs from locked archive: '+rel)
                        seen.add(rel)
                    else: raise SystemExit('special extracted crate entry: '+rel)
            finally: os.close(dfd)
        if seen!=set(expected): raise SystemExit('extracted crate inventory differs from locked archive: '+base)
    finally: os.close(source_root)
    return len(expected)

def unique_json_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:
            raise ValueError('duplicate JSON object key')
        result[key]=value
    return result

def verify_sparse_index(registryfd, package_name, locked_versions):
    parts=['index',REGISTRY,'.cache']+index_path(package_name).split('/')
    data=read_relative_file(registryfd,parts,max_size=MAX_INDEX)
    if not data.startswith(b'\x03\x02\x00\x00\x00'):
        raise SystemExit('unsupported sparse index cache format: '+package_name)
    pos=5
    etag_end=data.find(b'\0',pos)
    if etag_end<0 or etag_end-pos>4096:
        raise SystemExit('malformed sparse index cache validator: '+package_name)
    try: etag=data[pos:etag_end].decode('ascii')
    except UnicodeDecodeError: raise SystemExit('non-ASCII sparse index cache validator: '+package_name)
    if not etag.startswith('etag: ') or '\n' in etag or '\r' in etag:
        raise SystemExit('unexpected sparse index cache validator: '+package_name)
    pos=etag_end+1
    found={}
    while pos<len(data):
        version_end=data.find(b'\0',pos)
        if version_end<0 or version_end==pos:
            raise SystemExit('malformed sparse index version entry: '+package_name)
        record_end=data.find(b'\0',version_end+1)
        if record_end<0:
            raise SystemExit('truncated sparse index JSON entry: '+package_name)
        try:
            version=data[pos:version_end].decode('ascii')
            record=json.loads(data[version_end+1:record_end],object_pairs_hook=unique_json_object)
        except (UnicodeDecodeError,ValueError,TypeError):
            raise SystemExit('invalid sparse index JSON entry: '+package_name)
        if not isinstance(record,dict) or not isinstance(record.get('name'),str) or record['name']!=package_name or record.get('vers')!=version:
            raise SystemExit('sparse index package/version identity mismatch: '+package_name)
        checksum=record.get('cksum')
        if not isinstance(checksum,str) or re.fullmatch(r'[0-9a-f]{64}',checksum) is None or version in found:
            raise SystemExit('invalid or duplicate sparse index checksum: '+package_name)
        found[version]=checksum
        if version in locked_versions:
            validate_locked_index_record(record,package_name,version)
        pos=record_end+1
    for version,checksum in locked_versions.items():
        if found.get(version)!=checksum:
            raise SystemExit('sparse index locked version/checksum mismatch: '+package_name+' '+version)

def index_text(value, label, maximum=4096):
    if not isinstance(value,str) or len(value)>maximum:
        raise SystemExit('invalid sparse index string: '+label)
    return value

def index_string_list(value,label):
    if not isinstance(value,list) or any(not isinstance(item,str) or len(item)>MAX_INDEX for item in value):
        raise SystemExit('invalid sparse index string list: '+label)

def index_feature_map(value,label):
    if not isinstance(value,dict):
        raise SystemExit('invalid sparse index feature map: '+label)
    for key,features in value.items():
        index_text(key,label+' feature name')
        index_string_list(features,label+' feature '+key)

def validate_locked_index_record(record,package_name,version):
    """Check structural fields for locked index rows under Cargo 1.97's schema."""
    known_fields={'name','vers','deps','features','cksum','yanked','links','rust_version','pubtime','v','features2'}
    if set(record)-known_fields:
        raise SystemExit('unsupported sparse index fields for pinned Cargo: '+package_name+' '+version)
    schema=record.get('v',1)
    if schema is None: schema=1
    if type(schema) is not int or schema not in (1,2):
        raise SystemExit('unsupported sparse index schema version: '+package_name+' '+version)
    deps=record.get('deps')
    if not isinstance(deps,list):
        raise SystemExit('invalid sparse index dependency array: '+package_name+' '+version)
    dep_name=re.compile(r'[A-Za-z0-9_-]+\Z')
    for dep in deps:
        if not isinstance(dep,dict):
            raise SystemExit('invalid sparse index dependency record: '+package_name+' '+version)
        known_dependency_fields={'name','req','features','optional','default_features','target','kind','registry','package','public'}
        if set(dep)-known_dependency_fields:
            raise SystemExit('unsupported sparse index dependency fields for pinned Cargo: '+package_name+' '+version)
        name=index_text(dep.get('name'),'dependency name')
        if dep_name.fullmatch(name) is None:
            raise SystemExit('invalid sparse index dependency name: '+package_name+' '+version)
        index_text(dep.get('req'),'dependency requirement')
        # The pinned Cargo metadata phase validates requirement and target syntax.
        if 'features' in dep:
            index_string_list(dep['features'],'dependency features')
        for field,default in (('optional',False),('default_features',True)):
            if field in dep and type(dep[field]) is not bool:
                raise SystemExit('invalid sparse index dependency boolean: '+field)
        if 'target' in dep and dep['target'] is not None:
            index_text(dep['target'],'dependency target')
        if 'kind' in dep and dep['kind'] is not None and dep['kind'] not in ('normal','build','dev'):
            raise SystemExit('invalid sparse index dependency kind')
        if 'registry' in dep and dep['registry'] is not None:
            index_text(dep['registry'],'dependency registry')
        if 'package' in dep and dep['package'] is not None:
            package=index_text(dep['package'],'renamed dependency package')
            if dep_name.fullmatch(package) is None:
                raise SystemExit('invalid sparse index renamed dependency package')
        if 'public' in dep and dep['public'] is not None and type(dep['public']) is not bool:
            raise SystemExit('invalid sparse index public dependency flag')
    index_feature_map(record.get('features',{}),'features')
    features2=record.get('features2')
    if features2 is not None:
        if schema<2:
            raise SystemExit('extended sparse index features require schema version 2')
        index_feature_map(features2,'features2')
    if record.get('yanked') is not None and type(record['yanked']) is not bool:
        raise SystemExit('invalid sparse index yanked flag')
    if 'links' in record and record['links'] is not None:
        index_text(record['links'],'links')
    if record.get('rust_version') is not None:
        index_text(record['rust_version'],'rust_version')
    if record.get('pubtime') is not None:
        pubtime=index_text(record['pubtime'],'pubtime',maximum=32)
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z',pubtime) is None:
            raise SystemExit('invalid sparse index publish time')
        try:
            if datetime.strptime(pubtime,'%Y-%m-%dT%H:%M:%SZ').strftime('%Y-%m-%dT%H:%M:%SZ')!=pubtime:
                raise ValueError('noncanonical publish time')
        except ValueError:
            raise SystemExit('invalid sparse index publish time')

def verify_registry_config(registryfd):
    indexfd=open_relative_dir(registryfd,['index',REGISTRY])
    try:
        raw,_,_=read_regular_at(indexfd,'config.json',UID,GID,max_size=65536)
    finally: os.close(indexfd)
    try: config=json.loads(raw,object_pairs_hook=unique_json_object)
    except (ValueError,TypeError): raise SystemExit('invalid Cargo registry config')
    if config!={'dl':'https://static.crates.io/crates','api':'https://crates.io'}:
        raise SystemExit('Cargo registry config is not the pinned crates.io endpoint')

def git_tree_entries(checkout_path,revision,env):
    result=subprocess.run(['/usr/bin/git','--no-pager','-c','safe.directory='+checkout_path,'-C',checkout_path,'ls-tree','-r','-z','--full-tree',revision],
        stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,check=False,env=env)
    if result.returncode!=0 or result.stderr or len(result.stdout)>64*1024*1024:
        raise SystemExit('cannot read locked Git tree')
    entries={}
    for item in result.stdout.split(b'\0'):
        if not item: continue
        try: metadata,path=item.split(b'\t',1); mode,kind,oid=metadata.split(b' ',2)
        except ValueError: raise SystemExit('malformed locked Git tree row')
        if mode not in (b'100644',b'100755',b'120000') or kind!=b'blob' or re.fullmatch(rb'[0-9a-f]{40}',oid) is None:
            raise SystemExit('unsupported locked Git tree entry')
        rel=os.fsdecode(path); path_parts=rel.split('/')
        if not rel or rel.startswith('/') or any(x in ('','.','..') for x in path_parts) or rel in entries:
            raise SystemExit('unsafe or duplicate locked Git path')
        entries[rel]=(mode.decode('ascii'),oid.decode('ascii'))
    if not entries: raise SystemExit('locked Git tree has no files')
    return entries

def git_blob_hash(data_length,chunks):
    h=hashlib.sha1(); h.update(('blob %d\0'%data_length).encode('ascii')); total=0
    for block in chunks: total+=len(block); h.update(block)
    if total!=data_length: raise SystemExit('Git worktree file length changed')
    return h.hexdigest()

def verify_git_checkout_tree(checkoutfd,checkout_path,revision,env):
    expected=git_tree_entries(checkout_path,revision,env)
    expected_dirs=set()
    for rel in expected:
        parts=rel.split('/')
        expected_dirs.update('/'.join(parts[:i]) for i in range(1,len(parts)))
    seen=set(); stack=[(os.dup(checkoutfd),'')]
    while stack:
        dfd,prefix=stack.pop()
        try:
            for leaf in os.listdir(dfd):
                if not prefix and leaf=='.git': continue
                rel=(prefix+'/' if prefix else '')+leaf
                st=os.stat(leaf,dir_fd=dfd,follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    if rel not in expected_dirs or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700):
                        raise SystemExit('unexpected or unsafe Git checkout directory: '+rel)
                    child=os.open(leaf,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
                    opened=os.fstat(child)
                    if (opened.st_dev,opened.st_ino)!=(st.st_dev,st.st_ino):
                        os.close(child); raise SystemExit('Git checkout directory changed: '+rel)
                    stack.append((child,rel)); continue
                wanted=expected.get(rel)
                if wanted is None: raise SystemExit('untracked Git checkout path: '+rel)
                mode,oid=wanted
                if (st.st_uid,st.st_gid)!=(UID,GID): raise SystemExit('Git checkout file owner mismatch: '+rel)
                if stat.S_ISREG(st.st_mode) and mode in ('100644','100755'):
                    executable=bool(st.st_mode&0o111)
                    if st.st_nlink!=1 or st.st_mode&0o022 or executable!=(mode=='100755') or st.st_size<0 or st.st_size>MAX_FILE:
                        raise SystemExit('Git checkout file mode/size mismatch: '+rel)
                    fd=os.open(leaf,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
                    opened=os.fstat(fd)
                    if (opened.st_dev,opened.st_ino,opened.st_size,opened.st_nlink)!=(st.st_dev,st.st_ino,st.st_size,1):
                        os.close(fd); raise SystemExit('Git checkout file changed: '+rel)
                    def blocks():
                        while True:
                            block=os.read(fd,1024*1024)
                            if not block: break
                            yield block
                    actual=git_blob_hash(st.st_size,blocks()); after=os.fstat(fd); os.close(fd)
                    if (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)!=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns) or actual!=oid:
                        raise SystemExit('Git checkout bytes differ from locked commit: '+rel)
                elif stat.S_ISLNK(st.st_mode) and mode=='120000':
                    raw=os.fsencode(os.readlink(leaf,dir_fd=dfd))
                    if git_blob_hash(len(raw),(raw,))!=oid: raise SystemExit('Git checkout symlink differs from locked commit: '+rel)
                else:
                    raise SystemExit('Git checkout type differs from locked commit: '+rel)
                seen.add(rel)
        finally: os.close(dfd)
    if seen!=set(expected):
        raise SystemExit('Git checkout inventory differs from locked commit: missing='+str(len(set(expected)-seen)))

def main():
    opt=abs_dir('/opt')
    task=os.open('.jackin-pr1111-24b8-mbx-20261005-v2',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=opt); ts=os.fstat(task)
    if (ts.st_uid,ts.st_gid,stat.S_IMODE(ts.st_mode))!=(0,0,0o700): raise SystemExit('unsafe 24b8 task root')
    seed=os.open('seed-cargo-home',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=task); ss=os.fstat(seed)
    if (ss.st_uid,ss.st_gid,stat.S_IMODE(ss.st_mode))!=(0,0,0o700) or set(os.listdir(seed))!={'registry','git'}:
        raise SystemExit('unsafe private Cargo seed snapshot root')
    roots={}
    for name in ('registry','git'):
        roots[name]=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=seed); st=os.fstat(roots[name])
        if (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))!=(UID,GID,0o700): raise SystemExit('unsafe Cargo seed root: '+name)
    srcroot=abs_dir(SOURCE)
    try:
        sfd=os.open('Cargo.lock',os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=srcroot); ss=os.fstat(sfd)
        if not stat.S_ISREG(ss.st_mode) or (ss.st_uid,ss.st_gid)!=(0,0) or stat.S_IMODE(ss.st_mode)!=0o444 or ss.st_nlink!=1 or ss.st_size>2*1024*1024:
            os.close(sfd); raise SystemExit('unsafe exact-source Cargo.lock')
        raw=b''
        while True:
            b=os.read(sfd,1024*1024)
            if not b: break
            raw+=b
        os.close(sfd)
    finally: os.close(srcroot)
    lockhash=hashlib.sha256(raw).hexdigest()
    if lockhash!=LOCK_SHA: raise SystemExit('exact source Cargo.lock digest mismatch')
    lock=tomllib.loads(raw.decode('utf-8'))
    registry=[p for p in lock['package'] if p.get('source','').startswith('registry+')]
    gitpkgs=[p for p in lock['package'] if p.get('source','').startswith('git+')]
    if len(registry)!=762 or len(gitpkgs)!=3: raise SystemExit('unexpected lock package source counts')
    if any(p.get('source')!='registry+https://github.com/rust-lang/crates.io-index' for p in registry):
        raise SystemExit('unexpected Cargo registry source identity')
    rows=[]; total=0
    for root_name,rootfd in roots.items():
        stack=[(os.dup(rootfd),'')]
        while stack:
            fd,prefix=stack.pop()
            try:
                for name in os.listdir(fd):
                    if name in ('','.','..') or '/' in name or '\\' in name: raise SystemExit('unsafe cache entry name')
                    rel=(prefix+'/' if prefix else '')+name
                    st=os.stat(name,dir_fd=fd,follow_symlinks=False)
                    if st.st_uid!=UID or st.st_gid!=GID: raise SystemExit('cache entry owner mismatch: '+root_name+'/'+rel)
                    if stat.S_ISDIR(st.st_mode):
                        if st.st_mode&0o022 or stat.S_IMODE(st.st_mode)!=0o700: raise SystemExit('unsafe cache directory mode: '+root_name+'/'+rel)
                        child=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); opened=os.fstat(child)
                        if (opened.st_dev,opened.st_ino)!=(st.st_dev,st.st_ino): os.close(child); raise SystemExit('cache directory race')
                        stack.append((child,rel)); rows.append({'root':root_name,'path':rel,'type':'dir','mode':stat.S_IMODE(st.st_mode),'dev':st.st_dev,'ino':st.st_ino})
                    elif stat.S_ISREG(st.st_mode):
                        if st.st_mode&0o022 or st.st_nlink!=1 or st.st_size<0 or st.st_size>MAX_FILE: raise SystemExit('unsafe cache file metadata: '+root_name+'/'+rel)
                        leaf=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd); opened=os.fstat(leaf)
                        if (opened.st_dev,opened.st_ino,opened.st_size,opened.st_uid,opened.st_gid)!=(st.st_dev,st.st_ino,st.st_size,UID,GID): os.close(leaf); raise SystemExit('cache file race')
                        h=hashlib.sha256(); count=0
                        while True:
                            b=os.read(leaf,1024*1024)
                            if not b: break
                            count+=len(b); total+=len(b)
                            if count>st.st_size or total>MAX_TOTAL: os.close(leaf); raise SystemExit('Cargo seed size bound exceeded')
                            h.update(b)
                        after=os.fstat(leaf); os.close(leaf)
                        if count!=st.st_size or (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)!=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns): raise SystemExit('cache file changed while hashing: '+root_name+'/'+rel)
                        rows.append({'root':root_name,'path':rel,'type':'file','mode':stat.S_IMODE(st.st_mode),'size':count,'sha256':h.hexdigest()})
                    elif stat.S_ISLNK(st.st_mode):
                        target=os.readlink(name,dir_fd=fd)
                        if not target or target.startswith('/') or '\\' in target: raise SystemExit('unsafe cache symlink: '+root_name+'/'+rel)
                        full=os.path.realpath(os.path.join(SEED,root_name,rel))
                        if os.path.commonpath((os.path.realpath(SEED+'/'+root_name),full))!=os.path.realpath(SEED+'/'+root_name) or not os.path.exists(full): raise SystemExit('cache symlink escapes or is dangling: '+root_name+'/'+rel)
                        rows.append({'root':root_name,'path':rel,'type':'symlink','mode':stat.S_IMODE(st.st_mode),'target':target})
                    else: raise SystemExit('special cache entry: '+root_name+'/'+rel)
                    if len(rows)>MAX_ENTRIES: raise SystemExit('Cargo seed entry bound exceeded')
            finally: os.close(fd)
    # Exact registry archives and extracted source dirs must match every lock row.
    filehash={(r['root'],r['path']):r.get('sha256') for r in rows if r['type']=='file'}
    names={ (r['root'],r['path']) for r in rows if r['type']=='dir'}
    registryfd=roots['registry']
    extracted_files=0; locked_indexes={}
    for p in registry:
        n,v,checksum=p['name'],p['version'],p['checksum']; base=f'{n}-{v}'
        if ('registry',f'src/{REGISTRY}/{base}') not in names: raise SystemExit('missing locked extracted crate: '+base)
        rel=f'cache/{REGISTRY}/{base}.crate'
        if filehash.get(('registry',rel))!=checksum: raise SystemExit('locked archive checksum mismatch: '+base)
        ix=f'index/{REGISTRY}/.cache/{index_path(n)}'
        if ('registry',ix) not in filehash: raise SystemExit('missing locked sparse index row: '+n)
        versions=locked_indexes.setdefault(n,{})
        if v in versions and versions[v]!=checksum: raise SystemExit('duplicate locked package version has conflicting checksum: '+base)
        versions[v]=checksum
        extracted_files+=verify_extracted_crate(registryfd,n,v,checksum)
    verify_registry_config(registryfd)
    for n,versions in sorted(locked_indexes.items()):
        verify_sparse_index(registryfd,n,versions)
    verified_git=verify_git_seed(roots['git'],gitpkgs)
    rows.sort(key=lambda r:(r['root'],r['path']))
    output={'schema':'jackin-cargo-source-seed-24b8-v2','seed_root':SEED,'seed_origin':SEED_ORIGIN,'snapshot_method':'task-root-private FICLONE of registry and git only','included_roots':['registry','git'],'excluded':['bin','Cargo-home runtime files','target','MBX cache','config and credentials'],'source_commit':'24b8d5423a212130e4a1c60beffed860248b7f27','source_tree':'63e21941838f728583e22220e9432f6afceb90b9','source_archive_sha256':'c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a','cargo_lock_sha256':lockhash,'registry_packages':len(registry),'registry_versions_verified':sum(len(v) for v in locked_indexes.values()),'registry_config_verified':'https://static.crates.io/crates','registry_archive_checksums_verified':len(registry),'registry_extracted_crates_content_verified':len(registry),'registry_extracted_entries_verified':extracted_files,'git_packages':len(gitpkgs),'git_revisions_verified':verified_git,'git_checkout_blobs_verified':len(gitpkgs),'entries':len(rows),'regular_files':sum(r['type']=='file' for r in rows),'directories':sum(r['type']=='dir' for r in rows),'symlinks':sum(r['type']=='symlink' for r in rows),'regular_bytes':total,'inventory':rows}
    encoded=(json.dumps(output,sort_keys=True,separators=(',',':'))+'\n').encode()
    outdir='/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8'
    dfd=abs_dir(outdir)
    try:
        try: existing=os.open('cargo-seed-24b8-v2.json',os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
        except FileNotFoundError:
            fd=os.open('cargo-seed-24b8-v2.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=dfd)
            view=memoryview(encoded)
            while view: view=view[os.write(fd,view):]
            os.fsync(fd); os.close(fd); os.fsync(dfd)
        else:
            st=os.fstat(existing)
            if not stat.S_ISREG(st.st_mode) or (st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode),st.st_nlink)!=(0,0,0o600,1) or st.st_size!=len(encoded) or st.st_size>64*1024*1024:
                os.close(existing); raise SystemExit('unsafe existing cargo seed manifest')
            chunks=[]
            while True:
                block=os.read(existing,65536)
                if not block: break
                chunks.append(block)
            os.close(existing)
            if b''.join(chunks)!=encoded: raise SystemExit('existing cargo seed manifest differs from verified cache')
    finally: os.close(dfd)
    print('cargo_seed_24b8=PASS lock='+lockhash+' registry=762 git=3 extracted_crates=762 inventory_entries='+str(len(rows))+' bytes='+str(total)+' manifest_sha256='+hashlib.sha256(encoded).hexdigest())
    for fd in roots.values(): os.close(fd)
    os.close(seed); os.close(task); os.close(opt)
if __name__=='__main__': main()
