#!/usr/bin/python3
"""Exercise Git metadata guards and locked archive/source matching on synthetic data."""
import hashlib
import importlib.util
import io
import os
import pathlib
import subprocess
import tarfile
import tempfile

MODULE_PATH = pathlib.Path('/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/cargo-seed-verify-24b8-v3.py')
spec = importlib.util.spec_from_file_location('cargo_seed_24b8', MODULE_PATH)
if spec is None or spec.loader is None:
    raise SystemExit('cannot load pinned seed verifier')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.UID = os.getuid()
module.GID = os.getgid()
module.REGISTRY = 'fixture-index'

repo = 'termrock'
db = 'termrock-80ba21de23b1804f'
revision = '1ac0d0793b8cfd9edc61ced241e2b2ecb89162b4'
head = b'ref: refs/heads/master\n'
ref = (revision + '\n').encode()
checkout_config = module.git_checkout_config(repo, db)
db_config = b'[core]\n\tbare = true\n\trepositoryformatversion = 0\n\tfilemode = true\n'
module.validate_git_metadata(repo, db, revision, head, ref, checkout_config, head, ref, db_config)

cases = {
    'checkout_revision': (head, b'0' * 40 + b'\n', checkout_config, head, ref, db_config),
    'checkout_head': (b'ref: refs/heads/unexpected\n', ref, checkout_config, head, ref, db_config),
    'remote_credentials': (head, ref, checkout_config.replace(b'file:///work/', b'https://user:secret@host/'), head, ref, db_config),
    'remote_path': (head, ref, checkout_config.replace(db.encode(), b'wrong-db'), head, ref, db_config),
    'database_identity': (head, ref, checkout_config, head, b'0' * 40 + b'\n', db_config),
}
for label, args in cases.items():
    try:
        module.validate_git_metadata(repo, db, revision, *args)
    except SystemExit:
        continue
    raise SystemExit('negative Git metadata fixture was accepted: ' + label)

name, version = 'fixture-crate', '1.0.0'
base = name + '-' + version
members = {'a.txt': b'hello', 'sub/b.txt': b'locked source'}
archive_bytes = io.BytesIO()
with tarfile.open(fileobj=archive_bytes, mode='w:gz') as archive:
    for rel, data in members.items():
        info = tarfile.TarInfo(base + '/' + rel)
        info.mode = 0o644
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
raw_archive = archive_bytes.getvalue()
with tempfile.TemporaryDirectory(prefix='cargo-seed-fixture-') as temp:
    root = pathlib.Path(temp) / 'registry'
    for rel in ('cache/fixture-index', 'src/fixture-index/fixture-crate-1.0.0/sub'):
        (root / rel).mkdir(parents=True, mode=0o700)
    (root / 'cache/fixture-index/fixture-crate-1.0.0.crate').write_bytes(raw_archive)
    for rel, data in members.items():
        out = root / 'src/fixture-index/fixture-crate-1.0.0' / rel
        out.write_bytes(data)
    (root / 'src/fixture-index/fixture-crate-1.0.0/.cargo-ok').write_bytes(b'{"v":1}')
    for current, dirs, files in os.walk(root):
        os.chmod(current, 0o700)
        for leaf in files:
            os.chmod(pathlib.Path(current) / leaf, 0o600)
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        if module.verify_extracted_crate(fd, name, version, hashlib.sha256(raw_archive).hexdigest()) != 5:
            raise SystemExit('synthetic crate inventory count mismatch')
        (root / 'src/fixture-index/fixture-crate-1.0.0/a.txt').write_bytes(b'changed')
        try:
            module.verify_extracted_crate(fd, name, version, hashlib.sha256(raw_archive).hexdigest())
        except SystemExit:
            pass
        else:
            raise SystemExit('modified extracted source was accepted')
    finally:
        os.close(fd)

def rejected(call, label):
    try:
        call()
    except SystemExit:
        return
    raise SystemExit("negative fixture was accepted: " + label)

with tempfile.TemporaryDirectory(prefix='cargo-index-fixture-') as temp:
    root=pathlib.Path(temp)/'registry'
    index=root/'index'/'fixture-index'
    cache=index/'.cache'/'fi'/'xt'
    cache.mkdir(parents=True,mode=0o700)
    crate_config=index/'config.json'
    crate_config.write_text('{"dl":"https://static.crates.io/crates","api":"https://crates.io"}')
    cache_file=cache/'fixture-crate'
    checksum=hashlib.sha256(b'fixture archive').hexdigest()
    import json
    for current,dirs,files in os.walk(root):
        os.chmod(current,0o700)
        for name in files: os.chmod(pathlib.Path(current)/name,0o600)
    registryfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        def check_record(record, should_reject=False, label='record'):
            payload=(b'\x03\x02\x00\x00\x00etag: "fixture"\x00'+b'1.0.0\x00'+
                     json.dumps(record,separators=(',',':')).encode()+b'\x00')
            cache_file.write_bytes(payload)
            os.chmod(cache_file,0o600)
            if should_reject:
                rejected(lambda:module.verify_sparse_index(registryfd,'fixture-crate',{'1.0.0':checksum}),label)
            else:
                module.verify_sparse_index(registryfd,'fixture-crate',{'1.0.0':checksum})

        def check_raw_record(raw_record,label):
            payload=(b'\x03\x02\x00\x00\x00etag: "fixture"\x00'+b'1.0.0\x00'+raw_record+b'\x00')
            cache_file.write_bytes(payload)
            os.chmod(cache_file,0o600)
            rejected(lambda:module.verify_sparse_index(registryfd,'fixture-crate',{'1.0.0':checksum}),label)

        valid={"name":"fixture-crate","vers":"1.0.0","cksum":checksum,"deps":[],"yanked":False}
        check_record(valid,label='minimal schema v1')
        check_record({**valid,"v":2,"features":{"default":[]},"features2":{"optional":["dep:fixture-dep"]}},label='schema v2')
        check_record({**valid,"v":None,"features2":None,"yanked":None,"links":None,"rust_version":None,"pubtime":None},label='nullable Option fields')
        check_record({**valid,"deps":[{"name":"fixture-dep","req":"^1.0","target":None,"kind":None,"registry":None,"package":None,"public":None}]},label='dependency Option fields')
        check_record({**valid,"v":4294967295},True,'unsupported schema version')
        check_raw_record((b'{"name":"fixture-crate","vers":"1.0.0","cksum":"'+checksum.encode()+b'","deps":[],"v":4294967295,"v":1}'),'duplicate top-level JSON key')
        check_raw_record((b'{"name":"fixture-crate","vers":"1.0.0","cksum":"'+checksum.encode()+b'","deps":[{"name":"fixture-dep","name":"other","req":"^1.0"}]}'),'duplicate nested JSON key')
        check_record({**valid,"v":True},True,'boolean schema version')
        check_record({**valid,"name":"Fixture-Crate"},True,'case-mismatched package name')
        check_record({**valid,"deps":False},True,'dependency field type')
        check_record({**valid,"deps":[{"name":"fixture-dep"}]},True,'incomplete dependency record')
        check_record({**valid,"deps":[{"name":"fixture-dep","req":"^1.0","artifact":["bin"]}]},True,'unsupported artifact dependency schema')
        check_record({**valid,"deps":[{"name":"fixture-dep","req":"^1.0","bindep_target":"x86_64-unknown-linux-gnu"}]},True,'unsupported bindep target schema')
        check_record({**valid,"deps":[{"name":"fixture-dep","req":"^1.0","lib":True}]},True,'unsupported library dependency schema')
        check_record({**valid,"deps":[{"name":"fixture-dep","req":"^1.0","public":[]}]},True,'public dependency field type')
        check_record({**valid,"features":[]},True,'feature map type')
        check_record({**valid,"v":1,"features2":{"default":["dep:fixture-dep"]}},True,'features2 schema requirement')
        check_record({**valid,"yanked":"false"},True,'yanked field type')
        check_record({**valid,"pubtime":"2025-99-99T29:99:99Z"},True,'invalid publish time')
        check_record({**valid,"unexpected":"ignored"},True,'unknown top-level field')
        check_record(valid,label='restore valid row before checksum test')
        module.verify_registry_config(registryfd)
        crate_config.write_text('{\"dl\":\"https://attacker.invalid/crates\",\"dl\":\"https://static.crates.io/crates\",\"api\":\"https://crates.io\"}')
        os.chmod(crate_config,0o600)
        rejected(lambda:module.verify_registry_config(registryfd),'duplicate registry download key')
        crate_config.write_text('\"not an object\"')
        os.chmod(crate_config,0o600)
        rejected(lambda:module.verify_registry_config(registryfd),'non-object registry config')
        crate_config.write_text('{\"dl\":\"https://static.crates.io/crates\",\"api\":\"https://crates.io\"}')
        os.chmod(crate_config,0o600)
        module.verify_registry_config(registryfd)
        rejected(lambda:module.verify_sparse_index(registryfd,'fixture-crate',{'1.0.0':'0'*64}),'wrong locked checksum')
        crate_config.write_text('{"dl":"https://attacker.invalid/","api":"https://crates.io"}')
        os.chmod(crate_config,0o600)
        rejected(lambda:module.verify_registry_config(registryfd),'untrusted crate download endpoint')
    finally:
        os.close(registryfd)

with tempfile.TemporaryDirectory(prefix='cargo-git-tree-fixture-') as temp:
    root=pathlib.Path(temp)
    repo=root/'checkout'; repo.mkdir(mode=0o700)
    env={'PATH':'/usr/bin:/bin','HOME':temp,'LC_ALL':'C','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_AUTHOR_NAME':'Fixture','GIT_AUTHOR_EMAIL':'fixture@example.invalid','GIT_COMMITTER_NAME':'Fixture','GIT_COMMITTER_EMAIL':'fixture@example.invalid'}
    def git(*args):
        result=subprocess.run(['/usr/bin/git',*args],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=False,env=env)
        if result.returncode!=0 or result.stderr: raise SystemExit('synthetic Git setup failed')
        return result.stdout.decode().strip()
    git('init','--quiet','--initial-branch=master',str(repo))
    (repo/'nested').mkdir(mode=0o700)
    source_bytes=b'locked source bytes\n'
    (repo/'nested'/'file.txt').write_bytes(source_bytes)
    (repo/'nested'/'link').symlink_to('file.txt')
    git('-C',str(repo),'add','--all')
    git('-C',str(repo),'-c','core.hooksPath=/dev/null','commit','--quiet','-m','fixture')
    revision=git('-C',str(repo),'rev-parse','HEAD')
    repofd=os.open(repo,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        module.verify_git_checkout_tree(repofd,str(repo),revision,env)
        git('-C',str(repo),'update-index','--skip-worktree','nested/file.txt')
        (repo/'nested'/'file.txt').write_bytes(b'changed despite skip-worktree')
        rejected(lambda:module.verify_git_checkout_tree(repofd,str(repo),revision,env),'skip-worktree-modified Git blob')
    finally:
        os.close(repofd)

with tempfile.TemporaryDirectory(prefix='cargo-git-alternates-fixture-') as temp:
    info=pathlib.Path(temp)/'objects'/'info'; info.mkdir(parents=True,mode=0o700)
    fd=os.open(temp,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        module.require_empty_object_info(fd,'fixture','database')
        (info/'alternates').write_text('/outside/objects\n')
        rejected(lambda:module.require_empty_object_info(fd,'fixture','database alternate'),'Git object alternate')
    finally:
        os.close(fd)
print('cargo_seed_guard_fixture=PASS metadata_negative=%d archive_source_positive=1 archive_source_negative=1 sparse_index_v1_positive=1 sparse_index_v2_positive=1 sparse_option_null_positive=1 sparse_schema_negative=14 duplicate_json_keys=3 registry_config_negative=1 git_tree_positive=1 skip_worktree_negative=1 db_alternates_negative=1' % len(cases))
