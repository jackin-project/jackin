#!/usr/bin/python3
"""Validate the exact frozen source packet and reject packet identity drift."""
import hashlib
import os
import sys

MODULE_PATH = "/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/source-rebind-24b8-v4.py"
PACKET_PATH = "/root/.jackin-pr1111-source-24b8-20261005/source-packet.md"
PACKET_SHA = "22a0a9e3a777fbac13c3fbbec01505ab53bb3ebe18acc3d91f3fb1cfbe28bf2a"
PACKET_LIMIT = 1024 * 1024

scope = {"__file__": MODULE_PATH}
with open(MODULE_PATH, "rb") as stream:
    code = compile(stream.read(), MODULE_PATH, "exec")
exec(code, scope)
module_validate = scope["validate_source_packet"]
open_regular = scope["open_regular"]
raw = open_regular(PACKET_PATH, PACKET_SHA, None, PACKET_LIMIT)
module_validate(raw)
if hashlib.sha256(raw).hexdigest() != PACKET_SHA:
    raise SystemExit("frozen packet fixture digest mismatch")

def rejects(candidate, label):
    try:
        module_validate(candidate)
    except SystemExit:
        return
    raise SystemExit("invalid source packet was accepted: " + label)

text = raw.decode("utf-8")
mutations = {
    "wrong commit": text.replace("- Commit: `24b8d5423a212130e4a1c60beffed860248b7f27`", "- Commit: `34b8d5423a212130e4a1c60beffed860248b7f27`", 1),
    "duplicate commit": text + "\n- Commit: `24b8d5423a212130e4a1c60beffed860248b7f27`\n",
    "unquoted commit": text.replace("- Commit: `24b8d5423a212130e4a1c60beffed860248b7f27`", "- Commit: 24b8d5423a212130e4a1c60beffed860248b7f27", 1),
    "wrong tree": text.replace("- Tree: `63e21941838f728583e22220e9432f6afceb90b9`", "- Tree: `73e21941838f728583e22220e9432f6afceb90b9`", 1),
    "wrong archive digest": text.replace("- Archive SHA-256: `c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a`", "- Archive SHA-256: `d8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a`", 1),
    "wrong lock digest": text.replace("- `Cargo.lock`: SHA-256 `5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097`", "- `Cargo.lock`: SHA-256 `6e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097`", 1),
    "duplicate lock row": text + "\n- `Cargo.lock`: SHA-256 `5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097`, Git blob `04ecba8abab49a5c17e4e6d9dce95cfa07ac3daf`, 202427 bytes\n",
    "missing no-build statement": text.replace("No build or test result is claimed by this source packet.\n", "", 1),
}
for label, candidate in mutations.items():
    rejects(candidate.encode("utf-8"), label)
print("source_packet_fixture=PASS exact_frozen_packet=true rejected_mutations=" + str(len(mutations)))
