#!/usr/bin/python3
'''Check the frozen 24b8 source binding across helper, launcher, packet, and marker contract.'''
import hashlib
import os
import pathlib
import stat
import tempfile

LAUNCHER = "/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/launcher-pr1111-24b8-v5.sh"
HELPER = "/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/source-rebind-24b8-v4.py"
PACKET = "/root/.jackin-pr1111-source-24b8-20261005/source-packet.md"
ARCHIVE = "/root/.jackin-pr1111-source-24b8-20261005/jackin-24b8d5423a212130e4a1c60beffed860248b7f27.tar"
COMMIT = "24b8d5423a212130e4a1c60beffed860248b7f27"
TREE = "63e21941838f728583e22220e9432f6afceb90b9"
TASK = "/opt/.jackin-pr1111-24b8-mbx-20261005-v1"
ROOTFS = "/opt/.jackin-mbx-current-17b2b1b-v5-62dfd1ac/rootfs-clean-3986dfdd-v1"
ARCHIVE_SHA = "c8454e72854767370cbcb484fe2abec7e8bd7c851d7adf5780d09228df4e500a"
PACKET_SHA = "22a0a9e3a777fbac13c3fbbec01505ab53bb3ebe18acc3d91f3fb1cfbe28bf2a"
LOCK_SHA = "5e7f6b7018a449bd81a86e70bcf7e577b5ad378901001df845fa455794205097"
HELPER_SHA = "be26db1164e8f8cae10b3fdce8978f4b392d8f759b0cd58ec8e11c069706be27"
PLACEHOLDER = b"jackin-24b8-phase-mountpoint-v1\n"


def read_root_file(path, expected_sha, expected_mode, limit):
    parts = pathlib.PurePosixPath(path)
    if not parts.is_absolute() or any(part in ("", ".", "..") for part in parts.parts[1:]):
        raise SystemExit("unsafe fixture path")
    parent = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        for name in parts.parts[1:-1]:
            nxt = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
            st = os.fstat(nxt)
            if not stat.S_ISDIR(st.st_mode) or (st.st_uid, st.st_gid) != (0, 0) or st.st_mode & 0o022:
                os.close(nxt)
                raise SystemExit("unsafe fixture ancestor: " + name)
            os.close(parent)
            parent = nxt
        fd = os.open(parts.parts[-1], os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode), st.st_nlink) != (0, 0, expected_mode, 1) or st.st_size <= 0 or st.st_size > limit:
            os.close(fd)
            raise SystemExit("unsafe fixture input: " + path)
        data = bytearray()
        digest = hashlib.sha256()
        while True:
            block = os.read(fd, min(1024 * 1024, limit + 1 - len(data)))
            if not block:
                break
            data.extend(block)
            digest.update(block)
            if len(data) > limit:
                os.close(fd)
                raise SystemExit("fixture input exceeds bound")
        after = os.fstat(fd)
        os.close(fd)
        if len(data) != st.st_size or (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) != (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns):
            raise SystemExit("fixture input changed while reading")
        if expected_sha is not None and digest.hexdigest() != expected_sha:
            raise SystemExit("fixture input digest mismatch")
        return bytes(data)
    finally:
        os.close(parent)


launcher_bytes = read_root_file(LAUNCHER, None, 0o600, 131072)
helper_bytes = read_root_file(HELPER, HELPER_SHA, 0o600, 65536)
packet_bytes = read_root_file(PACKET, PACKET_SHA, 0o400, 1024 * 1024)
read_root_file(ARCHIVE, ARCHIVE_SHA, 0o400, 64 * 1024 * 1024)
launcher = launcher_bytes.decode("utf-8", "strict")
helper_text = helper_bytes.decode("utf-8", "strict")

for token in (
    "readonly TASK_ROOT=" + TASK,
    "readonly ROOTFS=" + ROOTFS,
    "readonly SOURCE_COMMIT=" + COMMIT,
    "readonly SOURCE_TREE=" + TREE,
    "readonly SOURCE_ARCHIVE_SHA256=" + ARCHIVE_SHA,
    "readonly SOURCE_PACKET_SHA256=" + PACKET_SHA,
    "readonly SOURCE_CARGO_LOCK_SHA256=" + LOCK_SHA,
    "readonly SOURCE_MARKER=source-recovery-24b8-v1.pass",
):
    if launcher.count(token) != 1:
        raise SystemExit("launcher source binding mismatch: " + token)

for token in (
    'TASK_ROOT = "' + TASK + '"',
    'ROOTFS = "' + ROOTFS + '"',
    'ARCHIVE_SHA = "' + ARCHIVE_SHA + '"',
    'PACKET_SHA = "' + PACKET_SHA + '"',
    'COMMIT = "' + COMMIT + '"',
    'TREE = "' + TREE + '"',
    '"Cargo.lock": "' + LOCK_SHA + '"',
):
    if helper_text.count(token) != 1:
        raise SystemExit("helper source binding mismatch: " + token)

packet_text = packet_bytes.decode("utf-8", "strict")
for token in (
    "- Commit: `" + COMMIT + "`",
    "- Tree: `" + TREE + "`",
    "- Archive SHA-256: `" + ARCHIVE_SHA + "`",
    "- `Cargo.lock`: SHA-256 `" + LOCK_SHA + "`",
):
    if packet_text.count(token) != 1:
        raise SystemExit("packet source binding mismatch: " + token)

if launcher.count("b'jackin-24b8-phase-mountpoint-v1\\n'") != 2:
    raise SystemExit("launcher phase placeholder does not match 24b8 helper")
if "jackin-a64-phase-mountpoint-v1" in launcher:
    raise SystemExit("stale a64 phase placeholder remains")
recover = launcher.split("source_recover_marker() {", 1)
if len(recover) != 2:
    raise SystemExit("source recovery phase is absent")
recover_body = recover[1].split("verify_source_phase() {", 1)[0]
if 'SOURCE_HELPER" verify' not in recover_body or "verify_task_state no" not in recover_body or 'write_pass_marker "$SOURCE_MARKER"' not in recover_body or " prepare" in recover_body:
    raise SystemExit("source recovery phase is not read-only verification plus marker")

namespace = {"__name__": "source_state_fixture", "__file__": HELPER}
exec(compile(helper_bytes, HELPER, "exec"), namespace)
with tempfile.TemporaryDirectory(prefix="jackin-source-phase-v1-", dir="/var/tmp") as temp:
    work = os.open(temp, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        namespace["ensure_phase_placeholder"](work, True)
        fd = os.open(".phase.sh", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=work)
        st = os.fstat(fd)
        data = os.read(fd, 128)
        os.close(fd)
        if (st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode), st.st_nlink, st.st_size) != (0, 0, 0o444, 1, len(PLACEHOLDER)) or data != PLACEHOLDER:
            raise SystemExit("source helper phase placeholder contract mismatch")
    finally:
        os.close(work)
print("source_state_fixture=PASS source=24b8 packet/helper/launcher identities aligned placeholder=PASS recovery=verify-only")
