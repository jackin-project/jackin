#!/usr/bin/python3
"""Exercise Cargo seed reflink copying with synthetic files under a private temp directory."""
import importlib.util
import os
import pathlib
import tempfile

MODULE_PATH = pathlib.Path("/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8/cargo-seed-snapshot-24b8-v3.py")
spec = importlib.util.spec_from_file_location("cargo_seed_snapshot_24b8", MODULE_PATH)
if spec is None or spec.loader is None:
    raise SystemExit("cannot load pinned seed snapshot helper")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.UID = os.getuid()
module.GID = os.getgid()

evidence = pathlib.Path("/root/.velnor-work/mbx-review.uXg3BZsJ/mbx-pr1111-24b8")
old_umask = os.umask(0o077)
try:
    with tempfile.TemporaryDirectory(prefix=".cargo-seed-snapshot-fixture-", dir=evidence) as temp:
        root = pathlib.Path(temp)
        source = root / "source"
        destination = root / "destination"
        source.mkdir(mode=0o700)
        destination.mkdir(mode=0o700)
        (source / "nested").mkdir(mode=0o700)
        original = b"locked Cargo source seed fixture\n"
        (source / "nested" / "crate.bin").write_bytes(original)
        (source / "nested" / "empty").write_bytes(b"")
        (source / "nested" / "relative-link").symlink_to("crate.bin")
        srcfd = os.open(source, module.DIR)
        dstfd = os.open(destination, module.DIR)
        try:
            state = {"entries": 0, "bytes": 0}
            module.clone_tree(srcfd, dstfd, "nested", "nested", state)
            copied = destination / "nested" / "crate.bin"
            if copied.read_bytes() != original:
                raise SystemExit("reflink copy changed fixture bytes")
            if (destination / "nested" / "empty").read_bytes() != b"":
                raise SystemExit("empty-file reflink changed fixture bytes")
            if os.stat(source / "nested" / "crate.bin").st_ino == os.stat(copied).st_ino:
                raise SystemExit("snapshot reused the source inode")
            (source / "nested" / "crate.bin").write_bytes(b"mutated source")
            if copied.read_bytes() != original:
                raise SystemExit("source mutation changed reflink snapshot")
            if os.readlink(destination / "nested" / "relative-link") != "crate.bin":
                raise SystemExit("relative symlink target changed")
        finally:
            os.close(srcfd)
            os.close(dstfd)

        unsafe_source = root / "unsafe"
        unsafe_destination = root / "unsafe-dest"
        unsafe_source.mkdir(mode=0o700)
        unsafe_destination.mkdir(mode=0o700)
        (unsafe_source / "nested").mkdir(mode=0o700)
        (unsafe_source / "nested" / "escape").symlink_to("../../outside")
        usfd = os.open(unsafe_source, module.DIR)
        udfd = os.open(unsafe_destination, module.DIR)
        try:
            try:
                module.clone_tree(usfd, udfd, "nested", "cache", {"entries": 0, "bytes": 0})
            except SystemExit:
                pass
            else:
                raise SystemExit("escaping symlink was accepted")
        finally:
            os.close(usfd)
            os.close(udfd)
finally:
    os.umask(old_umask)
print("cargo_seed_snapshot_fixture=PASS reflink_isolated=1 internal_symlink=1 escape_rejected=1")
