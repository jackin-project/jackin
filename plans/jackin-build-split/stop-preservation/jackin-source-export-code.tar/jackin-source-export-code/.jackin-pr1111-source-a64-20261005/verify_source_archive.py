#!/usr/bin/env python3
"""Verify a git-archive tar against an exact Git commit and emit JSONL inventory."""
import argparse
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True)
parser.add_argument("--commit", required=True)
parser.add_argument("--archive", required=True)
parser.add_argument("--inventory", required=True)
args = parser.parse_args()


def git(*cmd):
    return subprocess.check_output(["git", "-C", args.repo, *cmd])

commit = args.commit
raw = git("ls-tree", "-r", "-t", "-l", "-z", commit)
expected = {}
for record in raw.split(b"\0"):
    if not record:
        continue
    metadata, path_bytes = record.split(b"\t", 1)
    mode_s, kind, oid, size_s = metadata.decode("ascii").split(" ", 3)
    path = os.fsdecode(path_bytes)
    full_path = "jackin/" + path
    expected[full_path] = {
        "path": full_path,
        "kind": kind,
        "git_mode": mode_s,
        "git_oid": oid,
        "size": None if size_s.strip() == "-" else int(size_s.strip()),
    }
if any(item["kind"] == "commit" for item in expected.values()):
    raise SystemExit("gitlink/submodule entry found")
expected["jackin"] = {
    "path": "jackin",
    "kind": "tree-root",
    "git_mode": "040000",
    "git_oid": None,
    "size": None,
}

archive_members = {}
with tarfile.open(args.archive, "r:") as tf:
    for member in tf.getmembers():
        name = member.name.rstrip("/")
        if name in archive_members:
            raise SystemExit(f"duplicate tar member: {name!r}")
        archive_members[name] = member
        if member.isdir():
            observed_kind = "tree"
        elif member.issym():
            observed_kind = "symlink"
        elif member.isfile():
            observed_kind = "blob"
        else:
            raise SystemExit(f"special tar member: {name!r} type={member.type!r}")

expected_names = set(expected)
observed_names = set(archive_members)
if expected_names != observed_names:
    missing = sorted(expected_names - observed_names)
    extra = sorted(observed_names - expected_names)
    raise SystemExit(f"archive path mismatch missing={missing[:12]!r} extra={extra[:12]!r}")

records = []
blob_oids = set()
symlink_count = 0
executable_count = 0
for name in sorted(expected, key=os.fsencode):
    item = expected[name]
    member = archive_members[name]
    if item["kind"] in ("tree", "tree-root"):
        if not member.isdir() or (member.mode & 0o777) != 0o755:
            raise SystemExit(f"directory type/mode mismatch: {name!r} {member.mode:o}")
        item["archive_mode"] = format(member.mode & 0o777, "04o")
        item["verification"] = "match"
        records.append(item)
        continue
    mode = int(item["git_mode"], 8)
    if mode == 0o120000:
        symlink_count += 1
        blob = git("cat-file", "blob", item["git_oid"])
        if not member.issym() or os.fsencode(member.linkname) != blob:
            raise SystemExit(f"symlink target/mode mismatch: {name!r}")
        observed_bytes = blob
        expected_mode = 0o777
    else:
        if not member.isfile():
            raise SystemExit(f"regular blob type mismatch: {name!r}")
        stream = tarfile.open(args.archive, "r:")
        observed_bytes = stream.extractfile(member).read()
        stream.close()
        expected_mode = mode & 0o777
    if (member.mode & 0o777) != expected_mode:
        raise SystemExit(f"blob mode mismatch: {name!r} git={mode:o} tar={member.mode:o}")
    git_oid = hashlib.sha1(b"blob " + str(len(observed_bytes)).encode("ascii") + b"\0" + observed_bytes).hexdigest()
    if git_oid != item["git_oid"]:
        raise SystemExit(f"blob content mismatch: {name!r} expected={item['git_oid']} actual={git_oid}")
    if mode == 0o100755:
        executable_count += 1
    blob_oids.add(item["git_oid"])
    item["archive_mode"] = format(member.mode & 0o777, "04o")
    item["verification"] = "match"
    records.append(item)

with open(args.inventory, "w", encoding="utf-8", newline="\n") as out:
    for item in records:
        out.write(json.dumps(item, sort_keys=True, ensure_ascii=True) + "\n")

config_paths = [
    "Cargo.toml",
    "Cargo.lock",
    "rust-toolchain.toml",
    "mise.toml",
    "mise.lock",
    ".cargo/config.toml",
    ".velnor/config.toml",
    ".config/nextest.toml",
    ".codex/config.toml",
]
config_hashes = {}
for path in config_paths:
    try:
        data = git("show", f"{commit}:{path}")
    except subprocess.CalledProcessError:
        config_hashes[path] = None
    else:
        config_hashes[path] = hashlib.sha256(data).hexdigest()

summary = {
    "commit": commit,
    "archive_members": len(archive_members),
    "git_inventory_entries": len(records),
    "blobs": sum(item["kind"] == "blob" for item in records),
    "unique_blob_oids": len(blob_oids),
    "directories_including_root": sum(item["kind"] in ("tree", "tree-root") for item in records),
    "symlinks": symlink_count,
    "executables": executable_count,
    "all_paths_modes_symlink_targets_and_blob_contents_match": True,
    "gitlinks_or_special_archive_entries": 0,
    "config_sha256": config_hashes,
}
print(json.dumps(summary, indent=2, sort_keys=True))
