#!/usr/bin/python3
"""Export and verify one immutable PR source tree from Git objects only."""
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import subprocess
import tarfile

REPO = "/root/Projects/tailrocks/jackin-project/jackin"
OUT = "/root/.jackin-pr1111-source-4afc-20261005"
COMMIT = "4afc5a6eaa5dea404784c6176a32d9bd0c7f80b4"
TREE = "42d69fa07df17eca83d4a197739aa6980fabddd6"
PARENT = "a64af27dbefdf4d9239ad9e94209cb2416a4dbc4"
BASE = "0aa821a088e1bacf3d4d85a4c9faaa67faa85132"
ORIGIN = "https://github.com/jackin-project/jackin.git"
HANDSHAKE = OUT + "/github-pr.json"
REMOTE_REFS = OUT + "/remote-refs.txt"
LOCAL_ORIGIN = OUT + "/local-origin.txt"
ARCHIVE_NAME = "jackin-4afc5a6eaa5dea404784c6176a32d9bd0c7f80b4.tar"
MANIFEST_NAME = "tree-manifest.json"
PACKET_NAME = "source-packet.md"
MAX_OBJECT = 128 << 20
MAX_TOTAL = 1024 << 20
MAX_GIT_OUTPUT = 64 << 20
EXPECTED_CHANGED = {
    "crates/jackin/src/app/load_cmd.rs",
    "crates/jackin/src/app/load_cmd/tests.rs",
    "crates/jackin/src/cli/role.rs",
    "crates/jackin/src/cli/role/tests.rs",
}
PINNED_PATHS = (
    "Cargo.lock",
    "Cargo.toml",
    "mise.toml",
    "mise.lock",
    "rust-toolchain.toml",
    ".velnor/config.toml",
    ".cargo/config.toml",
    ".config/nextest.toml",
    "crates/jackin/Cargo.toml",
    "crates/jackin-xtask/Cargo.toml",
)
GIT_ENV = {
    "HOME": "/nonexistent",
    "PATH": "/usr/bin:/bin",
    "GIT_CONFIG_GLOBAL": "/dev/null",
    "GIT_CONFIG_SYSTEM": "/dev/null",
    "GIT_CONFIG_NOSYSTEM": "1",
    "GIT_TERMINAL_PROMPT": "0",
    "GIT_OPTIONAL_LOCKS": "0",
    "GIT_NO_LAZY_FETCH": "1",
    "GIT_NO_REPLACE_OBJECTS": "1",
    "GIT_PROTOCOL_FROM_USER": "0",
    "GIT_LFS_SKIP_SMUDGE": "1",
    "LC_ALL": "C",
}


def fail(message):
    raise SystemExit("PR1111 export: " + message)


def run_git(args, payload=None, limit=MAX_GIT_OUTPUT):
    command = [
        "/usr/bin/git", "-C", REPO, "-c", "core.fsmonitor=false",
        "-c", "core.hooksPath=/dev/null", "--no-replace-objects", *args,
    ]
    kwargs = {
        "stdout": subprocess.PIPE,
        "stderr": subprocess.PIPE,
        "env": GIT_ENV,
        "timeout": 180,
        "check": False,
    }
    if payload is None:
        kwargs["stdin"] = subprocess.DEVNULL
    else:
        kwargs["input"] = payload
    result = subprocess.run(command, **kwargs)
    if result.returncode != 0:
        fail("Git command failed: " + " ".join(args) + ": " + result.stderr[:4096].decode("utf-8", "replace"))
    if len(result.stdout) > limit or len(result.stderr) > 1 << 20:
        fail("Git output exceeded its bound: " + " ".join(args))
    return result.stdout


def sha1_object(kind, data):
    return hashlib.sha1(kind.encode("ascii") + b" " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_batch(oids):
    unique = list(dict.fromkeys(oids))
    if not unique:
        return {}
    request = b"".join(oid.encode("ascii") + b"\n" for oid in unique)
    checked = run_git(["cat-file", "--batch-check=%(objectname) %(objecttype) %(objectsize)"], request, limit=8 << 20)
    lines = checked.splitlines()
    if len(lines) != len(unique):
        fail("batch size preflight count mismatch")
    total = 0
    expected = {}
    for wanted, line in zip(unique, lines):
        fields = line.split()
        if len(fields) != 3 or fields[0].decode() != wanted:
            fail("missing or malformed Git object metadata")
        kind = fields[1].decode("ascii")
        size = int(fields[2])
        if kind == "missing" or size < 0 or size > MAX_OBJECT:
            fail("Git object is missing or exceeds per-object bound")
        total += size
        if total > MAX_TOTAL:
            fail("Git object set exceeds total size bound")
        expected[wanted] = (kind, size)
    raw = run_git(["cat-file", "--batch"], request, limit=MAX_TOTAL + (1 << 20))
    result = {}
    offset = 0
    for wanted in unique:
        end = raw.find(b"\n", offset)
        if end < 0:
            fail("truncated cat-file header")
        fields = raw[offset:end].split()
        if len(fields) != 3 or fields[0].decode("ascii") != wanted:
            fail("cat-file object identity mismatch")
        kind = fields[1].decode("ascii")
        size = int(fields[2])
        if expected[wanted] != (kind, size):
            fail("cat-file object size changed after preflight")
        data_start = end + 1
        data_end = data_start + size
        if data_end >= len(raw) or raw[data_end:data_end + 1] != b"\n":
            fail("truncated cat-file object body")
        data = raw[data_start:data_end]
        if sha1_object(kind, data) != wanted:
            fail("raw Git object SHA-1 mismatch: " + wanted)
        result[wanted] = (kind, data)
        offset = data_end + 1
    if offset != len(raw):
        fail("unexpected trailing bytes from cat-file")
    return result


def safe_path(raw):
    if not raw or raw.startswith(b"/") or b"\0" in raw:
        fail("unsafe or empty Git path")
    parts = raw.split(b"/")
    if any(part in (b"", b".", b"..") for part in parts):
        fail("unsafe Git path component")
    try:
        return raw.decode("utf-8", "strict")
    except UnicodeDecodeError:
        fail("Git path is not UTF-8; refusing lossy archive name")


def parse_tree(data, parent_path=b""):
    items = []
    offset = 0
    while offset < len(data):
        space = data.find(b" ", offset)
        nul = data.find(b"\0", space + 1)
        if space < 0 or nul < 0 or nul + 21 > len(data):
            fail("malformed raw Git tree entry")
        mode = data[offset:space].decode("ascii")
        name = data[space + 1:nul]
        oid = data[nul + 1:nul + 21].hex()
        offset = nul + 21
        path = name if not parent_path else parent_path + b"/" + name
        safe_path(path)
        if mode in ("40000", "040000"):
            kind = "tree"
        elif mode in ("100644", "100755", "120000"):
            kind = "blob"
        elif mode == "160000":
            kind = "commit"
        else:
            fail("unsupported Git tree mode: " + mode)
        items.append({"path_bytes": path, "path": safe_path(path), "mode": mode, "type": kind, "oid": oid})
    return items


def write_new(path, data, mode=0o400):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        view = memoryview(data)
        while view:
            count = os.write(fd, view)
            if count <= 0:
                fail("short output write")
            view = view[count:]
        os.fchown(fd, 0, 0)
        os.fchmod(fd, mode)
        os.fsync(fd)
    finally:
        os.close(fd)


def verify_tar(archive_path, expected_members, blobs):
    seen = {}
    with tarfile.open(archive_path, mode="r:") as tf:
        for member in tf.getmembers():
            name = member.name
            normalized = name.rstrip("/")
            if normalized in seen:
                fail("duplicate tar member: " + name)
            if member.uid != 0 or member.gid != 0 or member.mtime != 0:
                fail("archive metadata is not canonical: " + name)
            expected = expected_members.get(normalized)
            if expected is None:
                fail("archive contains an unexpected path: " + name)
            kind, mode, oid, target = expected
            if kind == "directory":
                if not member.isdir() or stat.S_IMODE(member.mode) != mode:
                    fail("directory mode/type mismatch: " + name)
            elif kind == "symlink":
                if not member.issym() or stat.S_IMODE(member.mode) != 0o777 or member.linkname != target:
                    fail("symlink mode/target mismatch: " + name)
            elif kind == "file":
                if not member.isfile() or stat.S_IMODE(member.mode) != mode:
                    fail("blob mode/type mismatch: " + name)
                extracted = tf.extractfile(member)
                if extracted is None or extracted.read() != blobs[oid]:
                    fail("archive blob differs from Git object: " + name)
            else:
                fail("unknown expected archive member type")
            seen[normalized] = True
    if set(seen) != set(expected_members):
        missing = sorted(set(expected_members) - set(seen))[:10]
        fail("archive is missing tracked paths: " + repr(missing))


def write_archive(archive_path, entries, blobs):
    dirs = {"jackin"}
    expected = {"jackin": ("directory", 0o755, None, None)}
    for entry in entries:
        path = entry["path"]
        components = path.split("/")
        for index in range(1, len(components)):
            dirs.add("jackin/" + "/".join(components[:index]))
        if entry["type"] == "tree":
            dirs.add("jackin/" + path)
        elif entry["type"] == "commit":
            dirs.add("jackin/" + path)
        elif entry["mode"] == "120000":
            target_bytes = blobs[entry["oid"]]
            if b"\0" in target_bytes:
                fail("NUL in symlink target")
            try:
                target = target_bytes.decode("utf-8", "strict")
            except UnicodeDecodeError:
                fail("symlink target is not UTF-8")
            entry["symlink_target"] = target
            expected["jackin/" + path] = ("symlink", 0o777, entry["oid"], target)
        else:
            expected["jackin/" + path] = ("file", int(entry["mode"], 8) & 0o777, entry["oid"], None)
    for directory in dirs:
        if directory != "jackin":
            expected[directory] = ("directory", 0o755, None, None)
    fd = os.open(archive_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, "wb") as raw:
        with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as tf:
            directories = sorted(dirs, key=lambda item: (item.count("/"), item))
            for name in directories:
                info = tarfile.TarInfo(name + "/")
                info.type = tarfile.DIRTYPE
                info.mode = 0o755
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                info.mtime = 0
                tf.addfile(info)
            for entry in sorted((item for item in entries if item["type"] not in ("tree", "commit")), key=lambda item: item["path"]):
                name = "jackin/" + entry["path"]
                info = tarfile.TarInfo(name)
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                info.mtime = 0
                if entry["mode"] == "120000":
                    info.type = tarfile.SYMTYPE
                    info.mode = 0o777
                    info.linkname = entry["symlink_target"]
                    info.size = 0
                    tf.addfile(info)
                else:
                    info.type = tarfile.REGTYPE
                    info.mode = int(entry["mode"], 8) & 0o777
                    data = blobs[entry["oid"]]
                    info.size = len(data)
                    tf.addfile(info, io.BytesIO(data))
        raw.flush()
        os.fsync(raw.fileno())
    os.chmod(archive_path, 0o400, follow_symlinks=False)
    verify_tar(archive_path, expected, blobs)
    return expected


def main():
    os.umask(0o077)
    if os.geteuid() != 0 or os.getegid() != 0:
        fail("must run as root to create root-owned immutable artifacts")
    if os.environ.get("PYTHONDONTWRITEBYTECODE") != "1":
        fail("entry requires bytecode disabled")
    out = os.lstat(OUT)
    if not stat.S_ISDIR(out.st_mode) or (out.st_uid, out.st_gid, stat.S_IMODE(out.st_mode)) != (0, 0, 0o700):
        fail("unsafe output directory")
    for name in (ARCHIVE_NAME, MANIFEST_NAME, PACKET_NAME):
        if os.path.lexists(os.path.join(OUT, name)):
            fail("output already exists: " + name)
    handshake = json.loads(pathlib.Path(HANDSHAKE).read_text())
    if handshake.get("head_sha") != COMMIT or handshake.get("base_sha") != BASE or handshake.get("number") != 1111 or handshake.get("head_repository") != "jackin-project/jackin":
        fail("GitHub PR handshake does not bind the selected commit")
    refs = pathlib.Path(REMOTE_REFS).read_text().splitlines()
    expected_refs = {"refs/pull/1111/head": COMMIT, "refs/heads/main": BASE}
    parsed_refs = {}
    for line in refs:
        fields = line.split()
        if len(fields) == 2:
            parsed_refs[fields[1]] = fields[0]
    if any(parsed_refs.get(ref) != oid for ref, oid in expected_refs.items()):
        fail("canonical remote PR head handshake mismatch")
    if pathlib.Path(LOCAL_ORIGIN).read_text().strip() != ORIGIN:
        fail("local canonical origin mismatch")
    commit_bytes = run_git(["cat-file", "commit", COMMIT], limit=2 << 20)
    if sha1_object("commit", commit_bytes) != COMMIT:
        fail("raw commit object hash mismatch")
    header = commit_bytes.split(b"\n\n", 1)[0].splitlines()
    tree_lines = [line.split(b" ", 1)[1].decode("ascii") for line in header if line.startswith(b"tree ")]
    parents = [line.split(b" ", 1)[1].decode("ascii") for line in header if line.startswith(b"parent ")]
    if tree_lines != [TREE] or parents != [PARENT]:
        fail("raw commit tree or parent differs from requested source")
    entries = []
    seen_paths = set()
    all_tree_oids = {TREE}
    tree_objects = {}
    pending_trees = [(b"", TREE)]
    while pending_trees:
        layer = pending_trees
        pending_trees = []
        layer_objects = read_batch([oid for _, oid in layer])
        for oid, pair in layer_objects.items():
            if pair[0] != "tree":
                fail("tree entry has non-tree object")
            tree_objects[oid] = pair
        for parent_path, oid in layer:
            for raw_item in parse_tree(tree_objects[oid][1], parent_path):
                path = raw_item["path"]
                if path in seen_paths:
                    fail("duplicate path in raw tree")
                seen_paths.add(path)
                item = {key: value for key, value in raw_item.items() if key != "path_bytes"}
                entries.append(item)
                if item["type"] == "tree":
                    all_tree_oids.add(item["oid"])
                    pending_trees.append((raw_item["path_bytes"], item["oid"]))
    raw_tree_listing = run_git(["ls-tree", "-r", "-t", "-z", "--full-tree", COMMIT], limit=MAX_GIT_OUTPUT)
    listed = set()
    for record in raw_tree_listing.split(b"\0"):
        if not record:
            continue
        header_part, path_bytes = record.split(b"\t", 1)
        mode_b, kind_b, oid_b = header_part.split(b" ", 2)
        mode = mode_b.decode("ascii")
        if mode == "040000":
            mode = "40000"
        listed.add((safe_path(path_bytes), mode, kind_b.decode("ascii"), oid_b.decode("ascii")))
    parsed = {(item["path"], item["mode"], item["type"], item["oid"]) for item in entries}
    if listed != parsed:
        fail("raw tree parser and Git ls-tree inventory disagree")
    blob_oids = sorted({item["oid"] for item in entries if item["type"] == "blob"})
    blobs_with_kind = read_batch(blob_oids)
    if any(blobs_with_kind[oid][0] != "blob" for oid in blob_oids):
        fail("blob entry has non-blob object")
    blobs = {oid: pair[1] for oid, pair in blobs_with_kind.items()}
    for entry in entries:
        if entry["type"] == "blob":
            data = blobs[entry["oid"]]
            entry["size"] = len(data)
            entry["sha256"] = sha256(data)
            if entry["mode"] == "120000":
                entry["symlink_target"] = data.decode("utf-8", "strict")
        elif entry["type"] == "tree":
            entry["size"] = len(tree_objects[entry["oid"]][1])
            entry["sha256"] = sha256(tree_objects[entry["oid"]][1])
        else:
            entry["size"] = None
            entry["sha256"] = None
    changes_raw = run_git(["diff-tree", "--no-commit-id", "--name-only", "--no-renames", "-r", "-z", PARENT, COMMIT], limit=1 << 20)
    changed = {safe_path(item) for item in changes_raw.split(b"\0") if item}
    if changed != EXPECTED_CHANGED:
        fail("changed-path scope differs: " + repr(sorted(changed)))
    pinned = {}
    entry_by_path = {entry["path"]: entry for entry in entries}
    for path in PINNED_PATHS:
        entry = entry_by_path.get(path)
        if entry is None or entry["type"] != "blob":
            fail("missing pinned input file: " + path)
        pinned[path] = {"git_blob": entry["oid"], "sha256": entry["sha256"], "size": entry["size"]}
    archive_path = os.path.join(OUT, ARCHIVE_NAME)
    expected_members = write_archive(archive_path, entries, blobs)
    archive_data_sha = hashlib.sha256()
    archive_size = 0
    with open(archive_path, "rb") as stream:
        while True:
            chunk = stream.read(1 << 20)
            if not chunk:
                break
            archive_data_sha.update(chunk)
            archive_size += len(chunk)
    manifest = {
        "schema": 1,
        "repository": ORIGIN,
        "pull_request": 1111,
        "source_commit": COMMIT,
        "source_tree": TREE,
        "source_parents": parents,
        "base_commit_at_handshake": BASE,
        "branch_at_handshake": handshake["head_ref"],
        "remote_pr_ref_at_handshake": COMMIT,
        "changed_paths_from_parent": sorted(changed),
        "archive": {"name": ARCHIVE_NAME, "sha256": archive_data_sha.hexdigest(), "size": archive_size, "format": "PAX tar; raw Git blobs; no checkout filters, hooks, or submodules executed"},
        "pinned_inputs": pinned,
        "entry_count": len(entries),
        "directory_count": sum(entry["type"] == "tree" for entry in entries) + 1,
        "blob_entry_count": sum(entry["type"] == "blob" for entry in entries),
        "unique_blob_count": len(blobs),
        "gitlink_count": sum(entry["type"] == "commit" for entry in entries),
        "lfs_pointers": [],
        "entries": sorted(entries, key=lambda item: item["path"]),
        "source_execution": "NOT RUN: no Cargo, test, build, CLI, docs-spec, or source program command was invoked",
    }
    lfs_re = re.compile(rb"version https://git-lfs.github.com/spec/v1\n(?:ext-0-[^\n]+\n)?oid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n\Z")
    for entry in manifest["entries"]:
        if entry["type"] == "blob":
            match = lfs_re.fullmatch(blobs[entry["oid"]])
            if match:
                manifest["lfs_pointers"].append({"path": entry["path"], "git_blob": entry["oid"], "sha256": match.group(1).decode(), "size": int(match.group(2))})
    manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    manifest_path = os.path.join(OUT, MANIFEST_NAME)
    write_new(manifest_path, manifest_bytes)
    manifest_sha = sha256(manifest_bytes)
    archive_sha = archive_data_sha.hexdigest()
    packet = f'''# Jackin PR #1111 exact source export\n\nStatus: raw-Git source data exported and full-blob verified. No Cargo, test, build, CLI, docs-spec, generation, or source program was run.\n\n## Authenticated source identity\n\n- Repository: `{ORIGIN}`\n- PR: `1111`, head ref `{handshake["head_ref"]}`\n- Commit: `{COMMIT}`\n- Tree: `{TREE}`\n- Parent: `{PARENT}`\n- PR base at API observation: `{BASE}` (`{handshake["base_ref"]}`)\n- GitHub API handshake SHA-256: `{sha256(pathlib.Path(HANDSHAKE).read_bytes())}`\n- Remote refs transcript SHA-256: `{sha256(pathlib.Path(REMOTE_REFS).read_bytes())}`\n- Handshake window: `{pathlib.Path(OUT + "/handshake-start.txt").read_text().strip()}` to `{pathlib.Path(OUT + "/handshake-end.txt").read_text().strip()}` UTC\n- Local origin: `{ORIGIN}`; remote PR head ref resolved to the exact selected commit during the handshake.\n\n## Scope and archive\n\nThe selected commit changes exactly four paths against its parent: `crates/jackin/src/app/load_cmd.rs`, `crates/jackin/src/app/load_cmd/tests.rs`, `crates/jackin/src/cli/role.rs`, and `crates/jackin/src/cli/role/tests.rs`. The archive is the complete committed tree and excludes uncommitted worktree changes.\n\n- Archive: `{ARCHIVE_NAME}`\n- Archive SHA-256: `{archive_sha}`\n- Archive bytes: `{archive_size}`\n- Archive mode/owner: `root:root 0400`; output directory `root:root 0700`\n- Manifest: `{MANIFEST_NAME}`\n- Manifest SHA-256: `{manifest_sha}`\n- Inventory: {manifest["entry_count"]} tree entries; {manifest["blob_entry_count"]} blob entries; {manifest["unique_blob_count"]} unique blobs; {manifest["directory_count"]} directories; {manifest["gitlink_count"]} gitlinks; {len(manifest["lfs_pointers"])} LFS pointers. Every raw blob SHA-1 was checked against its Git object ID and SHA-256 recorded; archive file bytes, modes, symlink targets, and member inventory were independently checked against the raw tree.\n- Per-path blob/mode/symlink and tree inventory is in the JSON manifest. Gitlinks and LFS pointers, if any, are recorded but not hydrated.\n\n## Build inputs\n\n'''
    for path, item in pinned.items():
        packet += f"- `{path}`: SHA-256 `{item['sha256']}`, Git blob `{item['git_blob']}`, {item['size']} bytes\n"
    packet += f"\nNo build or test result is claimed by this source packet.\n"
    packet_bytes = packet.encode()
    packet_path = os.path.join(OUT, PACKET_NAME)
    write_new(packet_path, packet_bytes)
    for filename in ("handshake-start.txt", "handshake-end.txt", "github-pr.json", "remote-refs.txt", "local-origin.txt"):
        path = os.path.join(OUT, filename)
        os.chown(path, 0, 0, follow_symlinks=False)
        os.chmod(path, 0o400, follow_symlinks=False)
    print(json.dumps({
        "archive_path": archive_path,
        "archive_sha256": archive_sha,
        "archive_size": archive_size,
        "manifest_path": manifest_path,
        "manifest_sha256": manifest_sha,
        "manifest_size": len(manifest_bytes),
        "packet_path": packet_path,
        "packet_sha256": sha256(packet_bytes),
        "packet_size": len(packet_bytes),
        "entries": len(entries),
        "blob_entries": manifest["blob_entry_count"],
        "unique_blobs": len(blobs),
        "directories": manifest["directory_count"],
        "gitlinks": manifest["gitlink_count"],
        "lfs_pointers": len(manifest["lfs_pointers"]),
        "changed_paths": sorted(changed),
        "pinned": pinned,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
